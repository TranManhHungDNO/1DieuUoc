-- NUKEVIET 4.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: localhost
-- Generation Time: February 24, 2016, 10:54 AM GMT
-- Server version: 5.5.31
-- PHP Version: 5.5.30

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8';
SET SESSION `character_set_results`='utf8';
SET SESSION `character_set_connection`='utf8';
SET SESSION `collation_connection`='utf8_general_ci';
SET NAMES 'utf8';
ALTER DATABASE DEFAULT CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

--
-- Database: `dieuuoc_4x`
--


-- ---------------------------------------


--
-- Table structure for table `ctypa_authors`
--

DROP TABLE IF EXISTS `ctypa_authors`;
CREATE TABLE `ctypa_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) DEFAULT '',
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) DEFAULT '',
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` text,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_authors`
--

INSERT INTO `ctypa_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', 'b9e3f17d751545a328dc85bd732aaec3', 1453464478, '113.174.226.124', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:43.0) Gecko/20100101 Firefox/43.0');


-- ---------------------------------------


--
-- Table structure for table `ctypa_authors_config`
--

DROP TABLE IF EXISTS `ctypa_authors_config`;
CREATE TABLE `ctypa_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_authors_module`
--

DROP TABLE IF EXISTS `ctypa_authors_module`;
CREATE TABLE `ctypa_authors_module` (
  `mid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `lang_key` varchar(50) NOT NULL DEFAULT '',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  `act_1` tinyint(4) NOT NULL DEFAULT '0',
  `act_2` tinyint(4) NOT NULL DEFAULT '1',
  `act_3` tinyint(4) NOT NULL DEFAULT '1',
  `checksum` varchar(32) DEFAULT '',
  PRIMARY KEY (`mid`),
  UNIQUE KEY `module` (`module`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_authors_module`
--

INSERT INTO `ctypa_authors_module` VALUES
(1, 'siteinfo', 'mod_siteinfo', 1, 1, 1, 1, 'b90d11f59b374692a41c395b36be3a77'), 
(2, 'authors', 'mod_authors', 2, 1, 1, 1, '9ce34325d3056684d2f8a487bfe4e0d3'), 
(3, 'settings', 'mod_settings', 3, 1, 1, 0, '6fbfaa1f493a6d1d0f627825bfcd5aea'), 
(4, 'database', 'mod_database', 4, 1, 0, 0, 'adfc4cd0e5230d89cecd703901b5836e'), 
(5, 'webtools', 'mod_webtools', 5, 1, 0, 0, 'ef04ba6ff94ff127132106564ce77962'), 
(6, 'seotools', 'mod_seotools', 6, 1, 0, 0, '732de064e223423c602d4cab3e870f3b'), 
(7, 'language', 'mod_language', 7, 1, 1, 0, '2c7ee462a0679368335d3a64f0bc0657'), 
(8, 'modules', 'mod_modules', 8, 1, 1, 0, '3c8a96952de3d4091b0de28111028d84'), 
(9, 'themes', 'mod_themes', 9, 1, 1, 0, 'acc89b51a61cfc24082e845da944817e'), 
(10, 'extensions', 'mod_extensions', 10, 1, 0, 0, '9437f5cee43b7eef7a83a108fb4a5284'), 
(11, 'upload', 'mod_upload', 11, 1, 1, 1, '695f83d16ce7919098bdf34b31ee6804');


-- ---------------------------------------


--
-- Table structure for table `ctypa_banip`
--

DROP TABLE IF EXISTS `ctypa_banip`;
CREATE TABLE `ctypa_banip` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_banners_click`
--

DROP TABLE IF EXISTS `ctypa_banners_click`;
CREATE TABLE `ctypa_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_banners_click`
--

INSERT INTO `ctypa_banners_click` VALUES
(3, 1453343086, 0, '5.9.87.111', 'DE', '', 'Unknown', '', 'Majestic-12', ''), 
(3, 1453451345, 0, '66.249.71.183', 'US', '', 'Unknown', '', 'Google Bot', ''), 
(1, 1453662135, 0, '203.113.152.5', 'VN', '', 'firefox', '', 'Windows 7', ''), 
(2, 1453686530, 0, '203.113.152.2', 'VN', '', 'firefox', '', 'Windows 7', ''), 
(1, 1454205785, 0, '178.151.143.163', 'UA', '', 'Unknown', '', 'Majestic-12', ''), 
(2, 1454205789, 0, '178.151.143.163', 'UA', '', 'Unknown', '', 'Majestic-12', ''), 
(3, 1454284977, 0, '89.27.36.103', 'FI', '', 'Unknown', '', 'Majestic-12', ''), 
(1, 1454486426, 0, '193.111.140.153', 'GB', '', 'Unknown', '', 'Majestic-12', ''), 
(2, 1454486428, 0, '193.111.140.153', 'GB', '', 'Unknown', '', 'Majestic-12', ''), 
(1, 1455312603, 0, '203.113.152.2', 'VN', '', 'firefox', '', 'Windows 7', ''), 
(1, 1455323428, 0, '203.113.152.6', 'VN', '', 'firefox', '', 'Windows 7', ''), 
(1, 1455334257, 0, '203.113.152.4', 'VN', '', 'firefox', '', 'Windows 7', ''), 
(2, 1455351158, 0, '203.113.152.8', 'VN', '', 'firefox', '', 'Windows 7', ''), 
(1, 1455355907, 0, '203.113.152.5', 'VN', '', 'firefox', '', 'Windows 7', '');


-- ---------------------------------------


--
-- Table structure for table `ctypa_banners_clients`
--

DROP TABLE IF EXISTS `ctypa_banners_clients`;
CREATE TABLE `ctypa_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(80) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_banners_plans`
--

DROP TABLE IF EXISTS `ctypa_banners_plans`;
CREATE TABLE `ctypa_banners_plans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) DEFAULT '',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_banners_plans`
--

INSERT INTO `ctypa_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 510, 100, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_banners_rows`
--

DROP TABLE IF EXISTS `ctypa_banners_rows`;
CREATE TABLE `ctypa_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) DEFAULT '',
  `imageforswf` varchar(255) DEFAULT '',
  `click_url` varchar(255) DEFAULT '',
  `target` varchar(10) NOT NULL DEFAULT '_blank',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_banners_rows`
--

INSERT INTO `ctypa_banners_rows` VALUES
(1, 'Bo ngoai giao', 2, 0, 'bongoaigiao.jpg', 'jpg', 'image/jpeg', 160, 54, '', '', 'http://www.mofa.gov.vn', '_blank', 1430288935, 1430288935, 0, 7, 1, 1), 
(2, 'vinades', 2, 0, 'vinades.jpg', 'jpg', 'image/jpeg', 190, 454, '', '', 'http://vinades.vn', '_blank', 1430288935, 1430288935, 0, 4, 1, 2), 
(3, 'Quang cao giua trang', 1, 0, 'webnhanh_vn.gif', 'gif', 'image/gif', 510, 65, '', '', 'http://webnhanh.vn', '_blank', 1430288935, 1430288935, 0, 3, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_config`
--

DROP TABLE IF EXISTS `ctypa_config`;
CREATE TABLE `ctypa_config` (
  `lang` varchar(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` text,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_config`
--

INSERT INTO `ctypa_config` VALUES
('sys', 'site', 'closed_site', '0'), 
('sys', 'site', 'admin_theme', 'admin_default'), 
('sys', 'site', 'date_pattern', 'l, d/m/Y'), 
('sys', 'site', 'time_pattern', 'H:i'), 
('sys', 'site', 'online_upd', '1'), 
('sys', 'site', 'statistic', '1'), 
('sys', 'site', 'mailer_mode', ''), 
('sys', 'site', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'site', 'smtp_ssl', '1'), 
('sys', 'site', 'smtp_port', '465'), 
('sys', 'site', 'smtp_username', 'user@gmail.com'), 
('sys', 'site', 'smtp_password', ''), 
('sys', 'site', 'googleAnalyticsID', ''), 
('sys', 'site', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'site', 'googleAnalyticsMethod', 'classic'), 
('sys', 'site', 'searchEngineUniqueID', ''), 
('sys', 'site', 'metaTagsOgp', '1'), 
('sys', 'site', 'pageTitleMode', 'pagetitle - sitename'), 
('sys', 'site', 'description_length', '170'), 
('sys', 'global', 'ssl_https', '0'), 
('sys', 'global', 'notification_active', '1'), 
('sys', 'global', 'notification_autodel', '15'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '134217728'), 
('sys', 'global', 'upload_checking_mode', 'strong'), 
('sys', 'global', 'upload_alt_require', '1'), 
('sys', 'global', 'upload_auto_alt', '1'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '0'), 
('sys', 'global', 'allowuserpublic', '0'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'allow_adminlangs', 'en,vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'rewrite_optional', '1'), 
('sys', 'global', 'rewrite_endurl', '.ct1'), 
('sys', 'global', 'rewrite_exturl', '.ct1'), 
('sys', 'global', 'rewrite_op_mod', ''), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'openid_mode', '1'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', 'yahoo,google'), 
('sys', 'global', 'optActive', '1'), 
('sys', 'global', 'timestamp', '14'), 
('sys', 'global', 'mudim_displaymode', '1'), 
('sys', 'global', 'mudim_method', '4'), 
('sys', 'global', 'mudim_showpanel', '1'), 
('sys', 'global', 'mudim_active', '1'), 
('sys', 'global', 'captcha_type', '0'), 
('sys', 'global', 'version', '4.0.15'), 
('sys', 'global', 'whoviewuser', '2'), 
('sys', 'global', 'facebook_client_id', ''), 
('sys', 'global', 'facebook_client_secret', ''), 
('sys', 'global', 'google_client_id', ''), 
('sys', 'global', 'google_client_secret', ''), 
('sys', 'global', 'cookie_httponly', '1'), 
('sys', 'global', 'admin_check_pass_time', '1800'), 
('sys', 'global', 'adminrelogin_max', '3'), 
('sys', 'global', 'cookie_secure', '0'), 
('sys', 'global', 'nv_unick_type', '4'), 
('sys', 'global', 'nv_upass_type', '0'), 
('sys', 'global', 'is_flood_blocker', '1'), 
('sys', 'global', 'max_requests_60', '40'), 
('sys', 'global', 'max_requests_300', '150'), 
('sys', 'global', 'nv_display_errors_list', '1'), 
('sys', 'global', 'display_errors_list', '1'), 
('sys', 'global', 'nv_auto_resize', '1'), 
('sys', 'global', 'dump_interval', '1'), 
('sys', 'global', 'cdn_url', ''), 
('sys', 'define', 'nv_unickmin', '4'), 
('sys', 'define', 'nv_unickmax', '20'), 
('sys', 'define', 'nv_upassmin', '5'), 
('sys', 'define', 'nv_upassmax', '20'), 
('sys', 'define', 'nv_gfx_num', '6'), 
('sys', 'define', 'nv_gfx_width', '120'), 
('sys', 'define', 'nv_gfx_height', '25'), 
('sys', 'define', 'nv_max_width', '1500'), 
('sys', 'define', 'nv_max_height', '1500'), 
('sys', 'define', 'nv_live_cookie_time', '31104000'), 
('sys', 'define', 'nv_live_session_time', '0'), 
('sys', 'define', 'nv_anti_iframe', '0'), 
('sys', 'define', 'nv_anti_agent', '0'), 
('sys', 'define', 'nv_allowed_html_tags', 'embed, object, param, a, b, blockquote, br, caption, col, colgroup, div, em, h1, h2, h3, h4, h5, h6, hr, i, img, li, p, span, strong, sub, sup, table, tbody, td, th, tr, u, ul, iframe, figure, figcaption, video, source, track, code, pre'), 
('sys', 'define', 'dir_forum', ''), 
('vi', 'global', 'site_domain', 'www.k6ct1.com'), 
('vi', 'global', 'site_name', 'Trường Trung Cấp Đăk Lắp - Lớp CNTT K6CT1'), 
('vi', 'global', 'site_logo', 'images/logo.png'), 
('vi', 'global', 'site_description', 'Trường Trung Cấp Đăk Lăk - Lớp CNTT K6CT1'), 
('vi', 'global', 'site_keywords', 'k6ct1, cntt k6ct1, lớp công nghệ thông tin k6ct1, lop cong nghe thong tin k6ct1'), 
('vi', 'global', 'site_theme', 'default'), 
('vi', 'global', 'mobile_theme', ''), 
('vi', 'global', 'site_home_module', 'news'), 
('vi', 'global', 'switch_mobi_des', '0'), 
('vi', 'global', 'upload_logo', 'images/logo.png'), 
('vi', 'global', 'autologosize1', '50'), 
('vi', 'global', 'autologosize2', '40'), 
('vi', 'global', 'autologosize3', '30'), 
('vi', 'global', 'autologomod', ''), 
('vi', 'global', 'name_show', '0'), 
('vi', 'global', 'cronjobs_next_time', '1456311559'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'seotools', 'prcservice', ''), 
('vi', 'about', 'auto_postcomm', '1'), 
('vi', 'about', 'allowed_comm', '-1'), 
('vi', 'about', 'view_comm', '6'), 
('vi', 'about', 'setcomm', '4'), 
('vi', 'about', 'activecomm', '0'), 
('vi', 'about', 'emailcomm', '0'), 
('vi', 'about', 'adminscomm', ''), 
('vi', 'about', 'sortcomm', '0'), 
('vi', 'about', 'captcha', '1'), 
('vi', 'news', 'tags_alias', '0'), 
('vi', 'news', 'alias_lower', '1'), 
('vi', 'news', 'timecheckstatus', '0'), 
('vi', 'news', 'config_source', '0'), 
('vi', 'news', 'show_no_image', ''), 
('vi', 'news', 'allowed_rating_point', '1'), 
('vi', 'news', 'facebookappid', ''), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'homewidth', '120'), 
('vi', 'news', 'homeheight', '120'), 
('vi', 'news', 'blockwidth', '120'), 
('vi', 'news', 'blockheight', '120'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'copyright', ''), 
('vi', 'news', 'showtooltip', '1'), 
('vi', 'news', 'tooltip_position', 'right'), 
('vi', 'news', 'tooltip_length', '150'), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'indexfile', 'viewcat_main_bottom'), 
('vi', 'news', 'auto_tags', '0'), 
('vi', 'news', 'socialbutton', '1'), 
('vi', 'page', 'auto_postcomm', '1'), 
('vi', 'page', 'allowed_comm', '-1'), 
('vi', 'page', 'view_comm', '6'), 
('vi', 'page', 'setcomm', '4'), 
('vi', 'page', 'activecomm', '1'), 
('vi', 'page', 'emailcomm', '0'), 
('vi', 'page', 'adminscomm', ''), 
('vi', 'page', 'sortcomm', '0'), 
('vi', 'page', 'captcha', '1'), 
('vi', 'news', 'tags_remind', '1'), 
('vi', 'news', 'structure_upload', 'Ym'), 
('vi', 'news', 'imgposition', '2'), 
('vi', 'news', 'auto_postcomm', '1'), 
('sys', 'site', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'site', 'site_email', 'info@cujut.vn'), 
('sys', 'global', 'error_send_email', 'taynguyenxanh20@gmail.com'), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'my_domains', '1dieuuoc.com,www.k6ct1.com,www.1dieuuoc.com'), 
('sys', 'global', 'cookie_prefix', 'nv3c_Mgddb'), 
('sys', 'global', 'session_prefix', 'nv3s_S8wkw1'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'lang_multi', '0'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', '_WR0VJ998WA4UBSkN1uZlv1kdFSfffFgOFAUpDdbmZY,'), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('vi', 'news', 'allowed_comm', '-1'), 
('vi', 'news', 'view_comm', '6'), 
('vi', 'news', 'setcomm', '4'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '0'), 
('vi', 'news', 'adminscomm', ''), 
('vi', 'news', 'sortcomm', '0'), 
('vi', 'news', 'captcha', '1'), 
('vi', 'download', 'auto_postcomm', '1'), 
('vi', 'download', 'allowed_comm', '-1'), 
('vi', 'download', 'view_comm', '6'), 
('vi', 'download', 'setcomm', '4'), 
('vi', 'download', 'activecomm', '1'), 
('vi', 'download', 'emailcomm', '0'), 
('vi', 'download', 'adminscomm', ''), 
('vi', 'download', 'sortcomm', '0'), 
('vi', 'download', 'captcha', '1'), 
('vi', 'laws', 'view_type', 'view_listall'), 
('vi', 'laws', 'view_num', '30'), 
('vi', 'laws', 'who_upload', '0'), 
('vi', 'laws', 'groups_view', ''), 
('vi', 'laws', 'status', '0');


-- ---------------------------------------


--
-- Table structure for table `ctypa_cookies`
--

DROP TABLE IF EXISTS `ctypa_cookies`;
CREATE TABLE `ctypa_cookies` (
  `name` varchar(50) NOT NULL DEFAULT '',
  `value` mediumtext NOT NULL,
  `domain` varchar(100) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `secure` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `cookiename` (`name`,`domain`,`path`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_cookies`
--

INSERT INTO `ctypa_cookies` VALUES
('nv3c_vndjsc_ctr', 'NDU4MDMyNTc4LlZO', '.api.nukeviet.vn', '/', 1461833756, 0), 
('nv3c_vndjsc_u_lang', '3KI,', '.api.nukeviet.vn', '/', 1461833756, 0), 
('nv3c_vndjsc_nvvithemever', 'yg,,', '.api.nukeviet.vn', '/', 1461833756, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_counter`
--

DROP TABLE IF EXISTS `ctypa_counter`;
CREATE TABLE `ctypa_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `vi_count` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_counter`
--

INSERT INTO `ctypa_counter` VALUES
('c_time', 'start', 0, 0, 0), 
('c_time', 'last', 0, 1456311258, 0), 
('total', 'hits', 1456311258, 16015, 16015), 
('year', '2015', 1430464053, 38, 38), 
('year', '2016', 1456311258, 15977, 15977), 
('year', '2017', 0, 0, 0), 
('year', '2018', 0, 0, 0), 
('year', '2019', 0, 0, 0), 
('year', '2020', 0, 0, 0), 
('year', '2021', 0, 0, 0), 
('year', '2022', 0, 0, 0), 
('year', '2023', 0, 0, 0), 
('month', 'Jan', 1454258106, 8153, 8153), 
('month', 'Feb', 1456311258, 7824, 7824), 
('month', 'Mar', 0, 0, 0), 
('month', 'Apr', 1430406950, 0, 0), 
('month', 'May', 1430464053, 0, 0), 
('month', 'Jun', 0, 0, 0), 
('month', 'Jul', 0, 0, 0), 
('month', 'Aug', 0, 0, 0), 
('month', 'Sep', 0, 0, 0), 
('month', 'Oct', 0, 0, 0), 
('month', 'Nov', 0, 0, 0), 
('month', 'Dec', 0, 0, 0), 
('day', '01', 1454342070, 1669, 1669), 
('day', '02', 1454431720, 33, 33), 
('day', '03', 1454517357, 41, 41), 
('day', '04', 1454602215, 49, 49), 
('day', '05', 1454685284, 43, 43), 
('day', '06', 1454776632, 35, 35), 
('day', '07', 1454864091, 36, 36), 
('day', '08', 1454949599, 42, 42), 
('day', '09', 1455036101, 283, 283), 
('day', '10', 1455122407, 55, 55), 
('day', '11', 1455209948, 983, 983), 
('day', '12', 1455295122, 50, 50), 
('day', '13', 1455381592, 674, 674), 
('day', '14', 1455467750, 26, 26), 
('day', '15', 1455554468, 256, 256), 
('day', '16', 1455635398, 245, 245), 
('day', '17', 1455728364, 180, 180), 
('day', '18', 1455814317, 318, 318), 
('day', '19', 1455901170, 1615, 1615), 
('day', '20', 1455986890, 288, 288), 
('day', '21', 1456073375, 78, 78), 
('day', '22', 1456158779, 465, 465), 
('day', '23', 1456245132, 258, 258), 
('day', '24', 1456311258, 102, 102), 
('day', '25', 1453739605, 0, 0), 
('day', '26', 1453824054, 0, 0), 
('day', '27', 1453905835, 0, 0), 
('day', '28', 1453998867, 0, 0), 
('day', '29', 1454081981, 0, 0), 
('day', '30', 1454168181, 0, 0), 
('day', '31', 1454258106, 0, 0), 
('dayofweek', 'Sunday', 1456073375, 1519, 1519), 
('dayofweek', 'Monday', 1456158779, 2614, 2614), 
('dayofweek', 'Tuesday', 1456245132, 2042, 2042), 
('dayofweek', 'Wednesday', 1456311258, 2564, 2564), 
('dayofweek', 'Thursday', 1455814317, 3085, 3085), 
('dayofweek', 'Friday', 1455901170, 2181, 2181), 
('dayofweek', 'Saturday', 1455986890, 2010, 2010), 
('hour', '00', 1456247886, 2, 2), 
('hour', '01', 1456253786, 2, 2), 
('hour', '02', 1456257023, 20, 20), 
('hour', '03', 1456260719, 42, 42), 
('hour', '04', 1456264575, 1, 1), 
('hour', '05', 1456267324, 20, 20), 
('hour', '06', 1456098428, 0, 0), 
('hour', '07', 1456274891, 5, 5), 
('hour', '08', 1456278832, 3, 3), 
('hour', '09', 1456107877, 0, 0), 
('hour', '10', 1456285470, 2, 2), 
('hour', '11', 1456288688, 1, 1), 
('hour', '12', 1456031657, 0, 0), 
('hour', '13', 1456210532, 0, 0), 
('hour', '14', 1456299713, 1, 1), 
('hour', '15', 1456303965, 1, 1), 
('hour', '16', 1456220272, 0, 0), 
('hour', '17', 1456311258, 2, 2), 
('hour', '18', 1456225979, 0, 0), 
('hour', '19', 1456056676, 0, 0), 
('hour', '20', 1456234899, 0, 0), 
('hour', '21', 1456236852, 0, 0), 
('hour', '22', 1456153898, 0, 0), 
('hour', '23', 1456245132, 0, 0), 
('bot', 'Alexa', 0, 0, 0), 
('bot', 'AltaVista Scooter', 0, 0, 0), 
('bot', 'Altavista Mercator', 0, 0, 0), 
('bot', 'Altavista Search', 0, 0, 0), 
('bot', 'Aport.ru Bot', 0, 0, 0), 
('bot', 'Ask Jeeves', 0, 0, 0), 
('bot', 'Baidu', 0, 0, 0), 
('bot', 'Exabot', 0, 0, 0), 
('bot', 'FAST Enterprise', 0, 0, 0), 
('bot', 'FAST WebCrawler', 0, 0, 0), 
('bot', 'Francis', 0, 0, 0), 
('bot', 'Gigablast', 0, 0, 0), 
('bot', 'Google AdsBot', 0, 0, 0), 
('bot', 'Google Adsense', 0, 0, 0), 
('bot', 'Google Bot', 1456278832, 739, 739), 
('bot', 'Google Desktop', 0, 0, 0), 
('bot', 'Google Feedfetcher', 0, 0, 0), 
('bot', 'Heise IT-Markt', 0, 0, 0), 
('bot', 'Heritrix', 0, 0, 0), 
('bot', 'IBM Research', 0, 0, 0), 
('bot', 'ICCrawler - ICjobs', 0, 0, 0), 
('bot', 'Ichiro', 0, 0, 0), 
('bot', 'InfoSeek Spider', 0, 0, 0), 
('bot', 'Lycos.com Bot', 0, 0, 0), 
('bot', 'MSN Bot', 1456136094, 48, 48), 
('bot', 'MSN Bot Media', 0, 0, 0), 
('bot', 'MSN Bot News', 0, 0, 0), 
('bot', 'MSN NewsBlogs', 0, 0, 0), 
('bot', 'Majestic-12', 1456274679, 13851, 13851), 
('bot', 'Metager', 0, 0, 0), 
('bot', 'NG-Search', 0, 0, 0), 
('bot', 'Nutch Bot', 0, 0, 0), 
('bot', 'NutchCVS', 0, 0, 0), 
('bot', 'OmniExplorer', 0, 0, 0), 
('bot', 'Online Link Validator', 0, 0, 0), 
('bot', 'Open-source Web Search', 0, 0, 0), 
('bot', 'Psbot', 0, 0, 0), 
('bot', 'Rambler', 0, 0, 0), 
('bot', 'SEO Crawler', 0, 0, 0), 
('bot', 'SEOSearch', 0, 0, 0), 
('bot', 'Seekport', 0, 0, 0), 
('bot', 'Sensis', 0, 0, 0), 
('bot', 'Seoma', 0, 0, 0), 
('bot', 'Snappy', 0, 0, 0), 
('bot', 'Steeler', 0, 0, 0), 
('bot', 'Synoo', 0, 0, 0), 
('bot', 'Telekom', 0, 0, 0), 
('bot', 'TurnitinBot', 0, 0, 0), 
('bot', 'Vietnamese Search', 0, 0, 0), 
('bot', 'Voyager', 0, 0, 0), 
('bot', 'W3 Sitesearch', 0, 0, 0), 
('bot', 'W3C Linkcheck', 0, 0, 0), 
('bot', 'W3C Validator', 0, 0, 0), 
('bot', 'WiseNut', 0, 0, 0), 
('bot', 'YaCy', 0, 0, 0), 
('bot', 'Yahoo Bot', 0, 0, 0), 
('bot', 'Yahoo MMCrawler', 0, 0, 0), 
('bot', 'Yahoo Slurp', 0, 0, 0), 
('bot', 'YahooSeeker', 0, 0, 0), 
('bot', 'Yandex', 0, 0, 0), 
('bot', 'Yandex Blog', 0, 0, 0), 
('bot', 'Yandex Direct Bot', 0, 0, 0), 
('bot', 'Yandex Something', 0, 0, 0), 
('browser', 'netcaptor', 0, 0, 0), 
('browser', 'opera', 1455671462, 3, 3), 
('browser', 'aol', 0, 0, 0), 
('browser', 'aol2', 0, 0, 0), 
('browser', 'mosaic', 0, 0, 0), 
('browser', 'k-meleon', 0, 0, 0), 
('browser', 'konqueror', 0, 0, 0), 
('browser', 'avantbrowser', 0, 0, 0), 
('browser', 'avantgo', 0, 0, 0), 
('browser', 'proxomitron', 0, 0, 0), 
('browser', 'chrome', 1456311258, 202, 202), 
('browser', 'safari', 1455191663, 17, 17), 
('browser', 'lynx', 0, 0, 0), 
('browser', 'links', 0, 0, 0), 
('browser', 'galeon', 0, 0, 0), 
('browser', 'abrowse', 0, 0, 0), 
('browser', 'amaya', 0, 0, 0), 
('browser', 'ant', 0, 0, 0), 
('browser', 'aweb', 0, 0, 0), 
('browser', 'beonex', 0, 0, 0), 
('browser', 'blazer', 0, 0, 0), 
('browser', 'camino', 0, 0, 0), 
('browser', 'chimera', 0, 0, 0), 
('browser', 'columbus', 0, 0, 0), 
('browser', 'crazybrowser', 0, 0, 0), 
('browser', 'curl', 0, 0, 0), 
('browser', 'deepnet', 0, 0, 0), 
('browser', 'dillo', 0, 0, 0), 
('browser', 'doris', 0, 0, 0), 
('browser', 'elinks', 0, 0, 0), 
('browser', 'epiphany', 0, 0, 0), 
('browser', 'ibrowse', 0, 0, 0), 
('browser', 'icab', 0, 0, 0), 
('browser', 'ice', 0, 0, 0), 
('browser', 'isilox', 0, 0, 0), 
('browser', 'lotus', 0, 0, 0), 
('browser', 'lunascape', 0, 0, 0), 
('browser', 'maxthon', 0, 0, 0), 
('browser', 'mbrowser', 0, 0, 0), 
('browser', 'multibrowser', 0, 0, 0), 
('browser', 'nautilus', 0, 0, 0), 
('browser', 'netfront', 0, 0, 0), 
('browser', 'netpositive', 0, 0, 0), 
('browser', 'omniweb', 0, 0, 0), 
('browser', 'oregano', 0, 0, 0), 
('browser', 'phaseout', 0, 0, 0), 
('browser', 'plink', 0, 0, 0), 
('browser', 'phoenix', 0, 0, 0), 
('browser', 'shiira', 0, 0, 0), 
('browser', 'sleipnir', 0, 0, 0), 
('browser', 'slimbrowser', 0, 0, 0), 
('browser', 'staroffice', 0, 0, 0), 
('browser', 'sunrise', 0, 0, 0), 
('browser', 'voyager', 0, 0, 0), 
('browser', 'w3m', 0, 0, 0), 
('browser', 'webtv', 0, 0, 0), 
('browser', 'xiino', 0, 0, 0), 
('browser', 'explorer', 1455565808, 17, 17), 
('browser', 'firefox', 1456299713, 539, 539), 
('browser', 'netscape', 0, 0, 0), 
('browser', 'netscape2', 0, 0, 0), 
('browser', 'mozilla', 1455057424, 3, 3), 
('browser', 'mozilla2', 1456309388, 429, 429), 
('browser', 'firebird', 0, 0, 0), 
('browser', 'Mobile', 1455828158, 37, 37), 
('browser', 'bots', 1456278832, 14603, 14603), 
('browser', 'Unknown', 1456267324, 165, 165), 
('browser', 'Unspecified', 0, 0, 0), 
('os', 'windows8', 1455546656, 1, 1), 
('os', 'windows7', 1456299713, 631, 631), 
('os', 'windowsvista', 0, 0, 0), 
('os', 'windows2003', 1455565808, 10, 10), 
('os', 'windowsxp', 0, 0, 0), 
('os', 'windowsxp2', 1456131096, 19, 19), 
('os', 'windows2k', 0, 0, 0), 
('os', 'windows95', 0, 0, 0), 
('os', 'windowsce', 0, 0, 0), 
('os', 'windowsme', 0, 0, 0), 
('os', 'windowsme2', 0, 0, 0), 
('os', 'windowsnt', 1456311258, 39, 39), 
('os', 'windowsnt2', 1454834556, 5, 5), 
('os', 'windows98', 0, 0, 0), 
('os', 'windows', 0, 0, 0), 
('os', 'linux', 0, 0, 0), 
('os', 'linux2', 1455973715, 17, 17), 
('os', 'linux3', 1454312168, 1, 1), 
('os', 'macosx', 1455728360, 62, 62), 
('os', 'macppc', 0, 0, 0), 
('os', 'mac', 0, 0, 0), 
('os', 'amiga', 0, 0, 0), 
('os', 'beos', 0, 0, 0), 
('os', 'freebsd', 0, 0, 0), 
('os', 'freebsd2', 0, 0, 0), 
('os', 'irix', 0, 0, 0), 
('os', 'netbsd', 0, 0, 0), 
('os', 'netbsd2', 0, 0, 0), 
('os', 'os2', 0, 0, 0), 
('os', 'os22', 0, 0, 0), 
('os', 'openbsd', 0, 0, 0), 
('os', 'openbsd2', 0, 0, 0), 
('os', 'palm', 0, 0, 0), 
('os', 'palm2', 0, 0, 0), 
('os', 'Unspecified', 1456309388, 592, 592), 
('country', 'AD', 0, 0, 0), 
('country', 'AE', 1454834556, 1, 1), 
('country', 'AF', 0, 0, 0), 
('country', 'AG', 0, 0, 0), 
('country', 'AI', 0, 0, 0), 
('country', 'AL', 0, 0, 0), 
('country', 'AM', 0, 0, 0), 
('country', 'AN', 0, 0, 0), 
('country', 'AO', 0, 0, 0), 
('country', 'AQ', 0, 0, 0), 
('country', 'AR', 0, 0, 0), 
('country', 'AS', 0, 0, 0), 
('country', 'AT', 0, 0, 0), 
('country', 'AU', 0, 0, 0), 
('country', 'AW', 0, 0, 0), 
('country', 'AZ', 0, 0, 0), 
('country', 'BA', 0, 0, 0), 
('country', 'BB', 0, 0, 0), 
('country', 'BD', 0, 0, 0), 
('country', 'BE', 1455908126, 1, 1), 
('country', 'BF', 0, 0, 0), 
('country', 'BG', 0, 0, 0), 
('country', 'BH', 0, 0, 0), 
('country', 'BI', 0, 0, 0), 
('country', 'BJ', 0, 0, 0), 
('country', 'BM', 0, 0, 0), 
('country', 'BN', 0, 0, 0), 
('country', 'BO', 0, 0, 0), 
('country', 'BR', 1456236598, 57, 57), 
('country', 'BS', 0, 0, 0), 
('country', 'BT', 0, 0, 0), 
('country', 'BW', 0, 0, 0), 
('country', 'BY', 0, 0, 0), 
('country', 'BZ', 0, 0, 0), 
('country', 'CA', 1455580645, 8, 8), 
('country', 'CD', 0, 0, 0), 
('country', 'CF', 0, 0, 0), 
('country', 'CG', 0, 0, 0), 
('country', 'CH', 0, 0, 0), 
('country', 'CI', 0, 0, 0), 
('country', 'CK', 0, 0, 0), 
('country', 'CL', 0, 0, 0), 
('country', 'CM', 0, 0, 0), 
('country', 'CN', 1456303965, 132, 132), 
('country', 'CO', 1454628310, 1, 1), 
('country', 'CR', 0, 0, 0), 
('country', 'CS', 0, 0, 0), 
('country', 'CU', 0, 0, 0), 
('country', 'CV', 0, 0, 0), 
('country', 'CY', 0, 0, 0), 
('country', 'CZ', 0, 0, 0), 
('country', 'DE', 1456260719, 6724, 6724), 
('country', 'DJ', 0, 0, 0), 
('country', 'DK', 0, 0, 0), 
('country', 'DM', 0, 0, 0), 
('country', 'DO', 1453311219, 1, 1), 
('country', 'DZ', 0, 0, 0), 
('country', 'EC', 0, 0, 0), 
('country', 'EE', 0, 0, 0), 
('country', 'EG', 0, 0, 0), 
('country', 'ER', 0, 0, 0), 
('country', 'ES', 1454846203, 1, 1), 
('country', 'ET', 0, 0, 0), 
('country', 'EU', 0, 0, 0), 
('country', 'FI', 1454285838, 260, 260), 
('country', 'FJ', 0, 0, 0), 
('country', 'FK', 0, 0, 0), 
('country', 'FM', 0, 0, 0), 
('country', 'FO', 0, 0, 0), 
('country', 'FR', 1456191912, 1585, 1585), 
('country', 'GA', 0, 0, 0), 
('country', 'GB', 1456274679, 1639, 1639), 
('country', 'GD', 0, 0, 0), 
('country', 'GE', 0, 0, 0), 
('country', 'GF', 0, 0, 0), 
('country', 'GH', 0, 0, 0), 
('country', 'GI', 0, 0, 0), 
('country', 'GL', 0, 0, 0), 
('country', 'GM', 0, 0, 0), 
('country', 'GN', 0, 0, 0), 
('country', 'GP', 0, 0, 0), 
('country', 'GQ', 0, 0, 0), 
('country', 'GR', 1455611479, 3, 3), 
('country', 'GS', 0, 0, 0), 
('country', 'GT', 0, 0, 0), 
('country', 'GU', 0, 0, 0), 
('country', 'GW', 0, 0, 0), 
('country', 'GY', 0, 0, 0), 
('country', 'HK', 0, 0, 0), 
('country', 'HN', 0, 0, 0), 
('country', 'HR', 0, 0, 0), 
('country', 'HT', 0, 0, 0), 
('country', 'HU', 1453653735, 1, 1), 
('country', 'ID', 0, 0, 0), 
('country', 'IE', 1453281025, 2, 2), 
('country', 'IL', 0, 0, 0), 
('country', 'IN', 1455622889, 8, 8), 
('country', 'IO', 0, 0, 0), 
('country', 'IQ', 0, 0, 0), 
('country', 'IR', 0, 0, 0), 
('country', 'IS', 0, 0, 0), 
('country', 'IT', 1455984458, 647, 647), 
('country', 'JM', 0, 0, 0), 
('country', 'JO', 0, 0, 0), 
('country', 'JP', 1455381592, 1, 1), 
('country', 'KE', 0, 0, 0), 
('country', 'KG', 0, 0, 0), 
('country', 'KH', 0, 0, 0), 
('country', 'KI', 0, 0, 0), 
('country', 'KM', 0, 0, 0), 
('country', 'KN', 0, 0, 0), 
('country', 'KR', 1454735321, 1, 1), 
('country', 'KW', 0, 0, 0), 
('country', 'KY', 0, 0, 0), 
('country', 'KZ', 0, 0, 0), 
('country', 'LA', 0, 0, 0), 
('country', 'LB', 0, 0, 0), 
('country', 'LC', 0, 0, 0), 
('country', 'LI', 0, 0, 0), 
('country', 'LK', 0, 0, 0), 
('country', 'LR', 0, 0, 0), 
('country', 'LS', 0, 0, 0), 
('country', 'LT', 0, 0, 0), 
('country', 'LU', 0, 0, 0), 
('country', 'LV', 0, 0, 0), 
('country', 'LY', 0, 0, 0), 
('country', 'MA', 0, 0, 0), 
('country', 'MC', 0, 0, 0), 
('country', 'MD', 0, 0, 0), 
('country', 'MG', 0, 0, 0), 
('country', 'MH', 0, 0, 0), 
('country', 'MK', 0, 0, 0), 
('country', 'ML', 0, 0, 0), 
('country', 'MM', 0, 0, 0), 
('country', 'MN', 0, 0, 0), 
('country', 'MO', 0, 0, 0), 
('country', 'MP', 0, 0, 0), 
('country', 'MQ', 0, 0, 0), 
('country', 'MR', 0, 0, 0), 
('country', 'MT', 0, 0, 0), 
('country', 'MU', 0, 0, 0), 
('country', 'MV', 0, 0, 0), 
('country', 'MW', 0, 0, 0), 
('country', 'MX', 1454862306, 4, 4), 
('country', 'MY', 0, 0, 0), 
('country', 'MZ', 1455242769, 1, 1), 
('country', 'NA', 0, 0, 0), 
('country', 'NC', 0, 0, 0), 
('country', 'NE', 0, 0, 0), 
('country', 'NF', 0, 0, 0), 
('country', 'NG', 0, 0, 0), 
('country', 'NI', 0, 0, 0), 
('country', 'NL', 1455540703, 196, 196), 
('country', 'NO', 1455843849, 75, 75), 
('country', 'NP', 0, 0, 0), 
('country', 'NR', 0, 0, 0), 
('country', 'NU', 0, 0, 0), 
('country', 'NZ', 0, 0, 0), 
('country', 'OM', 0, 0, 0), 
('country', 'PA', 0, 0, 0), 
('country', 'PE', 1455568000, 2, 2), 
('country', 'PF', 0, 0, 0), 
('country', 'PG', 0, 0, 0), 
('country', 'PH', 1456130875, 1, 1), 
('country', 'PK', 0, 0, 0), 
('country', 'PL', 1455973690, 1, 1), 
('country', 'PR', 1456000563, 1, 1), 
('country', 'PS', 0, 0, 0), 
('country', 'PT', 1455532716, 3, 3), 
('country', 'PW', 0, 0, 0), 
('country', 'PY', 0, 0, 0), 
('country', 'QA', 0, 0, 0), 
('country', 'RE', 0, 0, 0), 
('country', 'RO', 1455984776, 3, 3), 
('country', 'RU', 1455671462, 6, 6), 
('country', 'RW', 0, 0, 0), 
('country', 'SA', 0, 0, 0), 
('country', 'SB', 0, 0, 0), 
('country', 'SC', 0, 0, 0), 
('country', 'SD', 0, 0, 0), 
('country', 'SE', 1456098428, 1, 1), 
('country', 'SG', 1454602215, 1, 1), 
('country', 'SI', 0, 0, 0), 
('country', 'SK', 0, 0, 0), 
('country', 'SL', 0, 0, 0), 
('country', 'SM', 0, 0, 0), 
('country', 'SN', 0, 0, 0), 
('country', 'SO', 0, 0, 0), 
('country', 'SR', 0, 0, 0), 
('country', 'ST', 0, 0, 0), 
('country', 'SV', 0, 0, 0), 
('country', 'SY', 0, 0, 0), 
('country', 'SZ', 0, 0, 0), 
('country', 'TD', 0, 0, 0), 
('country', 'TF', 0, 0, 0), 
('country', 'TG', 0, 0, 0), 
('country', 'TH', 0, 0, 0), 
('country', 'TJ', 0, 0, 0), 
('country', 'TK', 0, 0, 0), 
('country', 'TL', 0, 0, 0), 
('country', 'TM', 0, 0, 0), 
('country', 'TN', 0, 0, 0), 
('country', 'TO', 0, 0, 0), 
('country', 'TR', 0, 0, 0), 
('country', 'TT', 0, 0, 0), 
('country', 'TV', 0, 0, 0), 
('country', 'TW', 0, 0, 0), 
('country', 'TZ', 0, 0, 0), 
('country', 'UA', 1455816910, 249, 249), 
('country', 'UG', 0, 0, 0), 
('country', 'US', 1456309388, 3290, 3290), 
('country', 'UY', 1455561656, 1, 1), 
('country', 'UZ', 0, 0, 0), 
('country', 'VA', 0, 0, 0), 
('country', 'VC', 0, 0, 0), 
('country', 'VE', 0, 0, 0), 
('country', 'VG', 0, 0, 0), 
('country', 'VI', 0, 0, 0), 
('country', 'VN', 1456311258, 565, 565), 
('country', 'VU', 0, 0, 0), 
('country', 'WS', 0, 0, 0), 
('country', 'YE', 0, 0, 0), 
('country', 'YT', 0, 0, 0), 
('country', 'YU', 0, 0, 0), 
('country', 'ZA', 0, 0, 0), 
('country', 'ZM', 0, 0, 0), 
('country', 'ZW', 0, 0, 0), 
('country', 'ZZ', 1456267319, 542, 542), 
('country', 'unkown', 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_cronjobs`
--

DROP TABLE IF EXISTS `ctypa_cronjobs`;
CREATE TABLE `ctypa_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `inter_val` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) DEFAULT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_cronjobs`
--

INSERT INTO `ctypa_cronjobs` VALUES
(1, 1430288935, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1456311259, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1430288935, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1456131096, 1, 'Tự động lưu CSDL'), 
(3, 1430288935, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1456131096, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1430288935, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1456131096, 1, 'Xóa IP log files, Xóa các file nhật ký truy cập'), 
(5, 1430288935, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1456131096, 1, 'Xóa các file error_log quá hạn'), 
(6, 1430288935, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1430288935, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1456131096, 1, 'Xóa các referer quá hạn'), 
(8, 1430288935, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 0, 1, 1456131096, 1, 'Cập nhật đánh giá site từ các máy chủ tìm kiếm'), 
(9, 1430288935, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1456131096, 1, 'Kiểm tra phiên bản NukeViet'), 
(10, 1430288935, 1440, 'notification_autodel.php', 'cron_notification_autodel', '', 0, 1, 1, 1456131096, 1, 'Xóa thông báo cũ');


-- ---------------------------------------


--
-- Table structure for table `ctypa_extension_files`
--

DROP TABLE IF EXISTS `ctypa_extension_files`;
CREATE TABLE `ctypa_extension_files` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL DEFAULT 'other',
  `title` varchar(55) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `lastmodified` int(11) unsigned NOT NULL DEFAULT '0',
  `duplicate` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idfile`)
) ENGINE=MyISAM  AUTO_INCREMENT=729  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_extension_files`
--

INSERT INTO `ctypa_extension_files` VALUES
(1, 'module', 'contact', 'modules/contact/action_mysql.php', 1430288935, 0), 
(2, 'module', 'contact', 'modules/contact/action_oci.php', 1430288935, 0), 
(3, 'module', 'contact', 'modules/contact/admin/change_status.php', 1430288935, 0), 
(4, 'module', 'contact', 'modules/contact/admin/content.php', 1430288935, 0), 
(5, 'module', 'contact', 'modules/contact/admin/del.php', 1430288935, 0), 
(6, 'module', 'contact', 'modules/contact/admin/del_department.php', 1430288935, 0), 
(7, 'module', 'contact', 'modules/contact/admin/department.php', 1430288935, 0), 
(8, 'module', 'contact', 'modules/contact/admin/index.html', 1430288935, 0), 
(9, 'module', 'contact', 'modules/contact/admin/main.php', 1430288935, 0), 
(10, 'module', 'contact', 'modules/contact/admin/reply.php', 1430288935, 0), 
(11, 'module', 'contact', 'modules/contact/admin/row.php', 1430288935, 0), 
(12, 'module', 'contact', 'modules/contact/admin/view.php', 1430288935, 0), 
(13, 'module', 'contact', 'modules/contact/admin.functions.php', 1430288935, 0), 
(14, 'module', 'contact', 'modules/contact/admin.menu.php', 1430288935, 0), 
(15, 'module', 'contact', 'modules/contact/blocks/global.department.ini', 1430288935, 0), 
(16, 'module', 'contact', 'modules/contact/blocks/global.department.php', 1430288935, 0), 
(17, 'module', 'contact', 'modules/contact/funcs/index.html', 1430288935, 0), 
(18, 'module', 'contact', 'modules/contact/funcs/main.php', 1430288935, 0), 
(19, 'module', 'contact', 'modules/contact/functions.php', 1430288935, 0), 
(20, 'module', 'contact', 'modules/contact/index.html', 1430288935, 0), 
(21, 'module', 'contact', 'modules/contact/js/admin.js', 1430288935, 0), 
(22, 'module', 'contact', 'modules/contact/js/index.html', 1430288935, 0), 
(23, 'module', 'contact', 'modules/contact/js/user.js', 1430288935, 0), 
(24, 'module', 'contact', 'modules/contact/language/admin_en.php', 1430288935, 0), 
(25, 'module', 'contact', 'modules/contact/language/admin_vi.php', 1430288935, 0), 
(26, 'module', 'contact', 'modules/contact/language/en.php', 1430288935, 0), 
(27, 'module', 'contact', 'modules/contact/language/index.html', 1430288935, 0), 
(28, 'module', 'contact', 'modules/contact/language/vi.php', 1430288935, 0), 
(29, 'module', 'contact', 'modules/contact/menu.php', 1430288935, 0), 
(30, 'module', 'contact', 'modules/contact/siteinfo.php', 1430288935, 0), 
(31, 'module', 'contact', 'modules/contact/theme.php', 1430288935, 0), 
(32, 'module', 'contact', 'modules/contact/version.php', 1430288935, 0), 
(33, 'module', 'contact', 'themes/admin_default/modules/contact/content.tpl', 1430288935, 0), 
(34, 'module', 'contact', 'themes/admin_default/modules/contact/department.tpl', 1430288935, 0), 
(35, 'module', 'contact', 'themes/admin_default/modules/contact/index.html', 1430288935, 0), 
(36, 'module', 'contact', 'themes/admin_default/modules/contact/main.tpl', 1430288935, 0), 
(37, 'module', 'contact', 'themes/admin_default/modules/contact/reply.tpl', 1430288935, 0), 
(38, 'module', 'contact', 'themes/admin_default/modules/contact/row.tpl', 1430288935, 0), 
(39, 'module', 'contact', 'themes/admin_default/modules/contact/view.tpl', 1430288935, 0), 
(40, 'module', 'contact', 'themes/default/modules/contact/block.department.tpl', 1430288935, 0), 
(41, 'module', 'contact', 'themes/default/modules/contact/form.tpl', 1430288935, 0), 
(42, 'module', 'contact', 'themes/default/modules/contact/index.html', 1430288935, 0), 
(43, 'module', 'contact', 'themes/default/modules/contact/sendcontact.tpl', 1430288935, 0), 
(44, 'module', 'contact', 'themes/modern/modules/contact/form.tpl', 1430288935, 0), 
(45, 'module', 'contact', 'themes/modern/modules/contact/index.html', 1430288935, 0), 
(46, 'module', 'contact', 'themes/modern/modules/contact/sendcontact.tpl', 1430288935, 0), 
(47, 'module', 'contact', 'themes/admin_default/css/contact.css', 1430288935, 0), 
(48, 'module', 'contact', 'themes/modern/css/contact.css', 1430288935, 0), 
(49, 'module', 'news', 'modules/news/action_mysql.php', 1430288935, 0), 
(50, 'module', 'news', 'modules/news/action_oci.php', 1430288935, 0), 
(51, 'module', 'news', 'modules/news/admin/addtotopics.php', 1430288935, 0), 
(52, 'module', 'news', 'modules/news/admin/alias.php', 1430288935, 0), 
(53, 'module', 'news', 'modules/news/admin/block.php', 1430288935, 0), 
(54, 'module', 'news', 'modules/news/admin/cat.php', 1430288935, 0), 
(55, 'module', 'news', 'modules/news/admin/chang_block_cat.php', 1430288935, 0), 
(56, 'module', 'news', 'modules/news/admin/change_block.php', 1430288935, 0), 
(57, 'module', 'news', 'modules/news/admin/change_cat.php', 1430288935, 0), 
(58, 'module', 'news', 'modules/news/admin/change_source.php', 1430288935, 0), 
(59, 'module', 'news', 'modules/news/admin/change_topic.php', 1430288935, 0), 
(60, 'module', 'news', 'modules/news/admin/content.php', 1430288935, 0), 
(61, 'module', 'news', 'modules/news/admin/declined.php', 1430288935, 0), 
(62, 'module', 'news', 'modules/news/admin/del_block_cat.php', 1430288935, 0), 
(63, 'module', 'news', 'modules/news/admin/del_cat.php', 1430288935, 0), 
(64, 'module', 'news', 'modules/news/admin/del_content.php', 1430288935, 0), 
(65, 'module', 'news', 'modules/news/admin/del_source.php', 1430288935, 0), 
(66, 'module', 'news', 'modules/news/admin/del_topic.php', 1430288935, 0), 
(67, 'module', 'news', 'modules/news/admin/exptime.php', 1430288935, 0), 
(68, 'module', 'news', 'modules/news/admin/groups.php', 1430288935, 0), 
(69, 'module', 'news', 'modules/news/admin/index.html', 1430288935, 0), 
(70, 'module', 'news', 'modules/news/admin/list_block.php', 1430288935, 0), 
(71, 'module', 'news', 'modules/news/admin/list_block_cat.php', 1430288935, 0), 
(72, 'module', 'news', 'modules/news/admin/list_cat.php', 1430288935, 0), 
(73, 'module', 'news', 'modules/news/admin/list_source.php', 1430288935, 0), 
(74, 'module', 'news', 'modules/news/admin/list_topic.php', 1430288935, 0), 
(75, 'module', 'news', 'modules/news/admin/main.php', 1430288935, 0), 
(76, 'module', 'news', 'modules/news/admin/publtime.php', 1430288935, 0), 
(77, 'module', 'news', 'modules/news/admin/re-published.php', 1430288935, 0), 
(78, 'module', 'news', 'modules/news/admin/rpc.php', 1430288935, 0), 
(79, 'module', 'news', 'modules/news/admin/setting.php', 1430288935, 0), 
(80, 'module', 'news', 'modules/news/admin/sourceajax.php', 1430288935, 0), 
(81, 'module', 'news', 'modules/news/admin/sources.php', 1430288935, 0), 
(82, 'module', 'news', 'modules/news/admin/tags.php', 1430288935, 0), 
(83, 'module', 'news', 'modules/news/admin/tagsajax.php', 1430288935, 0), 
(84, 'module', 'news', 'modules/news/admin/tools.php', 1430288935, 0), 
(85, 'module', 'news', 'modules/news/admin/topicajax.php', 1430288935, 0), 
(86, 'module', 'news', 'modules/news/admin/topicdelnews.php', 1430288935, 0), 
(87, 'module', 'news', 'modules/news/admin/topics.php', 1430288935, 0), 
(88, 'module', 'news', 'modules/news/admin/topicsnews.php', 1430288935, 0), 
(89, 'module', 'news', 'modules/news/admin/view.php', 1430288935, 0), 
(90, 'module', 'news', 'modules/news/admin/waiting.php', 1430288935, 0), 
(91, 'module', 'news', 'modules/news/admin.functions.php', 1430288935, 0), 
(92, 'module', 'news', 'modules/news/admin.menu.php', 1430288935, 0), 
(93, 'module', 'news', 'modules/news/blocks/global.block_category.ini', 1430288935, 0), 
(94, 'module', 'news', 'modules/news/blocks/global.block_category.php', 1430288935, 0), 
(95, 'module', 'news', 'modules/news/blocks/global.block_groups.ini', 1430288935, 0), 
(96, 'module', 'news', 'modules/news/blocks/global.block_groups.php', 1430288935, 0), 
(97, 'module', 'news', 'modules/news/blocks/global.block_news_cat.ini', 1430288935, 0), 
(98, 'module', 'news', 'modules/news/blocks/global.block_news_cat.php', 1430288935, 0), 
(99, 'module', 'news', 'modules/news/blocks/global.block_tophits.ini', 1430288935, 0), 
(100, 'module', 'news', 'modules/news/blocks/global.block_tophits.php', 1430288935, 0), 
(101, 'module', 'news', 'modules/news/blocks/index.html', 1430288935, 0), 
(102, 'module', 'news', 'modules/news/blocks/module.block_content.php', 1430288935, 0), 
(103, 'module', 'news', 'modules/news/blocks/module.block_headline.ini', 1430288935, 0), 
(104, 'module', 'news', 'modules/news/blocks/module.block_headline.php', 1430288935, 0), 
(105, 'module', 'news', 'modules/news/blocks/module.block_news.ini', 1430288935, 0), 
(106, 'module', 'news', 'modules/news/blocks/module.block_news.php', 1430288935, 0), 
(107, 'module', 'news', 'modules/news/blocks/module.block_newscenter.ini', 1430288935, 0), 
(108, 'module', 'news', 'modules/news/blocks/module.block_newscenter.php', 1430288935, 0), 
(109, 'module', 'news', 'modules/news/comment.php', 1430288935, 0), 
(110, 'module', 'news', 'modules/news/funcs/content.php', 1430288935, 0), 
(111, 'module', 'news', 'modules/news/funcs/detail.php', 1430288935, 0), 
(112, 'module', 'news', 'modules/news/funcs/groups.php', 1430288935, 0), 
(113, 'module', 'news', 'modules/news/funcs/index.html', 1430288935, 0), 
(114, 'module', 'news', 'modules/news/funcs/main.php', 1430288935, 0), 
(115, 'module', 'news', 'modules/news/funcs/print.php', 1430288935, 0), 
(116, 'module', 'news', 'modules/news/funcs/rating.php', 1430288935, 0), 
(117, 'module', 'news', 'modules/news/funcs/rss.php', 1430288935, 0), 
(118, 'module', 'news', 'modules/news/funcs/savefile.php', 1430288935, 0), 
(119, 'module', 'news', 'modules/news/funcs/search.php', 1430288935, 0), 
(120, 'module', 'news', 'modules/news/funcs/sendmail.php', 1430288935, 0), 
(121, 'module', 'news', 'modules/news/funcs/sitemap.php', 1430288935, 0), 
(122, 'module', 'news', 'modules/news/funcs/tag.php', 1430288935, 0), 
(123, 'module', 'news', 'modules/news/funcs/topic.php', 1430288935, 0), 
(124, 'module', 'news', 'modules/news/funcs/viewcat.php', 1430288935, 0), 
(125, 'module', 'news', 'modules/news/functions.php', 1430288935, 0), 
(126, 'module', 'news', 'modules/news/global.functions.php', 1430288935, 0), 
(127, 'module', 'news', 'modules/news/index.html', 1430288935, 0), 
(128, 'module', 'news', 'modules/news/js/admin.js', 1430288935, 0), 
(129, 'module', 'news', 'modules/news/js/content.js', 1430288935, 0), 
(130, 'module', 'news', 'modules/news/js/index.html', 1430288935, 0), 
(131, 'module', 'news', 'modules/news/js/user.js', 1430288935, 0), 
(132, 'module', 'news', 'modules/news/language/admin_en.php', 1430288935, 0), 
(133, 'module', 'news', 'modules/news/language/admin_vi.php', 1430288935, 0), 
(134, 'module', 'news', 'modules/news/language/block.global.block_category_en.php', 1430288935, 0), 
(135, 'module', 'news', 'modules/news/language/block.global.block_category_vi.php', 1430288935, 0), 
(136, 'module', 'news', 'modules/news/language/block.global.block_groups_en.php', 1430288935, 0), 
(137, 'module', 'news', 'modules/news/language/block.global.block_groups_vi.php', 1430288935, 0), 
(138, 'module', 'news', 'modules/news/language/block.global.block_news_cat_en.php', 1430288935, 0), 
(139, 'module', 'news', 'modules/news/language/block.global.block_news_cat_vi.php', 1430288935, 0), 
(140, 'module', 'news', 'modules/news/language/block.global.block_tophits_en.php', 1430288935, 0), 
(141, 'module', 'news', 'modules/news/language/block.global.block_tophits_vi.php', 1430288935, 0), 
(142, 'module', 'news', 'modules/news/language/block.module.block_headline_en.php', 1430288935, 0), 
(143, 'module', 'news', 'modules/news/language/block.module.block_headline_vi.php', 1430288935, 0), 
(144, 'module', 'news', 'modules/news/language/block.module.block_news_en.php', 1430288935, 0), 
(145, 'module', 'news', 'modules/news/language/block.module.block_news_vi.php', 1430288935, 0), 
(146, 'module', 'news', 'modules/news/language/block.module.block_newscenter_en.php', 1430288935, 0), 
(147, 'module', 'news', 'modules/news/language/block.module.block_newscenter_vi.php', 1430288935, 0), 
(148, 'module', 'news', 'modules/news/language/en.php', 1430288935, 0), 
(149, 'module', 'news', 'modules/news/language/index.html', 1430288935, 0), 
(150, 'module', 'news', 'modules/news/language/vi.php', 1430288935, 0), 
(151, 'module', 'news', 'modules/news/menu.php', 1430288935, 0), 
(152, 'module', 'news', 'modules/news/mobile/index.html', 1430288935, 0), 
(153, 'module', 'news', 'modules/news/rssdata.php', 1430288935, 0), 
(154, 'module', 'news', 'modules/news/search.php', 1430288935, 0), 
(155, 'module', 'news', 'modules/news/siteinfo.php', 1430288935, 0), 
(156, 'module', 'news', 'modules/news/theme.php', 1430288935, 0), 
(157, 'module', 'news', 'modules/news/version.php', 1430288935, 0), 
(158, 'module', 'news', 'themes/admin_default/modules/news/addtotopics.tpl', 1430288935, 0), 
(159, 'module', 'news', 'themes/admin_default/modules/news/block.tpl', 1430288935, 0), 
(160, 'module', 'news', 'themes/admin_default/modules/news/block_list.tpl', 1430288935, 0), 
(161, 'module', 'news', 'themes/admin_default/modules/news/blockcat_lists.tpl', 1430288935, 0), 
(162, 'module', 'news', 'themes/admin_default/modules/news/cat.tpl', 1430288935, 0), 
(163, 'module', 'news', 'themes/admin_default/modules/news/cat_list.tpl', 1430288935, 0), 
(164, 'module', 'news', 'themes/admin_default/modules/news/content.tpl', 1430288935, 0), 
(165, 'module', 'news', 'themes/admin_default/modules/news/del_cat.tpl', 1430288935, 0), 
(166, 'module', 'news', 'themes/admin_default/modules/news/groups.tpl', 1430288935, 0), 
(167, 'module', 'news', 'themes/admin_default/modules/news/index.html', 1430288935, 0), 
(168, 'module', 'news', 'themes/admin_default/modules/news/main.tpl', 1430288935, 0), 
(169, 'module', 'news', 'themes/admin_default/modules/news/redriect.tpl', 1430288935, 0), 
(170, 'module', 'news', 'themes/admin_default/modules/news/settings.tpl', 1430288935, 0), 
(171, 'module', 'news', 'themes/admin_default/modules/news/sources.tpl', 1430288935, 0), 
(172, 'module', 'news', 'themes/admin_default/modules/news/sources_list.tpl', 1430288935, 0), 
(173, 'module', 'news', 'themes/admin_default/modules/news/tags.tpl', 1430288935, 0), 
(174, 'module', 'news', 'themes/admin_default/modules/news/tags_lists.tpl', 1430288935, 0), 
(175, 'module', 'news', 'themes/admin_default/modules/news/tools.tpl', 1430288935, 0), 
(176, 'module', 'news', 'themes/admin_default/modules/news/topics.tpl', 1430288935, 0), 
(177, 'module', 'news', 'themes/admin_default/modules/news/topics_list.tpl', 1430288935, 0), 
(178, 'module', 'news', 'themes/admin_default/modules/news/topicsnews.tpl', 1430288935, 0), 
(179, 'module', 'news', 'themes/default/images/news/index.html', 1430288935, 0), 
(180, 'module', 'news', 'themes/default/images/news/new.gif', 1430288935, 0), 
(181, 'module', 'news', 'themes/default/modules/news/block_category.tpl', 1430288935, 0), 
(182, 'module', 'news', 'themes/default/modules/news/block_content.tpl', 1430288935, 0), 
(183, 'module', 'news', 'themes/default/modules/news/block_groups.tpl', 1430288935, 0), 
(184, 'module', 'news', 'themes/default/modules/news/block_headline.tpl', 1430288935, 0), 
(185, 'module', 'news', 'themes/default/modules/news/block_news.tpl', 1430288935, 0), 
(186, 'module', 'news', 'themes/default/modules/news/block_newscenter.tpl', 1430288935, 0), 
(187, 'module', 'news', 'themes/default/modules/news/content.tpl', 1430288935, 0), 
(188, 'module', 'news', 'themes/default/modules/news/detail.tpl', 1430288935, 0), 
(189, 'module', 'news', 'themes/default/modules/news/index.html', 1430288935, 0), 
(190, 'module', 'news', 'themes/default/modules/news/print.tpl', 1430288935, 0), 
(191, 'module', 'news', 'themes/default/modules/news/search.tpl', 1430288935, 0), 
(192, 'module', 'news', 'themes/default/modules/news/sendmail.tpl', 1430288935, 0), 
(193, 'module', 'news', 'themes/default/modules/news/topic.tpl', 1430288935, 0), 
(194, 'module', 'news', 'themes/default/modules/news/viewcat_grid.tpl', 1430288935, 0), 
(195, 'module', 'news', 'themes/default/modules/news/viewcat_list.tpl', 1430288935, 0), 
(196, 'module', 'news', 'themes/default/modules/news/viewcat_main_bottom.tpl', 1430288935, 0), 
(197, 'module', 'news', 'themes/default/modules/news/viewcat_main_left.tpl', 1430288935, 0), 
(198, 'module', 'news', 'themes/default/modules/news/viewcat_main_right.tpl', 1430288935, 0), 
(199, 'module', 'news', 'themes/default/modules/news/viewcat_page.tpl', 1430288935, 0), 
(200, 'module', 'news', 'themes/default/modules/news/viewcat_top.tpl', 1430288935, 0), 
(201, 'module', 'news', 'themes/default/modules/news/viewcat_two_column.tpl', 1430288935, 0), 
(202, 'module', 'news', 'themes/modern/images/news/index.html', 1430288935, 0), 
(203, 'module', 'news', 'themes/modern/images/news/new.gif', 1430288935, 0), 
(204, 'module', 'news', 'themes/modern/modules/news/block_category.tpl', 1430288935, 0), 
(205, 'module', 'news', 'themes/modern/modules/news/block_groups.tpl', 1430288935, 0), 
(206, 'module', 'news', 'themes/modern/modules/news/block_headline.tpl', 1430288935, 0), 
(207, 'module', 'news', 'themes/modern/modules/news/block_news.tpl', 1430288935, 0), 
(208, 'module', 'news', 'themes/modern/modules/news/block_newscenter.tpl', 1430288935, 0), 
(209, 'module', 'news', 'themes/modern/modules/news/block_newsright.tpl', 1430288935, 0), 
(210, 'module', 'news', 'themes/modern/modules/news/content.tpl', 1430288935, 0), 
(211, 'module', 'news', 'themes/modern/modules/news/detail.tpl', 1430288935, 0), 
(212, 'module', 'news', 'themes/modern/modules/news/index.html', 1430288935, 0), 
(213, 'module', 'news', 'themes/modern/modules/news/print.tpl', 1430288935, 0), 
(214, 'module', 'news', 'themes/modern/modules/news/search.tpl', 1430288935, 0), 
(215, 'module', 'news', 'themes/modern/modules/news/sendmail.tpl', 1430288935, 0), 
(216, 'module', 'news', 'themes/modern/modules/news/theme.php', 1430288935, 0), 
(217, 'module', 'news', 'themes/modern/modules/news/topic.tpl', 1430288935, 0), 
(218, 'module', 'news', 'themes/modern/modules/news/viewcat_grid.tpl', 1430288935, 0), 
(219, 'module', 'news', 'themes/modern/modules/news/viewcat_list.tpl', 1430288935, 0), 
(220, 'module', 'news', 'themes/modern/modules/news/viewcat_main_bottom.tpl', 1430288935, 0), 
(221, 'module', 'news', 'themes/modern/modules/news/viewcat_main_left.tpl', 1430288935, 0), 
(222, 'module', 'news', 'themes/modern/modules/news/viewcat_main_right.tpl', 1430288935, 0), 
(223, 'module', 'news', 'themes/modern/modules/news/viewcat_page.tpl', 1430288935, 0), 
(224, 'module', 'news', 'themes/modern/modules/news/viewcat_top.tpl', 1430288935, 0), 
(225, 'module', 'news', 'themes/modern/modules/news/viewcat_two_column.tpl', 1430288935, 0), 
(226, 'module', 'news', 'themes/mobile_nukeviet/images/news/email.png', 1430288935, 0), 
(227, 'module', 'news', 'themes/mobile_nukeviet/images/news/index.html', 1430288935, 0), 
(228, 'module', 'news', 'themes/mobile_nukeviet/images/news/new.gif', 1430288935, 0), 
(229, 'module', 'news', 'themes/mobile_nukeviet/images/news/print.png', 1430288935, 0), 
(230, 'module', 'news', 'themes/mobile_nukeviet/images/news/save.png', 1430288935, 0), 
(231, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_blocknews.tpl', 1430288935, 0), 
(232, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_category.tpl', 1430288935, 0), 
(233, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_content.tpl', 1430288935, 0), 
(234, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_headline.tpl', 1430288935, 0), 
(235, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_news.tpl', 1430288935, 0), 
(236, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_newscenter.tpl', 1430288935, 0), 
(237, 'module', 'news', 'themes/mobile_nukeviet/modules/news/content.tpl', 1430288935, 0), 
(238, 'module', 'news', 'themes/mobile_nukeviet/modules/news/detail.tpl', 1430288935, 0), 
(239, 'module', 'news', 'themes/mobile_nukeviet/modules/news/index.html', 1430288935, 0), 
(240, 'module', 'news', 'themes/mobile_nukeviet/modules/news/print.tpl', 1430288935, 0), 
(241, 'module', 'news', 'themes/mobile_nukeviet/modules/news/search.tpl', 1430288935, 0), 
(242, 'module', 'news', 'themes/mobile_nukeviet/modules/news/sendmail.tpl', 1430288935, 0), 
(243, 'module', 'news', 'themes/mobile_nukeviet/modules/news/theme.php', 1430288935, 0), 
(244, 'module', 'news', 'themes/mobile_nukeviet/modules/news/topic.tpl', 1430288935, 0), 
(245, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_grid.tpl', 1430288935, 0), 
(246, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_list.tpl', 1430288935, 0), 
(247, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_main_bottom.tpl', 1430288935, 0), 
(248, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_page.tpl', 1430288935, 0), 
(249, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_top.tpl', 1430288935, 0), 
(250, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_two_column.tpl', 1430288935, 0), 
(251, 'module', 'news', 'themes/admin_default/css/news.css', 1430288935, 0), 
(252, 'module', 'news', 'themes/default/css/news.css', 1430288935, 0), 
(253, 'module', 'news', 'themes/modern/css/news.css', 1430288935, 0), 
(254, 'module', 'voting', 'modules/voting/action_mysql.php', 1430288935, 0), 
(255, 'module', 'voting', 'modules/voting/action_oci.php', 1430288935, 0), 
(256, 'module', 'voting', 'modules/voting/admin/content.php', 1430288935, 0), 
(257, 'module', 'voting', 'modules/voting/admin/del.php', 1430288935, 0), 
(258, 'module', 'voting', 'modules/voting/admin/index.html', 1430288935, 0), 
(259, 'module', 'voting', 'modules/voting/admin/main.php', 1430288935, 0), 
(260, 'module', 'voting', 'modules/voting/admin.functions.php', 1430288935, 0), 
(261, 'module', 'voting', 'modules/voting/admin.menu.php', 1430288935, 0), 
(262, 'module', 'voting', 'modules/voting/blocks/global.voting.ini', 1430288935, 0), 
(263, 'module', 'voting', 'modules/voting/blocks/global.voting.php', 1430288935, 0), 
(264, 'module', 'voting', 'modules/voting/blocks/global.voting_random.php', 1430288935, 0), 
(265, 'module', 'voting', 'modules/voting/blocks/index.html', 1430288935, 0), 
(266, 'module', 'voting', 'modules/voting/funcs/index.html', 1430288935, 0), 
(267, 'module', 'voting', 'modules/voting/funcs/main.php', 1430288935, 0), 
(268, 'module', 'voting', 'modules/voting/functions.php', 1430288935, 0), 
(269, 'module', 'voting', 'modules/voting/index.html', 1430288935, 0), 
(270, 'module', 'voting', 'modules/voting/js/admin.js', 1430288935, 0), 
(271, 'module', 'voting', 'modules/voting/js/index.html', 1430288935, 0), 
(272, 'module', 'voting', 'modules/voting/js/user.js', 1430288935, 0), 
(273, 'module', 'voting', 'modules/voting/language/admin_en.php', 1430288935, 0), 
(274, 'module', 'voting', 'modules/voting/language/admin_vi.php', 1430288935, 0), 
(275, 'module', 'voting', 'modules/voting/language/en.php', 1430288935, 0), 
(276, 'module', 'voting', 'modules/voting/language/index.html', 1430288935, 0), 
(277, 'module', 'voting', 'modules/voting/language/vi.php', 1430288935, 0), 
(278, 'module', 'voting', 'modules/voting/theme.php', 1430288935, 0), 
(279, 'module', 'voting', 'modules/voting/version.php', 1430288935, 0), 
(280, 'module', 'voting', 'themes/admin_default/modules/voting/content.tpl', 1430288935, 0), 
(281, 'module', 'voting', 'themes/admin_default/modules/voting/index.html', 1430288935, 0), 
(282, 'module', 'voting', 'themes/admin_default/modules/voting/main.tpl', 1430288935, 0), 
(283, 'module', 'voting', 'themes/default/modules/voting/global.voting.tpl', 1430288935, 0), 
(284, 'module', 'voting', 'themes/default/modules/voting/index.html', 1430288935, 0), 
(285, 'module', 'voting', 'themes/default/modules/voting/main.tpl', 1430288935, 0), 
(286, 'module', 'voting', 'themes/default/modules/voting/result.voting.tpl', 1430288935, 0), 
(287, 'module', 'voting', 'themes/modern/modules/voting/global.voting.tpl', 1430288935, 0), 
(288, 'module', 'voting', 'themes/modern/modules/voting/index.html', 1430288935, 0), 
(289, 'module', 'voting', 'themes/modern/modules/voting/main.tpl', 1430288935, 0), 
(290, 'module', 'voting', 'themes/modern/modules/voting/result.voting.tpl', 1430288935, 0), 
(291, 'module', 'voting', 'themes/admin_default/css/voting.css', 1430288935, 0), 
(292, 'module', 'download', 'modules/download/action_mysql.php', 1430288935, 0), 
(293, 'module', 'download', 'modules/download/action_oci.php', 1430288935, 0), 
(294, 'module', 'download', 'modules/download/admin/add.php', 1430288935, 0), 
(295, 'module', 'download', 'modules/download/admin/cat.php', 1430288935, 0), 
(296, 'module', 'download', 'modules/download/admin/config.php', 1430288935, 0), 
(297, 'module', 'download', 'modules/download/admin/filequeue.php', 1430288935, 0), 
(298, 'module', 'download', 'modules/download/admin/index.html', 1430288935, 0), 
(299, 'module', 'download', 'modules/download/admin/main.php', 1430288935, 0), 
(300, 'module', 'download', 'modules/download/admin/report.php', 1430288935, 0), 
(301, 'module', 'download', 'modules/download/admin/view.php', 1430288935, 0), 
(302, 'module', 'download', 'modules/download/admin.functions.php', 1430288935, 0), 
(303, 'module', 'download', 'modules/download/admin.menu.php', 1430288935, 0), 
(304, 'module', 'download', 'modules/download/blocks/global.new_files.ini', 1430288935, 0), 
(305, 'module', 'download', 'modules/download/blocks/global.new_files.php', 1430288935, 0), 
(306, 'module', 'download', 'modules/download/blocks/global.search.php', 1430288935, 0), 
(307, 'module', 'download', 'modules/download/blocks/global.upload.php', 1430288935, 0), 
(308, 'module', 'download', 'modules/download/blocks/index.html', 1430288935, 0), 
(309, 'module', 'download', 'modules/download/blocks/module.block_category.php', 1430288935, 0), 
(310, 'module', 'download', 'modules/download/blocks/module.block_lastestdownload.php', 1430288935, 0), 
(311, 'module', 'download', 'modules/download/blocks/module.block_topdownload.php', 1430288935, 0), 
(312, 'module', 'download', 'modules/download/comment.php', 1430288935, 0), 
(313, 'module', 'download', 'modules/download/funcs/down.php', 1430288935, 0), 
(314, 'module', 'download', 'modules/download/funcs/index.html', 1430288935, 0), 
(315, 'module', 'download', 'modules/download/funcs/main.php', 1430288935, 0), 
(316, 'module', 'download', 'modules/download/funcs/report.php', 1430288935, 0), 
(317, 'module', 'download', 'modules/download/funcs/rss.php', 1430288935, 0), 
(318, 'module', 'download', 'modules/download/funcs/search.php', 1430288935, 0), 
(319, 'module', 'download', 'modules/download/funcs/sitemap.php', 1430288935, 0), 
(320, 'module', 'download', 'modules/download/funcs/upload.php', 1430288935, 0), 
(321, 'module', 'download', 'modules/download/funcs/viewcat.php', 1430288935, 0), 
(322, 'module', 'download', 'modules/download/funcs/viewfile.php', 1430288935, 0), 
(323, 'module', 'download', 'modules/download/functions.php', 1430288935, 0), 
(324, 'module', 'download', 'modules/download/index.html', 1430288935, 0), 
(325, 'module', 'download', 'modules/download/js/admin.js', 1430288935, 0), 
(326, 'module', 'download', 'modules/download/js/index.html', 1430288935, 0), 
(327, 'module', 'download', 'modules/download/js/user.js', 1430288935, 0), 
(328, 'module', 'download', 'modules/download/language/admin_en.php', 1430288935, 0), 
(329, 'module', 'download', 'modules/download/language/admin_vi.php', 1430288935, 0), 
(330, 'module', 'download', 'modules/download/language/block.global.new_files_en.php', 1430288935, 0), 
(331, 'module', 'download', 'modules/download/language/block.global.new_files_vi.php', 1430288935, 0), 
(332, 'module', 'download', 'modules/download/language/en.php', 1430288935, 0), 
(333, 'module', 'download', 'modules/download/language/index.html', 1430288935, 0), 
(334, 'module', 'download', 'modules/download/language/vi.php', 1430288935, 0), 
(335, 'module', 'download', 'modules/download/menu.php', 1430288935, 0), 
(336, 'module', 'download', 'modules/download/rssdata.php', 1430288935, 0), 
(337, 'module', 'download', 'modules/download/search.php', 1430288935, 0), 
(338, 'module', 'download', 'modules/download/siteinfo.php', 1430288935, 0), 
(339, 'module', 'download', 'modules/download/theme.php', 1430288935, 0), 
(340, 'module', 'download', 'modules/download/version.php', 1430288935, 0), 
(341, 'module', 'download', 'themes/admin_default/modules/download/cat_add.tpl', 1430288935, 0), 
(342, 'module', 'download', 'themes/admin_default/modules/download/cat_list.tpl', 1430288935, 0), 
(343, 'module', 'download', 'themes/admin_default/modules/download/config.tpl', 1430288935, 0), 
(344, 'module', 'download', 'themes/admin_default/modules/download/content.tpl', 1430288935, 0), 
(345, 'module', 'download', 'themes/admin_default/modules/download/filequeue.tpl', 1430288935, 0), 
(346, 'module', 'download', 'themes/admin_default/modules/download/filequeue_edit.tpl', 1430288935, 0), 
(347, 'module', 'download', 'themes/admin_default/modules/download/index.html', 1430288935, 0), 
(348, 'module', 'download', 'themes/admin_default/modules/download/main.tpl', 1430288935, 0), 
(349, 'module', 'download', 'themes/admin_default/modules/download/report.tpl', 1430288935, 0), 
(350, 'module', 'download', 'themes/default/images/download/report.gif', 1430288935, 0), 
(351, 'module', 'download', 'themes/default/modules/download/block.tpl', 1430288935, 0), 
(352, 'module', 'download', 'themes/default/modules/download/block_category.tpl', 1430288935, 0), 
(353, 'module', 'download', 'themes/default/modules/download/block_lastestdownload.tpl', 1430288935, 0), 
(354, 'module', 'download', 'themes/default/modules/download/block_new_files.tpl', 1430288935, 0), 
(355, 'module', 'download', 'themes/default/modules/download/block_search.tpl', 1430288935, 0), 
(356, 'module', 'download', 'themes/default/modules/download/block_topdownload.tpl', 1430288935, 0), 
(357, 'module', 'download', 'themes/default/modules/download/block_upload.tpl', 1430288935, 0), 
(358, 'module', 'download', 'themes/default/modules/download/index.html', 1430288935, 0), 
(359, 'module', 'download', 'themes/default/modules/download/main_page.tpl', 1430288935, 0), 
(360, 'module', 'download', 'themes/default/modules/download/upload.tpl', 1430288935, 0), 
(361, 'module', 'download', 'themes/default/modules/download/viewcat_page.tpl', 1430288935, 0), 
(362, 'module', 'download', 'themes/default/modules/download/viewfile.tpl', 1430288935, 0), 
(363, 'module', 'download', 'themes/modern/images/download/arr_black.png', 1430288935, 0), 
(364, 'module', 'download', 'themes/modern/images/download/arr_red.png', 1430288935, 0), 
(365, 'module', 'download', 'themes/modern/images/download/arr_right.gif', 1430288935, 0), 
(366, 'module', 'download', 'themes/modern/images/download/bt_gradient.png', 1430288935, 0), 
(367, 'module', 'download', 'themes/modern/images/download/bullet_star.png', 1430288935, 0), 
(368, 'module', 'download', 'themes/modern/images/download/comment.gif', 1430288935, 0), 
(369, 'module', 'download', 'themes/modern/images/download/comment.png', 1430288935, 0), 
(370, 'module', 'download', 'themes/modern/images/download/comment_outline.png', 1430288935, 0), 
(371, 'module', 'download', 'themes/modern/images/download/dl-icon.png', 1430288935, 0), 
(372, 'module', 'download', 'themes/modern/images/download/dot.gif', 1430288935, 0), 
(373, 'module', 'download', 'themes/modern/images/download/down.gif', 1430288935, 0), 
(374, 'module', 'download', 'themes/modern/images/download/down.png', 1430288935, 0), 
(375, 'module', 'download', 'themes/modern/images/download/down_outline.png', 1430288935, 0), 
(376, 'module', 'download', 'themes/modern/images/download/download.gif', 1430288935, 0), 
(377, 'module', 'download', 'themes/modern/images/download/download.png', 1430288935, 0), 
(378, 'module', 'download', 'themes/modern/images/download/download2.gif', 1430288935, 0), 
(379, 'module', 'download', 'themes/modern/images/download/folder-icon.png', 1430288935, 0), 
(380, 'module', 'download', 'themes/modern/images/download/folder.gif', 1430288935, 0), 
(381, 'module', 'download', 'themes/modern/images/download/header-bg.png', 1430288935, 0), 
(382, 'module', 'download', 'themes/modern/images/download/index.html', 1430288935, 0), 
(383, 'module', 'download', 'themes/modern/images/download/info.gif', 1430288935, 0), 
(384, 'module', 'download', 'themes/modern/images/download/lt_top_bg.png', 1430288935, 0), 
(385, 'module', 'download', 'themes/modern/images/download/report.gif', 1430288935, 0), 
(386, 'module', 'download', 'themes/modern/images/download/s-icon.png', 1430288935, 0), 
(387, 'module', 'download', 'themes/modern/images/download/spector.png', 1430288935, 0), 
(388, 'module', 'download', 'themes/modern/images/download/thumb.png', 1430288935, 0), 
(389, 'module', 'download', 'themes/modern/images/download/thumb2.png', 1430288935, 0), 
(390, 'module', 'download', 'themes/modern/images/download/thumb3.png', 1430288935, 0), 
(391, 'module', 'download', 'themes/modern/images/download/up-icon.png', 1430288935, 0), 
(392, 'module', 'download', 'themes/modern/images/download/up_bg.png', 1430288935, 0), 
(393, 'module', 'download', 'themes/modern/images/download/upload.gif', 1430288935, 0), 
(394, 'module', 'download', 'themes/modern/images/download/url.gif', 1430288935, 0), 
(395, 'module', 'download', 'themes/modern/modules/download/block.tpl', 1430288935, 0), 
(396, 'module', 'download', 'themes/modern/modules/download/block_category.tpl', 1430288935, 0), 
(397, 'module', 'download', 'themes/modern/modules/download/block_lastestdownload.tpl', 1430288935, 0), 
(398, 'module', 'download', 'themes/modern/modules/download/block_search.tpl', 1430288935, 0), 
(399, 'module', 'download', 'themes/modern/modules/download/block_topdownload.tpl', 1430288935, 0), 
(400, 'module', 'download', 'themes/modern/modules/download/block_upload.tpl', 1430288935, 0), 
(401, 'module', 'download', 'themes/modern/modules/download/index.html', 1430288935, 0), 
(402, 'module', 'download', 'themes/modern/modules/download/main_page.tpl', 1430288935, 0), 
(403, 'module', 'download', 'themes/modern/modules/download/upload.tpl', 1430288935, 0), 
(404, 'module', 'download', 'themes/modern/modules/download/viewcat_page.tpl', 1430288935, 0), 
(405, 'module', 'download', 'themes/modern/modules/download/viewfile.tpl', 1430288935, 0), 
(406, 'module', 'download', 'themes/admin_default/css/download.css', 1430288935, 0), 
(407, 'module', 'download', 'themes/default/css/download.css', 1430288935, 0), 
(408, 'module', 'download', 'themes/modern/css/download.css', 1430288935, 0), 
(409, 'module', 'statistics', 'modules/statistics/blocks/global.counter.php', 1430288935, 0), 
(410, 'module', 'statistics', 'modules/statistics/blocks/index.html', 1430288935, 0), 
(411, 'module', 'statistics', 'modules/statistics/funcs/allbots.php', 1430288935, 0), 
(412, 'module', 'statistics', 'modules/statistics/funcs/allbrowsers.php', 1430288935, 0), 
(413, 'module', 'statistics', 'modules/statistics/funcs/allcountries.php', 1430288935, 0), 
(414, 'module', 'statistics', 'modules/statistics/funcs/allos.php', 1430288935, 0), 
(415, 'module', 'statistics', 'modules/statistics/funcs/allreferers.php', 1430288935, 0), 
(416, 'module', 'statistics', 'modules/statistics/funcs/index.html', 1430288935, 0), 
(417, 'module', 'statistics', 'modules/statistics/funcs/main.php', 1430288935, 0), 
(418, 'module', 'statistics', 'modules/statistics/funcs/referer.php', 1430288935, 0), 
(419, 'module', 'statistics', 'modules/statistics/functions.php', 1430288935, 0), 
(420, 'module', 'statistics', 'modules/statistics/index.html', 1430288935, 0), 
(421, 'module', 'statistics', 'modules/statistics/language/en.php', 1430288935, 0), 
(422, 'module', 'statistics', 'modules/statistics/language/index.html', 1430288935, 0), 
(423, 'module', 'statistics', 'modules/statistics/language/vi.php', 1430288935, 0), 
(424, 'module', 'statistics', 'modules/statistics/theme.php', 1430288935, 0), 
(425, 'module', 'statistics', 'modules/statistics/version.php', 1430288935, 0), 
(426, 'module', 'statistics', 'themes/default/images/statistics/bg.gif', 1430288935, 0), 
(427, 'module', 'statistics', 'themes/default/images/statistics/bg2.gif', 1430288935, 0), 
(428, 'module', 'statistics', 'themes/default/images/statistics/index.html', 1430288935, 0), 
(429, 'module', 'statistics', 'themes/default/modules/statistics/allbots.tpl', 1430288935, 0), 
(430, 'module', 'statistics', 'themes/default/modules/statistics/allbrowsers.tpl', 1430288935, 0), 
(431, 'module', 'statistics', 'themes/default/modules/statistics/allcountries.tpl', 1430288935, 0), 
(432, 'module', 'statistics', 'themes/default/modules/statistics/allos.tpl', 1430288935, 0), 
(433, 'module', 'statistics', 'themes/default/modules/statistics/allreferers.tpl', 1430288935, 0), 
(434, 'module', 'statistics', 'themes/default/modules/statistics/index.html', 1430288935, 0), 
(435, 'module', 'statistics', 'themes/default/modules/statistics/main.tpl', 1430288935, 0), 
(436, 'module', 'statistics', 'themes/default/modules/statistics/referer.tpl', 1430288935, 0), 
(437, 'module', 'statistics', 'themes/modern/images/statistics/bg.gif', 1430288935, 0), 
(438, 'module', 'statistics', 'themes/modern/images/statistics/bg2.gif', 1430288935, 0), 
(439, 'module', 'statistics', 'themes/modern/images/statistics/index.html', 1430288935, 0), 
(440, 'module', 'statistics', 'themes/default/css/statistics.css', 1430288935, 0), 
(441, 'module', 'menu', 'modules/menu/action_mysql.php', 1430288935, 0), 
(442, 'module', 'menu', 'modules/menu/action_oci.php', 1430288935, 0), 
(443, 'module', 'menu', 'modules/menu/admin/change_weight_row.php', 1430288935, 0), 
(444, 'module', 'menu', 'modules/menu/admin/del_row.php', 1430288935, 0), 
(445, 'module', 'menu', 'modules/menu/admin/index.html', 1430288935, 0), 
(446, 'module', 'menu', 'modules/menu/admin/link_menu.php', 1430288935, 0), 
(447, 'module', 'menu', 'modules/menu/admin/link_module.php', 1430288935, 0), 
(448, 'module', 'menu', 'modules/menu/admin/main.php', 1430288935, 0), 
(449, 'module', 'menu', 'modules/menu/admin/menu.php', 1430288935, 0), 
(450, 'module', 'menu', 'modules/menu/admin/rows.php', 1430288935, 0), 
(451, 'module', 'menu', 'modules/menu/admin.functions.php', 1430288935, 0), 
(452, 'module', 'menu', 'modules/menu/admin.menu.php', 1430288935, 0), 
(453, 'module', 'menu', 'modules/menu/blocks/global.bootstrap.ini', 1430288935, 0), 
(454, 'module', 'menu', 'modules/menu/blocks/global.bootstrap.php', 1430288935, 0), 
(455, 'module', 'menu', 'modules/menu/blocks/global.metismenu.ini', 1430288935, 0), 
(456, 'module', 'menu', 'modules/menu/blocks/global.metismenu.php', 1430288935, 0), 
(457, 'module', 'menu', 'modules/menu/blocks/global.site_mods.ini', 1430288935, 0), 
(458, 'module', 'menu', 'modules/menu/blocks/global.site_mods.php', 1430288935, 0), 
(459, 'module', 'menu', 'modules/menu/blocks/global.slimmenu.ini', 1430288935, 0), 
(460, 'module', 'menu', 'modules/menu/blocks/global.slimmenu.php', 1430288935, 0), 
(461, 'module', 'menu', 'modules/menu/blocks/global.superfish.ini', 1430288935, 0), 
(462, 'module', 'menu', 'modules/menu/blocks/global.superfish.php', 1430288935, 0), 
(463, 'module', 'menu', 'modules/menu/blocks/global.treeview.ini', 1430288935, 0), 
(464, 'module', 'menu', 'modules/menu/blocks/global.treeview.php', 1430288935, 0), 
(465, 'module', 'menu', 'modules/menu/blocks/global.vertical_system.ini', 1430288935, 0), 
(466, 'module', 'menu', 'modules/menu/blocks/global.vertical_system.php', 1430288935, 0), 
(467, 'module', 'menu', 'modules/menu/blocks/index.html', 1430288935, 0), 
(468, 'module', 'menu', 'modules/menu/funcs/index.html', 1430288935, 0), 
(469, 'module', 'menu', 'modules/menu/funcs/main.php', 1430288935, 0), 
(470, 'module', 'menu', 'modules/menu/functions.php', 1430288935, 0), 
(471, 'module', 'menu', 'modules/menu/index.html', 1430288935, 0), 
(472, 'module', 'menu', 'modules/menu/js/admin.js', 1430288935, 0), 
(473, 'module', 'menu', 'modules/menu/js/index.html', 1430288935, 0), 
(474, 'module', 'menu', 'modules/menu/language/admin_en.php', 1430288935, 0), 
(475, 'module', 'menu', 'modules/menu/language/admin_vi.php', 1430288935, 0), 
(476, 'module', 'menu', 'modules/menu/language/block.config_en.php', 1430288935, 0), 
(477, 'module', 'menu', 'modules/menu/language/block.config_vi.php', 1430288935, 0), 
(478, 'module', 'menu', 'modules/menu/language/index.html', 1430288935, 0), 
(479, 'module', 'menu', 'modules/menu/menu_blocks.php', 1430288935, 0), 
(480, 'module', 'menu', 'modules/menu/menu_config.php', 1430288935, 0), 
(481, 'module', 'menu', 'modules/menu/version.php', 1430288935, 0), 
(482, 'module', 'menu', 'themes/admin_default/modules/menu/index.html', 1430288935, 0), 
(483, 'module', 'menu', 'themes/admin_default/modules/menu/main.tpl', 1430288935, 0), 
(484, 'module', 'menu', 'themes/admin_default/modules/menu/menu.tpl', 1430288935, 0), 
(485, 'module', 'menu', 'themes/admin_default/modules/menu/rows.tpl', 1430288935, 0), 
(486, 'module', 'menu', 'themes/default/modules/menu/global.bootstrap.tpl', 1430288935, 0), 
(487, 'module', 'menu', 'themes/default/modules/menu/global.metismenu.tpl', 1430288935, 0), 
(488, 'module', 'menu', 'themes/default/modules/menu/global.slimmenu.tpl', 1430288935, 0), 
(489, 'module', 'menu', 'themes/default/modules/menu/global.superfish.tpl', 1430288935, 0), 
(490, 'module', 'menu', 'themes/default/modules/menu/global.treeview.tpl', 1430288935, 0), 
(491, 'module', 'menu', 'themes/default/modules/menu/index.html', 1430288935, 0), 
(492, 'module', 'menu', 'themes/modern/modules/menu/global.superfish.tpl', 1430288935, 0), 
(493, 'module', 'menu', 'themes/modern/modules/menu/index.html', 1430288935, 0), 
(494, 'module', 'menu', 'themes/default/css/menu.css', 1430288935, 0), 
(495, 'module', 'tkblop', 'modules/tkblop/action_mysql.php', 1453200590, 0), 
(496, 'module', 'tkblop', 'modules/tkblop/admin/config.php', 1453200590, 0), 
(497, 'module', 'tkblop', 'modules/tkblop/admin/del.php', 1453200590, 0), 
(498, 'module', 'tkblop', 'modules/tkblop/admin/edit_tkb.php', 1453200590, 0), 
(499, 'module', 'tkblop', 'modules/tkblop/admin/import.php', 1453200590, 0), 
(500, 'module', 'tkblop', 'modules/tkblop/admin/index.html', 1453200590, 0), 
(501, 'module', 'tkblop', 'modules/tkblop/admin/main.php', 1453200590, 0), 
(502, 'module', 'tkblop', 'modules/tkblop/admin/quanli.php', 1453200590, 0), 
(503, 'module', 'tkblop', 'modules/tkblop/admin.functions.php', 1453200590, 0), 
(504, 'module', 'tkblop', 'modules/tkblop/admin.menu.php', 1453200590, 0), 
(505, 'module', 'tkblop', 'modules/tkblop/blocks/.htaccess', 1453200590, 0), 
(506, 'module', 'tkblop', 'modules/tkblop/blocks/index.html', 1453200590, 0), 
(507, 'module', 'tkblop', 'modules/tkblop/config.php', 1453200590, 0), 
(508, 'module', 'tkblop', 'modules/tkblop/config.txt', 1453200590, 0), 
(509, 'module', 'tkblop', 'modules/tkblop/ftp.class.php', 1453200590, 0), 
(510, 'module', 'tkblop', 'modules/tkblop/funcs/index.html', 1453200590, 0), 
(511, 'module', 'tkblop', 'modules/tkblop/funcs/main.php', 1453200590, 0), 
(512, 'module', 'tkblop', 'modules/tkblop/functions.php', 1453200590, 0), 
(513, 'module', 'tkblop', 'modules/tkblop/index.html', 1453200590, 0), 
(514, 'module', 'tkblop', 'modules/tkblop/language/.htaccess', 1453200590, 0), 
(515, 'module', 'tkblop', 'modules/tkblop/language/admin_vi.php', 1453200590, 0), 
(516, 'module', 'tkblop', 'modules/tkblop/language/index.html', 1453200590, 0), 
(517, 'module', 'tkblop', 'modules/tkblop/language/vi.php', 1453200590, 0), 
(518, 'module', 'tkblop', 'modules/tkblop/theme.php', 1453200590, 0), 
(519, 'module', 'tkblop', 'modules/tkblop/version.php', 1453200590, 0), 
(520, 'module', 'tkblop', 'themes/default/css/tkblop.css', 1453200590, 0), 
(521, 'module', 'tkblop', 'themes/default/modules/tkblop/main.tpl', 1453200590, 0), 
(522, 'module', 'diemex', 'modules/diemex/action_mysql.php', 1453201047, 0), 
(523, 'module', 'diemex', 'modules/diemex/admin/.htaccess', 1453201047, 0), 
(524, 'module', 'diemex', 'modules/diemex/admin/content.php', 1453201047, 0), 
(525, 'module', 'diemex', 'modules/diemex/admin/index.html', 1453201047, 0), 
(526, 'module', 'diemex', 'modules/diemex/admin/main.php', 1453201047, 0), 
(527, 'module', 'diemex', 'modules/diemex/admin/notice.php', 1453201047, 0), 
(528, 'module', 'diemex', 'modules/diemex/admin.functions.php', 1453201047, 0), 
(529, 'module', 'diemex', 'modules/diemex/admin.menu.php', 1453201047, 0), 
(530, 'module', 'diemex', 'modules/diemex/funcs/.htaccess', 1453201047, 0), 
(531, 'module', 'diemex', 'modules/diemex/funcs/index.html', 1453201047, 0), 
(532, 'module', 'diemex', 'modules/diemex/funcs/main.php', 1453201047, 0), 
(533, 'module', 'diemex', 'modules/diemex/funcs/print.php', 1453201047, 0), 
(534, 'module', 'diemex', 'modules/diemex/functions.php', 1453201047, 0), 
(535, 'module', 'diemex', 'modules/diemex/index.html', 1453201047, 0), 
(536, 'module', 'diemex', 'modules/diemex/js/admin.js', 1453201047, 0), 
(537, 'module', 'diemex', 'modules/diemex/js/index.html', 1453201047, 0), 
(538, 'module', 'diemex', 'modules/diemex/js/user.js', 1453201047, 0), 
(539, 'module', 'diemex', 'modules/diemex/language/.htaccess', 1453201047, 0), 
(540, 'module', 'diemex', 'modules/diemex/language/admin_vi.php', 1453201047, 0), 
(541, 'module', 'diemex', 'modules/diemex/language/index.html', 1453201047, 0), 
(542, 'module', 'diemex', 'modules/diemex/language/vi.php', 1453201047, 0), 
(543, 'module', 'diemex', 'modules/diemex/version.php', 1453201047, 0), 
(544, 'module', 'diemex', 'themes/admin_default/modules/diemex/content.tpl', 1453201047, 0), 
(545, 'module', 'diemex', 'themes/admin_default/modules/diemex/index.html', 1453201047, 0), 
(546, 'module', 'diemex', 'themes/admin_default/modules/diemex/main.tpl', 1453201047, 0), 
(547, 'module', 'diemex', 'themes/default/modules/diemex/index.html', 1453201047, 0), 
(548, 'module', 'diemex', 'themes/default/modules/diemex/main.tpl', 1453201047, 0), 
(549, 'module', 'diemex', 'themes/default/modules/diemex/print.tpl', 1453201047, 0), 
(550, 'module', 'laws', 'modules/laws/action_mysql.php', 1453201170, 0), 
(551, 'module', 'laws', 'modules/laws/admin/.htaccess', 1453201170, 0), 
(552, 'module', 'laws', 'modules/laws/admin/alias.php', 1453201170, 0), 
(553, 'module', 'laws', 'modules/laws/admin/cat.php', 1453201170, 0), 
(554, 'module', 'laws', 'modules/laws/admin/cat_action.php', 1453201170, 0), 
(555, 'module', 'laws', 'modules/laws/admin/config.php', 1453201170, 0), 
(556, 'module', 'laws', 'modules/laws/admin/content.php', 1453201170, 0), 
(557, 'module', 'laws', 'modules/laws/admin/field.php', 1453201170, 0), 
(558, 'module', 'laws', 'modules/laws/admin/field_action.php', 1453201170, 0), 
(559, 'module', 'laws', 'modules/laws/admin/index.html', 1453201170, 0), 
(560, 'module', 'laws', 'modules/laws/admin/main.php', 1453201170, 0), 
(561, 'module', 'laws', 'modules/laws/admin/organ.php', 1453201170, 0), 
(562, 'module', 'laws', 'modules/laws/admin/organ_action.php', 1453201170, 0), 
(563, 'module', 'laws', 'modules/laws/admin/room.php', 1453201170, 0), 
(564, 'module', 'laws', 'modules/laws/admin/room_action.php', 1453201170, 0), 
(565, 'module', 'laws', 'modules/laws/admin.functions.php', 1453201170, 0), 
(566, 'module', 'laws', 'modules/laws/admin.menu.php', 1453201170, 0), 
(567, 'module', 'laws', 'modules/laws/blocks/.htaccess', 1453201170, 0), 
(568, 'module', 'laws', 'modules/laws/blocks/global.block_category.ini', 1453201170, 0), 
(569, 'module', 'laws', 'modules/laws/blocks/global.block_category.php', 1453201170, 0), 
(570, 'module', 'laws', 'modules/laws/blocks/global.block_cattree.php', 1453201170, 0), 
(571, 'module', 'laws', 'modules/laws/blocks/global.block_fieldtree.php', 1453201170, 0), 
(572, 'module', 'laws', 'modules/laws/blocks/global.block_newlaws.ini', 1453201170, 0), 
(573, 'module', 'laws', 'modules/laws/blocks/global.block_newlaws.php', 1453201170, 0), 
(574, 'module', 'laws', 'modules/laws/blocks/global.block_roomtree.php', 1453201170, 0), 
(575, 'module', 'laws', 'modules/laws/blocks/global.block_uplaws.php', 1453201170, 0), 
(576, 'module', 'laws', 'modules/laws/blocks/index.html', 1453201170, 0), 
(577, 'module', 'laws', 'modules/laws/blocks/module.block_catall.php', 1453201170, 0), 
(578, 'module', 'laws', 'modules/laws/blocks/module.block_search.php', 1453201170, 0), 
(579, 'module', 'laws', 'modules/laws/funcs/.htaccess', 1453201170, 0), 
(580, 'module', 'laws', 'modules/laws/funcs/content.php', 1453201170, 0), 
(581, 'module', 'laws', 'modules/laws/funcs/down.php', 1453201170, 0), 
(582, 'module', 'laws', 'modules/laws/funcs/index.html', 1453201170, 0), 
(583, 'module', 'laws', 'modules/laws/funcs/main.php', 1453201170, 0), 
(584, 'module', 'laws', 'modules/laws/funcs/search.php', 1453201170, 0), 
(585, 'module', 'laws', 'modules/laws/funcs/view.php', 1453201170, 0), 
(586, 'module', 'laws', 'modules/laws/funcs/viewcat.php', 1453201170, 0), 
(587, 'module', 'laws', 'modules/laws/funcs/viewfield.php', 1453201170, 0), 
(588, 'module', 'laws', 'modules/laws/funcs/vieworgan.php', 1453201170, 0), 
(589, 'module', 'laws', 'modules/laws/funcs/viewroom.php', 1453201170, 0), 
(590, 'module', 'laws', 'modules/laws/functions.php', 1453201170, 0), 
(591, 'module', 'laws', 'modules/laws/index.html', 1453201170, 0), 
(592, 'module', 'laws', 'modules/laws/js/admin.js', 1453201170, 0), 
(593, 'module', 'laws', 'modules/laws/js/index.html', 1453201170, 0), 
(594, 'module', 'laws', 'modules/laws/js/user.js', 1453201170, 0), 
(595, 'module', 'laws', 'modules/laws/language/.htaccess', 1453201170, 0), 
(596, 'module', 'laws', 'modules/laws/language/admin_en.php', 1453201170, 0), 
(597, 'module', 'laws', 'modules/laws/language/admin_vi.php', 1453201170, 0), 
(598, 'module', 'laws', 'modules/laws/language/en.php', 1453201170, 0), 
(599, 'module', 'laws', 'modules/laws/language/index.html', 1453201170, 0), 
(600, 'module', 'laws', 'modules/laws/language/vi.php', 1453201170, 0), 
(601, 'module', 'laws', 'modules/laws/search.php', 1453201170, 0), 
(602, 'module', 'laws', 'modules/laws/siteinfo.php', 1453201170, 0), 
(603, 'module', 'laws', 'modules/laws/theme.php', 1453201170, 0), 
(604, 'module', 'laws', 'modules/laws/version.php', 1453201170, 0), 
(605, 'module', 'laws', 'themes/admin_default/css/laws.css', 1453201170, 0), 
(606, 'module', 'laws', 'themes/admin_default/images/laws/index.html', 1453201170, 0), 
(607, 'module', 'laws', 'themes/admin_default/modules/laws/.htaccess', 1453201170, 0), 
(608, 'module', 'laws', 'themes/admin_default/modules/laws/cat.tpl', 1453201170, 0), 
(609, 'module', 'laws', 'themes/admin_default/modules/laws/config.tpl', 1453201170, 0), 
(610, 'module', 'laws', 'themes/admin_default/modules/laws/content.tpl', 1453201170, 0), 
(611, 'module', 'laws', 'themes/admin_default/modules/laws/field.tpl', 1453201170, 0), 
(612, 'module', 'laws', 'themes/admin_default/modules/laws/index.html', 1453201170, 0), 
(613, 'module', 'laws', 'themes/admin_default/modules/laws/main.tpl', 1453201170, 0), 
(614, 'module', 'laws', 'themes/admin_default/modules/laws/organ.tpl', 1453201170, 0), 
(615, 'module', 'laws', 'themes/admin_default/modules/laws/room.tpl', 1453201170, 0), 
(616, 'module', 'laws', 'themes/admin_default/modules/laws/version.php', 1453201170, 0), 
(617, 'module', 'laws', 'themes/default/css/laws.css', 1453201170, 0), 
(618, 'module', 'laws', 'themes/default/images/laws/doc.png', 1453201170, 0), 
(619, 'module', 'laws', 'themes/default/images/laws/docx.png', 1453201170, 0), 
(620, 'module', 'laws', 'themes/default/images/laws/download.png', 1453201170, 0), 
(621, 'module', 'laws', 'themes/default/images/laws/file.png', 1453201170, 0), 
(622, 'module', 'laws', 'themes/default/images/laws/index.html', 1453201170, 0), 
(623, 'module', 'laws', 'themes/default/images/laws/jquery.marquee.js', 1453201170, 0), 
(624, 'module', 'laws', 'themes/default/images/laws/new.gif', 1453201170, 0), 
(625, 'module', 'laws', 'themes/default/images/laws/pdf.png', 1453201170, 0), 
(626, 'module', 'laws', 'themes/default/images/laws/ppt.png', 1453201170, 0), 
(627, 'module', 'laws', 'themes/default/images/laws/pptx.png', 1453201170, 0), 
(628, 'module', 'laws', 'themes/default/images/laws/rar.png', 1453201170, 0), 
(629, 'module', 'laws', 'themes/default/images/laws/xls.png', 1453201170, 0), 
(630, 'module', 'laws', 'themes/default/images/laws/xlsx.png', 1453201170, 0), 
(631, 'module', 'laws', 'themes/default/images/laws/zip.png', 1453201170, 0), 
(632, 'module', 'laws', 'themes/default/modules/laws/.htaccess', 1453201170, 0), 
(633, 'module', 'laws', 'themes/default/modules/laws/block_catall.tpl', 1453201170, 0), 
(634, 'module', 'laws', 'themes/default/modules/laws/block_category.tpl', 1453201170, 0), 
(635, 'module', 'laws', 'themes/default/modules/laws/block_listorgans.tpl', 1453201170, 0), 
(636, 'module', 'laws', 'themes/default/modules/laws/block_listtree.tpl', 1453201170, 0), 
(637, 'module', 'laws', 'themes/default/modules/laws/block_newarchives.tpl', 1453201170, 0), 
(638, 'module', 'laws', 'themes/default/modules/laws/block_search.tpl', 1453201170, 0), 
(639, 'module', 'laws', 'themes/default/modules/laws/block_uparchives.tpl', 1453201170, 0), 
(640, 'module', 'laws', 'themes/default/modules/laws/content.tpl', 1453201170, 0), 
(641, 'module', 'laws', 'themes/default/modules/laws/index.html', 1453201170, 0), 
(642, 'module', 'laws', 'themes/default/modules/laws/main_catall.tpl', 1453201170, 0), 
(643, 'module', 'laws', 'themes/default/modules/laws/main_listall.tpl', 1453201170, 0), 
(644, 'module', 'laws', 'themes/default/modules/laws/view.tpl', 1453201170, 0), 
(645, 'module', 'laws', 'themes/default/modules/laws/view_search.tpl', 1453201170, 0), 
(646, 'module', 'video-clip', 'themes/admin_default/css/video-clip.css', 1453419482, 0), 
(647, 'module', 'video-clip', 'themes/admin_default/images/video-clip/disabled.png', 1453419482, 0), 
(648, 'module', 'video-clip', 'themes/admin_default/images/video-clip/enabled.png', 1453419482, 0), 
(649, 'module', 'video-clip', 'themes/admin_default/images/video-clip/index.html', 1453419482, 0), 
(650, 'module', 'video-clip', 'themes/admin_default/modules/video-clip/.htaccess', 1453419482, 0), 
(651, 'module', 'video-clip', 'themes/admin_default/modules/video-clip/cbroken.tpl', 1453419482, 0), 
(652, 'module', 'video-clip', 'themes/admin_default/modules/video-clip/config.tpl', 1453419482, 0), 
(653, 'module', 'video-clip', 'themes/admin_default/modules/video-clip/index.html', 1453419482, 0), 
(654, 'module', 'video-clip', 'themes/admin_default/modules/video-clip/main.tpl', 1453419482, 0), 
(655, 'module', 'video-clip', 'themes/admin_default/modules/video-clip/topic_add.tpl', 1453419482, 0), 
(656, 'module', 'video-clip', 'themes/admin_default/modules/video-clip/topic_list.tpl', 1453419482, 0), 
(657, 'module', 'video-clip', 'themes/admin_default/modules/video-clip/vbroken.tpl', 1453419482, 0), 
(658, 'module', 'video-clip', 'themes/default/css/video-clip.css', 1453419482, 0), 
(659, 'module', 'video-clip', 'themes/default/images/video-clip/current.png', 1453419482, 0), 
(660, 'module', 'video-clip', 'themes/default/images/video-clip/icons.png', 1453419482, 0), 
(661, 'module', 'video-clip', 'themes/default/images/video-clip/index.html', 1453419482, 0), 
(662, 'module', 'video-clip', 'themes/default/images/video-clip/like.png', 1453419482, 0), 
(663, 'module', 'video-clip', 'themes/default/images/video-clip/play-small.png', 1453419482, 0), 
(664, 'module', 'video-clip', 'themes/default/images/video-clip/play.png', 1453419482, 0), 
(665, 'module', 'video-clip', 'themes/default/images/video-clip/video.png', 1453419482, 0), 
(666, 'module', 'video-clip', 'themes/default/images/video-clip/wait.gif', 1453419482, 0), 
(667, 'module', 'video-clip', 'themes/default/images/video-clip/Zicons.png', 1453419482, 0), 
(668, 'module', 'video-clip', 'themes/default/modules/video-clip/.htaccess', 1453419482, 0), 
(669, 'module', 'video-clip', 'themes/default/modules/video-clip/block.box_video.tpl', 1453419482, 0), 
(670, 'module', 'video-clip', 'themes/default/modules/video-clip/block_new_image_video.tpl', 1453419482, 0), 
(671, 'module', 'video-clip', 'themes/default/modules/video-clip/block_new_video.tpl', 1453419482, 0), 
(672, 'module', 'video-clip', 'themes/default/modules/video-clip/block_top_video.tpl', 1453419482, 0), 
(673, 'module', 'video-clip', 'themes/default/modules/video-clip/detail.tpl', 1453419482, 0), 
(674, 'module', 'video-clip', 'themes/default/modules/video-clip/index.html', 1453419482, 0), 
(675, 'module', 'video-clip', 'themes/default/modules/video-clip/main.tpl', 1453419482, 0), 
(676, 'module', 'video-clip', 'themes/mobile_nukeviet/css/video-clip.css', 1453419482, 0), 
(677, 'module', 'video-clip', 'themes/mobile_nukeviet/images/video-clip/index.html', 1453419482, 0), 
(678, 'module', 'video-clip', 'themes/mobile_nukeviet/images/video-clip/play.png', 1453419482, 0), 
(679, 'module', 'video-clip', 'themes/mobile_nukeviet/images/video-clip/video.png', 1453419482, 0), 
(680, 'module', 'video-clip', 'themes/mobile_nukeviet/modules/video-clip/.htaccess', 1453419482, 0), 
(681, 'module', 'video-clip', 'themes/mobile_nukeviet/modules/video-clip/block.box_video.tpl', 1453419482, 0), 
(682, 'module', 'video-clip', 'themes/mobile_nukeviet/modules/video-clip/index.html', 1453419482, 0), 
(683, 'module', 'video-clip', 'themes/mobile_nukeviet/modules/video-clip/main.tpl', 1453419482, 0), 
(684, 'module', 'video-clip', 'modules/video-clip/action_mysql.php', 1453419482, 0), 
(685, 'module', 'video-clip', 'modules/video-clip/admin/.htaccess', 1453419482, 0), 
(686, 'module', 'video-clip', 'modules/video-clip/admin/cbroken.php', 1453419482, 0), 
(687, 'module', 'video-clip', 'modules/video-clip/admin/config.php', 1453419482, 0), 
(688, 'module', 'video-clip', 'modules/video-clip/admin/index.html', 1453419482, 0), 
(689, 'module', 'video-clip', 'modules/video-clip/admin/main.php', 1453419482, 0), 
(690, 'module', 'video-clip', 'modules/video-clip/admin/topic.php', 1453419482, 0), 
(691, 'module', 'video-clip', 'modules/video-clip/admin/vbroken.php', 1453419482, 0), 
(692, 'module', 'video-clip', 'modules/video-clip/admin.functions.php', 1453419482, 0), 
(693, 'module', 'video-clip', 'modules/video-clip/admin.menu.php', 1453419482, 0), 
(694, 'module', 'video-clip', 'modules/video-clip/blocks/.htaccess', 1453419482, 0), 
(695, 'module', 'video-clip', 'modules/video-clip/blocks/global.box_video.ini', 1453419482, 0), 
(696, 'module', 'video-clip', 'modules/video-clip/blocks/global.box_video.php', 1453419482, 0), 
(697, 'module', 'video-clip', 'modules/video-clip/blocks/global.new_image_video.php', 1453419482, 0), 
(698, 'module', 'video-clip', 'modules/video-clip/blocks/global.new_videos.ini', 1453419482, 0), 
(699, 'module', 'video-clip', 'modules/video-clip/blocks/global.new_videos.php', 1453419482, 0), 
(700, 'module', 'video-clip', 'modules/video-clip/blocks/global.top_videos.ini', 1453419482, 0), 
(701, 'module', 'video-clip', 'modules/video-clip/blocks/global.top_videos.php', 1453419482, 0), 
(702, 'module', 'video-clip', 'modules/video-clip/blocks/index.html', 1453419482, 0), 
(703, 'module', 'video-clip', 'modules/video-clip/blocks/module.detail.php', 1453419482, 0), 
(704, 'module', 'video-clip', 'modules/video-clip/funcs/.htaccess', 1453419482, 0), 
(705, 'module', 'video-clip', 'modules/video-clip/funcs/index.html', 1453419482, 0), 
(706, 'module', 'video-clip', 'modules/video-clip/funcs/main.php', 1453419482, 0), 
(707, 'module', 'video-clip', 'modules/video-clip/funcs/rss.php', 1453419482, 0), 
(708, 'module', 'video-clip', 'modules/video-clip/funcs/Sitemap.php', 1453419482, 0), 
(709, 'module', 'video-clip', 'modules/video-clip/functions.php', 1453419482, 0), 
(710, 'module', 'video-clip', 'modules/video-clip/index.html', 1453419482, 0), 
(711, 'module', 'video-clip', 'modules/video-clip/js/admin.js', 1453419482, 0), 
(712, 'module', 'video-clip', 'modules/video-clip/js/index.html', 1453419482, 0), 
(713, 'module', 'video-clip', 'modules/video-clip/js/jquery.autoresize.js', 1453419482, 0), 
(714, 'module', 'video-clip', 'modules/video-clip/js/jwplayer.flash.swf', 1453419482, 0), 
(715, 'module', 'video-clip', 'modules/video-clip/js/jwplayer.html5.js', 1453419482, 0), 
(716, 'module', 'video-clip', 'modules/video-clip/js/jwplayer.js', 1453419482, 0), 
(717, 'module', 'video-clip', 'modules/video-clip/language/.htaccess', 1453419482, 0), 
(718, 'module', 'video-clip', 'modules/video-clip/language/admin_en.php', 1453419482, 0), 
(719, 'module', 'video-clip', 'modules/video-clip/language/admin_vi.php', 1453419482, 0), 
(720, 'module', 'video-clip', 'modules/video-clip/language/en.php', 1453419482, 0), 
(721, 'module', 'video-clip', 'modules/video-clip/language/index.html', 1453419482, 0), 
(722, 'module', 'video-clip', 'modules/video-clip/language/vi.php', 1453419482, 0), 
(723, 'module', 'video-clip', 'modules/video-clip/mobile/.htaccess', 1453419482, 0), 
(724, 'module', 'video-clip', 'modules/video-clip/mobile/index.html', 1453419482, 0), 
(725, 'module', 'video-clip', 'modules/video-clip/mobile/main.php', 1453419482, 0), 
(726, 'module', 'video-clip', 'modules/video-clip/rssdata.php', 1453419482, 0), 
(727, 'module', 'video-clip', 'modules/video-clip/search.php', 1453419482, 0), 
(728, 'module', 'video-clip', 'modules/video-clip/version.php', 1453419482, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_googleplus`
--

DROP TABLE IF EXISTS `ctypa_googleplus`;
CREATE TABLE `ctypa_googleplus` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `idprofile` varchar(25) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  UNIQUE KEY `idprofile` (`idprofile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_groups`
--

DROP TABLE IF EXISTS `ctypa_groups`;
CREATE TABLE `ctypa_groups` (
  `group_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `publics` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  `idsite` int(11) unsigned NOT NULL DEFAULT '0',
  `numbers` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `siteus` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `ktitle` (`title`,`idsite`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_groups`
--

INSERT INTO `ctypa_groups` VALUES
(6, 'All', '', 1430288935, 0, 0, 1, 1, 0, 0, 0), 
(5, 'Guest', '', 1430288935, 0, 0, 2, 1, 0, 0, 0), 
(4, 'Users', '', 1430288935, 0, 0, 3, 1, 0, 1, 0), 
(1, 'Super admin', '', 1430288935, 0, 0, 4, 1, 0, 0, 0), 
(2, 'General admin', '', 1430288935, 0, 0, 5, 1, 0, 0, 0), 
(3, 'Module admin', '', 1430288935, 0, 0, 6, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_groups_users`
--

DROP TABLE IF EXISTS `ctypa_groups_users`;
CREATE TABLE `ctypa_groups_users` (
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`group_id`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_language`
--

DROP TABLE IF EXISTS `ctypa_language`;
CREATE TABLE `ctypa_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_language_file`
--

DROP TABLE IF EXISTS `ctypa_language_file`;
CREATE TABLE `ctypa_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` varchar(255) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_logs`
--

DROP TABLE IF EXISTS `ctypa_logs`;
CREATE TABLE `ctypa_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=248  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_logs`
--

INSERT INTO `ctypa_logs` VALUES
(1, 'vi', 'login', '[ngocanh@pasvietnam.vn] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1430289200), 
(2, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1430290058), 
(3, 'vi', 'themes', 'Sửa block', 'Name : Thống kê truy cập', '', 1, 1430291783), 
(4, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1430297746), 
(5, 'vi', 'themes', 'Sửa block', 'Name : Giới thiệu', '', 1, 1430297916), 
(6, 'vi', 'themes', 'Sửa block', 'Name : Thăm dò ý kiến', '', 1, 1430298443), 
(7, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1430304115), 
(8, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1430305548), 
(9, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1430305634), 
(10, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1430305652), 
(11, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1430305678), 
(12, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1430306246), 
(13, 'vi', 'login', '[ngocanh@pasvietnam.vn] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1430362494), 
(14, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1430362507), 
(15, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1430362800), 
(16, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1430369626), 
(17, 'vi', 'modules', 'Thiết lập module mới feednews', '', '', 1, 1430369760), 
(18, 'vi', 'modules', 'Sửa module &ldquo;feednews&rdquo;', '', '', 1, 1430369761), 
(19, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1430369804), 
(20, 'vi', 'login', '[ngocanh@pasvietnam.vn] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1430428986), 
(21, 'vi', 'themes', 'Thêm block', 'Name : global block pa groups', '', 1, 1430431875), 
(22, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1430431889), 
(23, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1430432021), 
(24, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1430432139), 
(25, 'vi', 'upload', 'Upload file', 'uploads/news/2015_05/anh-1-1430419430_490x294.jpg', '', 1, 1430432182), 
(26, 'vi', 'news', 'Thêm bài viết', 'Đông nghẹt người ngắm pháo hoa từ phố đi bộ Nguyễn Huệ', '', 1, 1430432216), 
(27, 'vi', 'themes', 'Sửa block', 'Name : Tin mới nhất', '', 1, 1430432930), 
(28, 'vi', 'modules', 'Thiết lập module mới nvgetnews', '', '', 1, 1430433332), 
(29, 'vi', 'modules', 'Sửa module &ldquo;nvgetnews&rdquo;', '', '', 1, 1430433334), 
(30, 'vi', 'modules', 'Cài lại module \"news\"', '', '', 1, 1430433343), 
(31, 'vi', 'news', 'Thêm chuyên mục', 'Thời sự', '', 1, 1430433405), 
(32, 'vi', 'news', 'Thêm chuyên mục', 'Thế giới', '', 1, 1430433479), 
(33, 'vi', 'news', 'Thêm chuyên mục', 'Giáo dục', '', 1, 1430433503), 
(34, 'vi', 'news', 'Thêm chuyên mục', 'Pháp luật', '', 1, 1430433508), 
(35, 'vi', 'news', 'Thêm chuyên mục', 'Sức khoẻ', '', 1, 1430433527), 
(36, 'vi', 'news', 'Thêm chuyên mục', 'Tình yêu', '', 1, 1430433534), 
(37, 'vi', 'news', 'Thêm chuyên mục', 'Chuyện lạ', '', 1, 1430433538), 
(38, 'vi', 'news', 'log_add_blockcat', ' ', '', 1, 1430433561), 
(39, 'vi', 'news', 'log_add_blockcat', ' ', '', 1, 1430433568), 
(40, 'vi', 'themes', 'Sửa block', 'Name : Tin mới', '', 1, 1430433705), 
(41, 'vi', 'themes', 'Sửa block', 'Name : Tin mới', '', 1, 1430433919), 
(42, 'vi', 'themes', 'Thêm block', 'Name : Sự kiện', '', 1, 1430436167), 
(43, 'vi', 'themes', 'Sửa block', 'Name : Sự kiện', '', 1, 1430436528), 
(44, 'vi', 'themes', 'Sửa block', 'Name : Social icon', '', 1, 1430436817), 
(45, 'vi', 'themes', 'Sửa block', 'Name : Social icon', '', 1, 1430437187), 
(46, 'vi', 'themes', 'Sửa block', 'Name : Social icon', '', 1, 1430437518), 
(47, 'vi', 'themes', 'Sửa block', 'Name : Social icon', '', 1, 1430438030), 
(48, 'vi', 'modules', 'Xóa module \"nvgetnews\"', '', '', 1, 1430438199), 
(49, 'vi', 'modules', 'Xóa module \"feednews\"', '', '', 1, 1430438203), 
(50, 'vi', 'modules', 'Thiết lập module mới support', '', '', 1, 1430438302), 
(51, 'vi', 'modules', 'Sửa module &ldquo;support&rdquo;', '', '', 1, 1430438306), 
(52, 'vi', 'themes', 'Thêm block', 'Name : Hỗ trợ online', '', 1, 1430438328), 
(53, 'vi', 'themes', 'Sửa block', 'Name : Sự kiện', '', 1, 1430438893), 
(54, 'vi', 'themes', 'Thêm block', 'Name : global block news cat cal', '', 1, 1430450463), 
(55, 'vi', 'themes', 'Sửa block', 'Name : global block news cat cal', '', 1, 1430450526), 
(56, 'vi', 'themes', 'Sửa block', 'Name : global block news cat cal', '', 1, 1430450620), 
(57, 'vi', 'themes', 'Sửa block', 'Name : global block news cat cal', '', 1, 1430450644), 
(58, 'vi', 'themes', 'Sửa block', 'Name : Hỗ trợ online', '', 1, 1430451132), 
(59, 'vi', 'themes', 'Sửa block', 'Name : Hỗ trợ online', '', 1, 1430451151), 
(60, 'vi', 'themes', 'Sửa block', 'Name : Hỗ trợ online', '', 1, 1430451181), 
(61, 'vi', 'themes', 'Sửa block', 'Name : Hỗ trợ online', '', 1, 1430451216), 
(62, 'vi', 'login', '[ngocanh@pasvietnam.vn] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1430460578), 
(63, 'vi', 'themes', 'Thêm block', 'Name : Thảo luận mới', '', 1, 1430460612), 
(64, 'vi', 'themes', 'Sửa block', 'Name : Hỗ trợ online', '', 1, 1430460663), 
(65, 'vi', 'themes', 'Thiết lập lại vị trí các block', 'reset position all block', '', 1, 1430460683), 
(66, 'vi', 'themes', 'Sửa block', 'Name : Thảo luận mới', '', 1, 1430460698), 
(67, 'vi', 'themes', 'Thêm block', 'Name : Tag', '', 1, 1430460807), 
(68, 'vi', 'themes', 'Sửa block', 'Name : Tag', '', 1, 1430460828), 
(69, 'vi', 'themes', 'Sửa block', 'Name : Tag', '', 1, 1430460905), 
(70, 'vi', 'themes', 'Sửa block', 'Name : Giới thiệu', '', 1, 1430460933), 
(71, 'vi', 'themes', 'Thêm block', 'Name : Facebook', '', 1, 1430461068), 
(72, 'vi', 'themes', 'Sửa block', 'Name : Facebook', '', 1, 1430461083), 
(73, 'vi', 'themes', 'Thiết lập lại vị trí các block', 'reset position all block', '', 1, 1430461100), 
(74, 'vi', 'themes', 'Thêm block', 'Name : Tin mới', '', 1, 1430461343), 
(75, 'vi', 'themes', 'Sửa block', 'Name : Tin mới', '', 1, 1430461437), 
(76, 'vi', 'themes', 'Sửa block', 'Name : Tin mới', '', 1, 1430461462), 
(77, 'vi', 'themes', 'Thiết lập lại vị trí các block', 'reset position all block', '', 1, 1430461509), 
(78, 'vi', 'modules', 'Thiết lập module mới download', '', '', 1, 1430461513), 
(79, 'vi', 'modules', 'Sửa module &ldquo;download&rdquo;', '', '', 1, 1430461519), 
(80, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Chuyện lạ', '', 1, 1430461559), 
(81, 'vi', 'themes', 'Sửa block', 'Name : footer site', '', 1, 1430461608), 
(82, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1430461642), 
(83, 'vi', 'modules', 'Thiết lập module mới photo', '', '', 1, 1430462036), 
(84, 'vi', 'modules', 'Sửa module &ldquo;photo&rdquo;', '', '', 1, 1430462040), 
(85, 'vi', 'modules', 'Thiết lập module mới guestbook', '', '', 1, 1430462045), 
(86, 'vi', 'modules', 'Sửa module &ldquo;guestbook&rdquo;', '', '', 1, 1430462052), 
(87, 'vi', 'modules', 'Thứ tự module: download', '16 -> 4', '', 1, 1430462059), 
(88, 'vi', 'modules', 'Thứ tự module: photo', '16 -> 5', '', 1, 1430462061), 
(89, 'vi', 'modules', 'Thứ tự module: guestbook', '16 -> 6', '', 1, 1430462063), 
(90, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1430462075), 
(91, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1430462189), 
(92, 'vi', 'themes', 'Thêm block', 'Name : Guesbook', '', 1, 1430462222), 
(93, 'vi', 'themes', 'Thiết lập lại vị trí các block', 'reset position all block', '', 1, 1430462228), 
(94, 'vi', 'photo', 'Add A Category', 'category_id: 1', '', 1, 1430462351), 
(95, 'vi', 'photo', 'Add A Album', 'album_id: 1', '', 1, 1430462706), 
(96, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1430464486), 
(97, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1430464565), 
(98, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453191479), 
(99, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1453191618), 
(100, 'vi', 'support', 'Sửa nhóm nhân viên', 'nsupportid 1', '', 1, 1453191715), 
(101, 'vi', 'users', 'log_edit_user', 'userid 1', '', 1, 1453191824), 
(102, 'vi', 'themes', 'Sửa block', 'Name : Social icon', '', 1, 1453191859), 
(103, 'vi', 'themes', 'Sửa block', 'Name : footer site', '', 1, 1453192042), 
(104, 'vi', 'themes', 'Sửa block', 'Name : footer site', '', 1, 1453192078), 
(105, 'vi', 'photo', 'log_del_album', '1', '', 1, 1453192151), 
(106, 'vi', 'about', 'Delete', 'ID: 2', '', 1, 1453192175), 
(107, 'vi', 'upload', 'Upload file', 'uploads/about/tcdl.png', '', 1, 1453192210), 
(108, 'vi', 'about', 'Edit', 'ID: 1', '', 1, 1453192239), 
(109, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:113.174.226.124', '', 0, 1453192263), 
(110, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453192291), 
(111, 'vi', 'themes', 'Sửa block', 'Name : Facebook', '', 1, 1453192378), 
(112, 'vi', 'themes', 'Sửa block', 'Name : Facebook', '', 1, 1453192622), 
(113, 'vi', 'themes', 'Sửa block', 'Name : Facebook', '', 1, 1453192630), 
(114, 'vi', 'themes', 'Sửa block', 'Name : Facebook', '', 1, 1453192638), 
(115, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:113.174.226.124', '', 0, 1453192756), 
(116, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453200422), 
(117, 'vi', 'extensions', 'Cài đặt ứng dụng', 'nv4_module_tkblop-4.0.16.zip', '', 1, 1453200504), 
(118, 'vi', 'extensions', 'Cài đặt ứng dụng', 'nv4_module_tkblop.zip', '', 1, 1453200582), 
(119, 'vi', 'modules', 'Thiết lập module mới tkblop', '', '', 1, 1453200596), 
(120, 'vi', 'modules', 'Sửa module &ldquo;tkblop&rdquo;', '', '', 1, 1453200621), 
(121, 'vi', 'extensions', 'Cài đặt ứng dụng', 'nv4_module_diemex.zip', '', 1, 1453201044), 
(122, 'vi', 'modules', 'Thiết lập module mới diemex', '', '', 1, 1453201055), 
(123, 'vi', 'modules', 'Sửa module &ldquo;diemex&rdquo;', '', '', 1, 1453201072), 
(124, 'vi', 'extensions', 'Cài đặt ứng dụng', 'nv4_module_laws-4.0.16.zip', '', 1, 1453201168), 
(125, 'vi', 'modules', 'Thiết lập module mới laws', '', '', 1, 1453201173), 
(126, 'vi', 'modules', 'Sửa module &ldquo;laws&rdquo;', '', '', 1, 1453201185), 
(127, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:113.174.226.124', '', 0, 1453201198), 
(128, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453202244), 
(129, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1453202409), 
(130, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453206875), 
(131, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1453207391), 
(132, 'vi', 'voting', 'log_del_vote', 'votingid 3', '', 1, 1453208097), 
(133, 'vi', 'themes', 'Thêm block', 'Name : module block headline', '', 1, 1453208634), 
(134, 'vi', 'themes', 'Sửa block', 'Name : Tin mới', '', 1, 1453208650), 
(135, 'vi', 'themes', 'Thêm block', 'Name : Tin mới', '', 1, 1453208813), 
(136, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1453208836), 
(137, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1453208945), 
(138, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453209680), 
(139, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:116.110.218.130', '', 0, 1453297880), 
(140, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453360206), 
(141, 'vi', 'news', 'Xóa bài viêt', 'Quán phở Việt giúp hàng chục người gặp nạn ở Nepal, Lắp pháo hoa trên toà nhà cao nhất TP HCM, Tìm thấy thi thể phi công thứ hai của tiêm kích Su-22, Người Việt công tác ở Nepal hiến máu giúp nạn nhân động đất, Nghị sỹ Hữu nghị Mexico-Việt Nam kỷ nhiệm ngày 30&#x002F;4, Mỹ và Việt Nam nên là bạn, Triều Tiên bị nghi đã tái khởi động lò phản ứng hạt nhân, Chiến thắng VN - bốn trong một&#x3A; Cái nhìn của người ngoài cuộc, Nepal&#x3A; Thiếu niên sống sót thần kỳ sau 5 ngày bị vùi lấp, Luyện thi IELTS&#x002F;TOEFL iBT - Bí quyết để thành công, Học bổng thạc sỹ toàn phần tại AIT Bangkok, Nữ giảng viên “Đông trùng hạ thảo”, Thi công chức&#x3A; Thủ khoa, thạc sĩ &quot;xịn&quot; trượt còn dài dài, Đất lành của trí thức, “Tiểu Mozart” thần đồng âm nhạc tốt nghiệp đại học ở tuổi 11, Thí sinh được chỉnh sửa sai sót trong hồ sơ đăng ký dự thi, Một thời nhà giáo đi B, Thấm thía giá trị hòa bình từ lễ tri ân, “Cái nôi” đóng góp trí tuệ trực tiếp trên chiến trường, Chuyện nhà khoa học nữ từng được đề cử Nobel Hòa bình, Bắt nghi phạm tạt xăng đốt nam sinh lớp 10, 7 trai làng vướng lao lý vì &quot;chuyền tay&quot; thiếu nữ 13 tuổi, Lừa đảo bán gà giống Đông Tảo “dỏm”, 2 “quý cô” sập bẫy hacker vì tin vào quà… ảo từ trời Tây, Hà Nội&#x3A; Bắt đối tượng vụ tung đồn tin nữ sinh bị hiếp, giết để tăng view facebook, Bắt đối tượng trốn truy nã đang làm việc trên tàu đánh cá, Triệt phá ổ xóc đĩa trong rừng tràm, Triệt phá ổ nhóm chuyên cung cấp ma tuý cho vũ trường, Kiếm tiền từ việc “câu view” bằng tin đồn thất thiệt, Gã cán bộ “dởm” lừa chạy việc chiếm đoạt hơn 1 tỷ đồng, Bà cụ 62 tuổi bị lừa mất 200 triệu đồng qua điện thoại, Ngắm hình ảnh mang bầu hạnh phúc của cặp đôi đồng tính, Vững vàng khi chồng ngoại tình, Tình yêu có thực sự “đi qua dạ dày“?, Mẹ bảo..., Những xao xuyến đa mang, Thời buổi này làm sao giữ hôn nhân?, “Sao anh không gặp em sớm hơn”, Các nước thực hiện “quyền được chết” như thế nào?, Một phụ nữ nhập viện do thời trẻ bơm ngực, 8 nguyên tắc đơn giản tránh ngộ độc trong mùa hè, Quá chén rượu bia và những hệ lụy sức khỏe, Ban Dân y miền Nam&#x3A; Những hồi ức về một thời oanh liệt, Trị hen&#x3A; Chớ tin lang vườn&#33;, Thực phẩm nhiễm vi khuẩn tụ cầu khiến hơn 700 công nhân nhập viện, Hoạt chất trong súp lơ xanh có thể điều trị thoái hóa khớp, Vụ thực phẩm bẩn vào trường học&#x3A; Gần 50&#x25; bếp ăn không đủ điều kiện an toàn thực phẩm, Cứu sống sản phụ bị nhau cài răng lược và băng huyết nặng, Viêm phổi làm suy giảm thể chất và tinh thần người lớn tuổi, Khánh thành Trung tâm Ung bướu Chợ Rẫy “hạ hỏa” cho phía Nam', '', 1, 1453360223), 
(142, 'vi', 'news', 'Xóa bài viêt', 'Hành hương từ nửa đêm về đất Tổ, 13 chuyến bay không thể hạ cánh tại Tân Sơn Nhất vì mưa giông, Chi 5.000 tỷ đồng nâng cấp đường, Sài Gòn đi Đà Lạt chỉ còn 5 giờ, Hơn 30 trẻ mầm non nhập viện nghi ăn bánh mì nhiễm khuẩn, Nhóm người Việt đầu tiên rời Nepal an toàn, Nỗi niềm gia đình có người ở hai bên chiến tuyến, Hai người thiệt mạng do bom bi phát nổ, Cảnh sát giao thông bị xe đầu kéo cuốn vào gầm, Lãnh đạo Đảng, Nhà nước tưởng niệm các Anh hùng liệt sĩ tại TP HCM, Tìm thấy trung tá phi công trong buồng lái tiêm kích Su-22, Hàng nghìn người Sài Gòn đến quảng trường đi bộ Nguyễn Huệ, Năm người tử nạn khi xe Camry bị ôtô khách đâm bẹp dúm, Người phụ nữ bị nước cuốn mất tích tại trung tâm Đà Lạt, 5 ôtô húc nhau tại cửa ngõ Sài Gòn, Những chính sách có hiệu lực từ tháng 5, Có một Việt Nam nằm trong tiềm thức, Báo quốc tế đưa tin Việt Nam diễu binh mừng 40 năm thống nhất, Phần Lan bắn bom cảnh báo vật thể lạ nghi là tàu ngầm Nga, Làn sóng biểu tình từ Baltimore lan rộng khắp nước Mỹ, Nhật, Mỹ có thể tuần tra chung trên Biển Đông', '', 1, 1453360230), 
(143, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tình yêu', '', 1, 1453360236), 
(144, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sức khoẻ', '', 1, 1453360238), 
(145, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Pháp luật', '', 1, 1453360241), 
(146, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Giáo dục', '', 1, 1453360242), 
(147, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Thế giới', '', 1, 1453360244), 
(148, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Thời sự', '', 1, 1453360246), 
(149, 'vi', 'themes', 'Sửa block', 'Name : Facebook', '', 1, 1453360297), 
(150, 'vi', 'themes', 'Sửa block', 'Name : K6CT1 on Facebook', '', 1, 1453360315), 
(151, 'vi', 'news', 'Thêm chuyên mục', 'Thời sự Trong nước', '', 1, 1453360667), 
(152, 'vi', 'news', 'Thêm chuyên mục', 'Tin tức Chuyên ngành', '', 1, 1453360712), 
(153, 'vi', 'news', 'Thêm chuyên mục', 'Tin tức Chuyên ngành', '', 1, 1453361055), 
(154, 'vi', 'news', 'Thêm chuyên mục', 'Hướng nghiệp Việc làm', '', 1, 1453361418), 
(155, 'vi', 'news', 'Thêm chuyên mục', 'Tài liệu Học tập', '', 1, 1453363001), 
(156, 'vi', 'news', 'Thêm chuyên mục', 'Hướng dẫn Thực hành', '', 1, 1453363033), 
(157, 'vi', 'upload', 'Upload file', 'uploads/news/2016_01/dai-hoi-dang-lan-thu-xii-chieu-231-se-nghe-bao-cao-nhan-su.jpg', '', 1, 1453363389), 
(158, 'vi', 'news', 'Thêm bài viết', 'Đại hội Đảng lần thứ XII&#x3A; Chiều 23&#x002F;1 sẽ nghe báo cáo nhân sự', '', 1, 1453363422), 
(159, 'vi', 'news', 'Sửa bài viết', 'Đại hội Đảng lần thứ XII&#x3A; Chiều 23&#x002F;1 sẽ nghe báo cáo nhân sự', '', 1, 1453363449), 
(160, 'vi', 'upload', 'Upload file', 'uploads/news/2016_01/bui.jpg', '', 1, 1453363655), 
(161, 'vi', 'news', 'Thêm bài viết', 'Bộ giáo dục công bố một số thay đổi trong mùa tuyển sinh 2016', '', 1, 1453363738), 
(162, 'vi', 'news', 'Sửa bài viết', 'Bộ giáo dục công bố một số thay đổi trong mùa tuyển sinh 2016', '', 1, 1453363784), 
(163, 'vi', 'upload', 'Upload file', 'uploads/news/2016_01/21-11-13.jpg', '', 1, 1453364066), 
(164, 'vi', 'news', 'Thêm bài viết', 'Địa điểm nào cho trải nghiệm 4G miễn phí?', '', 1, 1453364095), 
(165, 'vi', 'modules', 'Sửa module &ldquo;download&rdquo;', '', '', 1, 1453364295), 
(166, 'vi', 'download', 'Thêm chủ đề', 'Phần mềm học tập', '', 1, 1453364494), 
(167, 'vi', 'download', 'Thêm chủ đề', 'Bài tập mẫu', '', 1, 1453364512), 
(168, 'vi', 'download', 'Thêm chủ đề', 'Ứng dụng hay', '', 1, 1453364537), 
(169, 'vi', 'modules', 'Sửa module &ldquo;guestbook&rdquo;', '', '', 1, 1453364575), 
(170, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1453364630), 
(171, 'vi', 'modules', 'Thứ tự module: contact', '19 -> 18', '', 1, 1453364645), 
(172, 'vi', 'modules', 'Thứ tự module: seek', '18 -> 19', '', 1, 1453364659), 
(173, 'vi', 'modules', 'Thứ tự module: contact', '19 -> 18', '', 1, 1453364693), 
(174, 'vi', 'upload', 'Upload file', 'uploads/news/2016_01/a998.jpg', '', 1, 1453365486), 
(175, 'vi', 'news', 'Thêm bài viết', 'Chức năng và vai trò Ngành công nghệ thông tin', '', 1, 1453365548), 
(176, 'vi', 'upload', 'Upload file', 'uploads/news/2016_01/tu-van-ngay-hoi.jpg', '', 1, 1453365694), 
(177, 'vi', 'news', 'Thêm bài viết', 'Học ngành Công nghệ thông tin ra trường làm gì?', '', 1, 1453365722), 
(178, 'vi', 'themes', 'Sửa block', 'Name : Lưu bút', '', 1, 1453365751), 
(179, 'vi', 'themes', 'Sửa block', 'Name : Thành viên', '', 1, 1453365769), 
(180, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:113.174.226.124', '', 0, 1453365854), 
(181, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453366527), 
(182, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1453366538), 
(183, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1453367301), 
(184, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:113.174.226.124', '', 0, 1453367310), 
(185, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453367443), 
(186, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1453367454), 
(187, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:113.174.226.124', '', 0, 1453367522), 
(188, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:116.110.223.34', '', 0, 1453377318), 
(189, 'vi', 'upload', 'Upload file', 'uploads/download/images/bt1-hung.png', '', 1, 1453377475), 
(190, 'vi', 'upload', 'Upload file', 'uploads/download/files/bt1.zip', '', 1, 1453378128), 
(191, 'vi', 'download', 'Thêm file mới', 'Bài tập 1 Vùng chọn và Layer &#91;Photoshop&#93;', '', 1, 1453378149), 
(192, 'vi', 'download', 'Sửa file', 'Bài tập 1 Vùng chọn và Layer &#91;Photoshop&#93;', '', 1, 1453378299), 
(193, 'vi', 'upload', 'Upload file', 'uploads/download/images/bt2-hung.png', '', 1, 1453378413), 
(194, 'vi', 'upload', 'Upload file', 'uploads/download/files/bt2.zip', '', 1, 1453378610), 
(195, 'vi', 'download', 'Thêm file mới', 'Bài tập 2 Vùng chọn và Layer &#91;Photoshop&#93;', '', 1, 1453378637), 
(196, 'vi', 'upload', 'Upload file', 'uploads/download/images/ket-qua.jpg', '', 1, 1453379408), 
(197, 'vi', 'upload', 'Upload file', 'uploads/download/files/bt2.2.zip', '', 1, 1453379444), 
(198, 'vi', 'download', 'Thêm file mới', 'Bài tập 2.2 Vùng chọn và Layer &#91;Photoshop&#93;', '', 1, 1453379538), 
(199, 'vi', 'upload', 'Upload file', 'uploads/download/images/ketqua.jpg', '', 1, 1453379635), 
(200, 'vi', 'upload', 'Upload file', 'uploads/download/files/bt3.zip', '', 1, 1453379667), 
(201, 'vi', 'download', 'Thêm file mới', 'Bài tập 3 Vùng chọn và Layer &#91;Photoshop&#93;', '', 1, 1453379757), 
(202, 'vi', 'download', 'Sửa file', 'Bài tập 3 Vùng chọn và Layer &#91;Photoshop&#93;', '', 1, 1453379784), 
(203, 'vi', 'upload', 'Upload file', 'uploads/download/images/img-1347703471-1.jpg', '', 1, 1453380051), 
(204, 'vi', 'download', 'Thêm file mới', 'Adobe photoshop CS6 Portable', '', 1, 1453380201), 
(205, 'vi', 'upload', 'Upload file', 'uploads/download/images/cs.png', '', 1, 1453380520), 
(206, 'vi', 'download', 'Thêm file mới', 'Adobe Photoshop CS6 Setup', '', 1, 1453380663), 
(207, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1453381339), 
(208, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:116.110.223.34', '', 0, 1453381859), 
(209, 'vi', 'voting', 'Sửa thăm dò của bạn', 'Bạn biết đến Website này từ đâu?', '', 1, 1453381964), 
(210, 'vi', 'voting', 'Sửa thăm dò của bạn', 'Bạn biết đến Website này từ đâu?', '', 1, 1453382010), 
(211, 'vi', 'themes', 'Sửa block', 'Name : Social icon', '', 1, 1453382119), 
(212, 'vi', 'themes', 'Sửa block', 'Name : Social icon', '', 1, 1453382261), 
(213, 'vi', 'themes', 'Sửa block', 'Name : Social icon', '', 1, 1453382670), 
(214, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:116.110.223.34', '', 0, 1453382953), 
(215, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453414134), 
(216, 'vi', 'upload', 'Upload file', 'uploads/news/2016_01/tcdl-1.jpg', '', 1, 1453414266), 
(217, 'vi', 'upload', 'Upload file', 'uploads/news/2016_01/tcdl-2.jpg', '', 1, 1453414318), 
(218, 'vi', 'upload', 'Upload file', 'uploads/news/2016_01/tcdl-3.jpg', '', 1, 1453414347), 
(219, 'vi', 'news', 'Thêm bài viết', 'Trường Trung cấp Đắk Lắk kỉ niệm 5 năm thành lập và khai giảng năm học 2015-2016', '', 1, 1453414418), 
(220, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1453415600), 
(221, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1453415942), 
(222, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1453416459), 
(223, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1453418729), 
(224, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1453418751), 
(225, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1453418788), 
(226, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1453419401), 
(227, 'vi', 'extensions', 'Cài đặt ứng dụng', 'module-video-clips-v4-0-01.zip', '', 1, 1453419473), 
(228, 'vi', 'modules', 'Thiết lập module mới video-clip', '', '', 1, 1453419495), 
(229, 'vi', 'modules', 'Sửa module &ldquo;video-clip&rdquo;', '', '', 1, 1453419516), 
(230, 'vi', 'video-clip', 'Thêm thể loại mới', 'ID 1', '', 1, 1453419541), 
(231, 'vi', 'video-clip', 'Thêm thể loại mới', 'ID 2', '', 1, 1453419563), 
(232, 'vi', 'video-clip', 'Thêm thể loại mới', 'ID 3', '', 1, 1453419613), 
(233, 'vi', 'video-clip', 'Thêm thể loại mới', 'ID 4', '', 1, 1453419654), 
(234, 'vi', 'modules', 'Thứ tự module: video-clip', '20 -> 6', '', 1, 1453419667), 
(235, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1453419692), 
(236, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1453419760), 
(237, 'vi', 'video-clip', 'Thêm video-clip', 'Id: 1', '', 1, 1453419856), 
(238, 'vi', 'themes', 'Thêm block', 'Name : module detail', '', 1, 1453419930), 
(239, 'vi', 'themes', 'Thêm block', 'Name : module detail', '', 1, 1453420007), 
(240, 'vi', 'themes', 'Thêm block', 'Name : video', '', 1, 1453420260), 
(241, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1453420294), 
(242, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:113.174.226.124', '', 0, 1453420298), 
(243, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453460841), 
(244, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453461612), 
(245, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:113.174.226.124', '', 0, 1453463728), 
(246, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.174.226.124', '', 0, 1453464478), 
(247, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1453464559);


-- ---------------------------------------


--
-- Table structure for table `ctypa_notification`
--

DROP TABLE IF EXISTS `ctypa_notification`;
CREATE TABLE `ctypa_notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` mediumint(8) unsigned NOT NULL,
  `send_from` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(1) unsigned NOT NULL,
  `language` char(3) NOT NULL,
  `module` varchar(50) NOT NULL,
  `type` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  `view` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_plugin`
--

DROP TABLE IF EXISTS `ctypa_plugin`;
CREATE TABLE `ctypa_plugin` (
  `pid` tinyint(4) NOT NULL AUTO_INCREMENT,
  `plugin_file` varchar(50) NOT NULL,
  `plugin_area` tinyint(4) NOT NULL,
  `weight` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `plugin_file` (`plugin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_sessions`
--

DROP TABLE IF EXISTS `ctypa_sessions`;
CREATE TABLE `ctypa_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_sessions`
--

INSERT INTO `ctypa_sessions` VALUES
('oe05tgeplsfir56o46e0kkst57', 0, 'guest', 1456311258);


-- ---------------------------------------


--
-- Table structure for table `ctypa_setup`
--

DROP TABLE IF EXISTS `ctypa_setup`;
CREATE TABLE `ctypa_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_setup_extensions`
--

DROP TABLE IF EXISTS `ctypa_setup_extensions`;
CREATE TABLE `ctypa_setup_extensions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL DEFAULT 'other',
  `title` varchar(55) NOT NULL,
  `is_sys` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `basename` varchar(50) NOT NULL DEFAULT '',
  `table_prefix` varchar(55) NOT NULL DEFAULT '',
  `version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) DEFAULT '',
  UNIQUE KEY `title` (`type`,`title`),
  KEY `id` (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_setup_extensions`
--

INSERT INTO `ctypa_setup_extensions` VALUES
(0, 'module', 'about', 0, 0, 'page', 'about', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(19, 'module', 'banners', 1, 0, 'banners', 'banners', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(20, 'module', 'contact', 0, 1, 'contact', 'contact', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(1, 'module', 'news', 0, 1, 'news', 'news', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(21, 'module', 'voting', 0, 0, 'voting', 'voting', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(284, 'module', 'seek', 1, 0, 'seek', 'seek', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(24, 'module', 'users', 1, 0, 'users', 'users', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(25, 'module', 'download', 0, 1, 'download', 'download', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(27, 'module', 'statistics', 0, 0, 'statistics', 'statistics', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(29, 'module', 'menu', 0, 1, 'menu', 'menu', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(283, 'module', 'feeds', 1, 0, 'feeds', 'feeds', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(282, 'module', 'page', 1, 1, 'page', 'page', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(281, 'module', 'comment', 1, 0, 'comment', 'comment', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'default', 0, 0, 'default', 'default', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'modern', 0, 0, 'modern', 'modern', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'mobile_nukeviet', 0, 0, 'mobile_nukeviet', 'mobile_nukeviet', '4.0.13 1427991873', 1430288935, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'guestbook', 0, 1, 'guestbook', 'guestbook', '3.0.1 1395235974', 1430462034, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'support', 0, 1, 'support', 'support', '4.0 1416416400', 1430438300, 'Pa Software Solutions ( contact@vinanat.vn)', ''), 
(0, 'module', 'photo', 0, 1, 'photo', 'photo', '4.0.01 1421848859', 1430462034, 'DANGDINHTU (dlinhvan@gmail.com)', ''), 
(0, 'module', 'tkblop', 0, 1, 'tkblop', 'tkblop', '4.0.16 1453200590', 1453200590, 'Trần Thế Vinh (gangucay@gmail.com)', 'module update to 4.x by webvang'), 
(0, 'module', 'diemex', 0, 0, 'diemex', 'diemex', '4.0.16 1453201047', 1453201047, 'hongoctrien (01692777913@yahoo.com)', 'module update to 4.x by webvang'), 
(0, 'module', 'laws', 0, 1, 'laws', 'laws', '4.0.16 1453201170', 1453201170, 'PCD-GROUP (contact@dinhpc.com)', 'Update to 4.x webvang (hoang.nguyen@webvang.vn)'), 
(79, 'module', 'video-clip', 0, 1, 'video-clip', 'video_clip', '4.0.01 1453419482', 1453419482, 'hoaquynhtim99 (phantandung92@gmail.com)', 'Module nhỏ gọn nhưng tính năng đầy đủ và hấp dẫn, quản lý video và phát video, hiển thị video dưới dạng ajax mềm mại. Hỗ trợ tốt cho SEO.');


-- ---------------------------------------


--
-- Table structure for table `ctypa_setup_language`
--

DROP TABLE IF EXISTS `ctypa_setup_language`;
CREATE TABLE `ctypa_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_setup_language`
--

INSERT INTO `ctypa_setup_language` VALUES
('vi', 1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_upload_dir`
--

DROP TABLE IF EXISTS `ctypa_upload_dir`;
CREATE TABLE `ctypa_upload_dir` (
  `did` mediumint(8) NOT NULL AUTO_INCREMENT,
  `dirname` varchar(255) DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `thumb_type` tinyint(4) NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) NOT NULL DEFAULT '0',
  `thumb_quality` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  UNIQUE KEY `name` (`dirname`)
) ENGINE=MyISAM  AUTO_INCREMENT=46  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_upload_dir`
--

INSERT INTO `ctypa_upload_dir` VALUES
(0, '', 0, 3, 100, 150, 90), 
(1, 'images', 0, 0, 0, 0, 0), 
(2, 'images/rank', 0, 0, 0, 0, 0), 
(3, 'uploads', 0, 0, 0, 0, 0), 
(4, 'uploads/about', 1453192201, 0, 0, 0, 0), 
(5, 'uploads/banners', 0, 0, 0, 0, 0), 
(6, 'uploads/contact', 0, 0, 0, 0, 0), 
(7, 'uploads/menu', 0, 0, 0, 0, 0), 
(8, 'uploads/news', 0, 0, 0, 0, 0), 
(9, 'uploads/news/2015_03', 0, 0, 0, 0, 0), 
(10, 'uploads/news/source', 1453414253, 0, 0, 0, 0), 
(11, 'uploads/news/temp_pic', 0, 0, 0, 0, 0), 
(12, 'uploads/news/topics', 0, 0, 0, 0, 0), 
(13, 'uploads/page', 0, 0, 0, 0, 0), 
(14, 'uploads/users', 0, 0, 0, 0, 0), 
(21, 'uploads/download', 0, 0, 0, 0, 0), 
(16, 'uploads/news/2015_05', 1430432179, 0, 0, 0, 0), 
(24, 'uploads/download/temp', 0, 0, 0, 0, 0), 
(23, 'uploads/download/images', 1453379624, 0, 0, 0, 0), 
(22, 'uploads/download/files', 1453378122, 0, 0, 0, 0), 
(20, 'uploads/news/2015_05/01', 0, 0, 0, 0, 0), 
(25, 'uploads/photo', 0, 0, 0, 0, 0), 
(26, 'uploads/photo/images', 0, 0, 0, 0, 0), 
(27, 'uploads/photo/thumbs', 0, 0, 0, 0, 0), 
(28, 'uploads/photo/temp', 0, 0, 0, 0, 0), 
(29, 'uploads/guestbook', 0, 0, 0, 0, 0), 
(30, 'uploads/photo/images/2015', 0, 0, 0, 0, 0), 
(31, 'uploads/photo/images/2015/05', 0, 0, 0, 0, 0), 
(32, 'uploads/photo/thumb', 0, 0, 0, 0, 0), 
(33, 'uploads/photo/thumb/2015', 0, 0, 0, 0, 0), 
(34, 'uploads/photo/thumb/2015/05', 0, 0, 0, 0, 0), 
(40, 'uploads/news/2015_04', 1453414256, 0, 0, 0, 0), 
(36, 'uploads/tkblop', 0, 0, 0, 0, 0), 
(37, 'uploads/diemex', 0, 0, 0, 0, 0), 
(38, 'uploads/laws', 0, 0, 0, 0, 0), 
(39, 'uploads/news/2016_01', 1453414251, 0, 0, 0, 0), 
(41, 'uploads/laws/2016_01', 0, 0, 0, 0, 0), 
(42, 'uploads/video-clip', 0, 0, 0, 0, 0), 
(43, 'uploads/video-clip/icons', 0, 0, 0, 0, 0), 
(44, 'uploads/video-clip/images', 0, 0, 0, 0, 0), 
(45, 'uploads/video-clip/video', 0, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_upload_file`
--

DROP TABLE IF EXISTS `ctypa_upload_file`;
CREATE TABLE `ctypa_upload_file` (
  `name` varchar(255) NOT NULL,
  `ext` varchar(10) NOT NULL DEFAULT '',
  `type` varchar(5) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `src` varchar(255) NOT NULL DEFAULT '',
  `srcwidth` int(11) NOT NULL DEFAULT '0',
  `srcheight` int(11) NOT NULL DEFAULT '0',
  `sizes` varchar(50) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alt` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `did` (`did`,`title`),
  KEY `userid` (`userid`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_upload_file`
--

INSERT INTO `ctypa_upload_file` VALUES
('anh-1-1430...jpg', 'jpg', 'image', 65535, 'files/news/2015_05/anh-1-1430419430_490x294.jpg', 80, 48, '490|294', 1, 1430432182, 16, 'anh-1-1430419430_490x294.jpg', 'anh 1 1430419430 490x294'), 
('tcdl.png', 'png', 'image', 579660, 'files/about/tcdl.png', 80, 80, '1000|1000', 1, 1453192210, 4, 'tcdl.png', 'tcdl'), 
('dai-hoi-da...jpg', 'jpg', 'image', 169789, 'files/news/2016_01/dai-hoi-dang-lan-thu-xii-chieu-231-se-nghe-bao-cao-nhan-su.jpg', 80, 45, '640|354', 1, 1453363392, 39, 'dai-hoi-dang-lan-thu-xii-chieu-231-se-nghe-bao-cao-nhan-su.jpg', 'dai hoi dang lan thu xii chieu 231 se nghe bao cao nhan su'), 
('bui.jpg', 'jpg', 'image', 40043, 'files/news/2016_01/bui.jpg', 80, 54, '500|333', 1, 1453363655, 39, 'bui.jpg', 'bui'), 
('21-11-13.jpg', 'jpg', 'image', 30483, 'files/news/2016_01/21-11-13.jpg', 80, 60, '500|375', 1, 1453364080, 39, '21-11-13.jpg', '21 11 13'), 
('a998.jpg', 'jpg', 'image', 94714, 'files/news/2016_01/a998.jpg', 80, 48, '640|384', 1, 1453365487, 39, 'a998.jpg', 'a998'), 
('tu-van-nga...jpg', 'jpg', 'image', 49721, 'files/news/2016_01/tu-van-ngay-hoi.jpg', 80, 54, '640|427', 1, 1453365694, 39, 'tu-van-ngay-hoi.jpg', 'tu van ngay hoi'), 
('bt1-hung.png', 'png', 'image', 352467, 'files/download/images/bt1-hung.png', 80, 80, '600|600', 1, 1453377476, 23, 'bt1-hung.png', 'bt1 hung'), 
('bt1.zip', 'zip', 'file', 522065, 'images/zip.gif', 32, 32, '|', 1, 1453378129, 22, 'bt1.zip', 'bt1'), 
('bt2-hung.png', 'png', 'image', 220788, 'files/download/images/bt2-hung.png', 55, 80, '290|420', 1, 1453378417, 23, 'bt2-hung.png', 'bt2 hung'), 
('bt2.zip', 'zip', 'file', 636249, 'images/zip.gif', 32, 32, '|', 1, 1453378623, 22, 'bt2.zip', 'bt2'), 
('ket-qua.jpg', 'jpg', 'image', 133540, 'files/download/images/ket-qua.jpg', 50, 80, '258|412', 1, 1453379411, 23, 'ket-qua.jpg', 'ket qua'), 
('bt2.2.zip', 'zip', 'file', 294883, 'images/zip.gif', 32, 32, '|', 1, 1453379450, 22, 'bt2.2.zip', 'bt2 2'), 
('ketqua.jpg', 'jpg', 'image', 102802, 'files/download/images/ketqua.jpg', 67, 80, '240|290', 1, 1453379636, 23, 'ketqua.jpg', 'Ketqua'), 
('bt3.zip', 'zip', 'file', 698375, 'images/zip.gif', 32, 32, '|', 1, 1453379668, 22, 'bt3.zip', 'bt3'), 
('img-134770...jpg', 'jpg', 'image', 61999, 'files/download/images/img-1347703471-1.jpg', 80, 68, '497|420', 1, 1453380052, 23, 'img-1347703471-1.jpg', 'img 1347703471 1'), 
('cs.png', 'png', 'image', 342087, 'files/download/images/cs.png', 80, 54, '546|370', 1, 1453380521, 23, 'cs.png', 'cs'), 
('tcdl-1.jpg', 'jpg', 'image', 67483, 'files/news/2016_01/tcdl-1.jpg', 80, 50, '826|517', 1, 1453414267, 39, 'tcdl-1.jpg', 'TCDL 1'), 
('tcdl-2.jpg', 'jpg', 'image', 68223, 'files/news/2016_01/tcdl-2.jpg', 80, 48, '826|490', 1, 1453414318, 39, 'tcdl-2.jpg', 'TCDL 2'), 
('tcdl-3.jpg', 'jpg', 'image', 62400, 'files/news/2016_01/tcdl-3.jpg', 80, 45, '826|461', 1, 1453414348, 39, 'tcdl-3.jpg', 'TCDL 3');


-- ---------------------------------------


--
-- Table structure for table `ctypa_users`
--

DROP TABLE IF EXISTS `ctypa_users`;
CREATE TABLE `ctypa_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(80) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `first_name` varchar(100) NOT NULL DEFAULT '',
  `last_name` varchar(100) NOT NULL DEFAULT '',
  `gender` char(1) DEFAULT '',
  `photo` varchar(255) DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(50) DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  `last_openid` varchar(255) DEFAULT '',
  `idsite` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`),
  KEY `idsite` (`idsite`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_users`
--

INSERT INTO `ctypa_users` VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '{SSHA}g4pvuFb58iWFXLfDKMMWkv4Ot+V5d2t3', 'taynguyenxanh20@gmail.com', 'Hùng', 'Trần Mạnh', 'M', 'uploads/users/bia_ncvjwwkv_1.jpg', 534186000, '', 1430289196, 'Không cần thiết', 'khỏi trả lời', '', 1, 1, '', 1, '', 1430289196, '', '', '', 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_users_config`
--

DROP TABLE IF EXISTS `ctypa_users_config`;
CREATE TABLE `ctypa_users_config` (
  `config` varchar(100) NOT NULL,
  `content` text,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_users_config`
--

INSERT INTO `ctypa_users_config` VALUES
('access_admin', 'a:6:{s:12:\"access_addus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:14:\"access_waiting\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_editus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:\"access_delus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_passus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_groups\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}}', 1352873462), 
('password_simple', '000000|1234|2000|12345|111111|123123|123456|654321|696969|1234567|12345678|123456789|1234567890|aaaaaa|abc123|abc123@|abc@123|adobe1|adobe123|azerty|baseball|dragon|football|harley|iloveyou|jennifer|jordan|letmein|macromedia|master|michael|monkey|mustang|password|photoshop|pussy|qwerty|shadow|superman', 1430288935), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1430288935), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1430288935), 
('avatar_width', '80', 1430288935), 
('avatar_height', '80', 1430288935), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br /> <br /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br /> <br /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br /> <br /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `ctypa_users_field`
--

DROP TABLE IF EXISTS `ctypa_users_field`;
CREATE TABLE `ctypa_users_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect') NOT NULL DEFAULT 'textbox',
  `field_choices` text NOT NULL,
  `sql_choices` text NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback') NOT NULL DEFAULT 'none',
  `match_regex` varchar(250) NOT NULL DEFAULT '',
  `func_callback` varchar(75) NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_register` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_editable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_profile` tinyint(4) NOT NULL DEFAULT '1',
  `class` varchar(50) NOT NULL,
  `language` text NOT NULL,
  `default_value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_users_info`
--

DROP TABLE IF EXISTS `ctypa_users_info`;
CREATE TABLE `ctypa_users_info` (
  `userid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_users_info`
--

INSERT INTO `ctypa_users_info` VALUES
(1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_users_openid`
--

DROP TABLE IF EXISTS `ctypa_users_openid`;
CREATE TABLE `ctypa_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_users_question`
--

DROP TABLE IF EXISTS `ctypa_users_question`;
CREATE TABLE `ctypa_users_question` (
  `qid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_users_question`
--

INSERT INTO `ctypa_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `ctypa_users_reg`
--

DROP TABLE IF EXISTS `ctypa_users_reg`;
CREATE TABLE `ctypa_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(80) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `first_name` varchar(255) NOT NULL DEFAULT '',
  `last_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  `users_info` text,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_about`
--

DROP TABLE IF EXISTS `ctypa_vi_about`;
CREATE TABLE `ctypa_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_about`
--

INSERT INTO `ctypa_vi_about` VALUES
(1, 'Giới thiệu về lớp K6CT1', 'Gioi-thieu-ve-lop-K6CT1', 'tcdl.png', 'logo Trung cấp Đăk Lăk', 'Chưa có mô tả', 'Chưa cập nhật thông tin', 'giới thiệu', 0, '4', '', 0, 1, 1, 1275320174, 1453192239, 1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_about_config`
--

DROP TABLE IF EXISTS `ctypa_vi_about_config`;
CREATE TABLE `ctypa_vi_about_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_about_config`
--

INSERT INTO `ctypa_vi_about_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_blocks_groups`
--

DROP TABLE IF EXISTS `ctypa_vi_blocks_groups`;
CREATE TABLE `ctypa_vi_blocks_groups` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `template` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` tinyint(4) DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=37  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_blocks_groups`
--

INSERT INTO `ctypa_vi_blocks_groups` VALUES
(2, 'default', 'statistics', 'global.counter.php', 'Thống kê truy cập', '', '', '[LEFT]', 0, 1, '6', 1, 4, ''), 
(4, 'default', 'about', 'global.page_list.php', 'Giới thiệu', '', 'primary', '[RIGHT]', 0, 1, '6', 1, 1, 'a:2:{s:12:\"title_length\";i:24;s:6:\"numrow\";i:5;}'), 
(5, 'default', 'users', 'global.login.php', 'Thành viên', '', 'primary', '[RIGHT]', 0, 1, '6', 1, 4, ''), 
(6, 'default', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '6', 1, 6, ''), 
(17, 'default', 'menu', 'global.site_mods.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, 1, '6', 1, 1, 'a:2:{s:12:\"title_length\";i:20;s:14:\"module_in_menu\";a:10:{i:0;s:4:\"news\";i:1;s:8:\"download\";i:2;s:5:\"photo\";i:3;s:10:\"video-clip\";i:4;s:9:\"guestbook\";i:5;s:6:\"tkblop\";i:6;s:6:\"diemex\";i:7;s:4:\"laws\";i:8;s:7:\"contact\";i:9;s:4:\"seek\";}}'), 
(19, 'default', 'page', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '6', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:279:\"<div><strong>TRƯỜNG TRUNG CẤP ĐĂK LĂK - LỚP CNTT K6CT1</strong></div><div>Địa chỉ: Số 01 Đinh Tiên Hoàng, TP. Buôn Ma Thuộc, Đăk Lăk<br  />Điện thoại : 0944.62 47 48<br  />Website: http://k6ct1.com</div><div>Email: info@k6ct1.com</div><p>&nbsp;</p>\";}'), 
(21, 'default', 'theme', 'global.social.php', 'Social icon', '', 'default_no_title', '[SOCIAL_ICONS]', 0, 1, '6', 1, 1, 'a:4:{s:8:\"facebook\";s:45:\"http://www.facebook.com/K6CT1-541749769327900\";s:11:\"google_plus\";s:46:\"https://plus.google.com/102690091722588686570/\";s:7:\"youtube\";s:23:\"https://www.youtube.com\";s:7:\"twitter\";s:20:\"https://twitter.com/\";}'), 
(22, 'default', 'theme', 'global.menu_footer.php', 'Menu footer', '', 'no_title', '[MENU_FOOTER]', 0, 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:4:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";}}'), 
(9, 'modern', 'news', 'module.block_newscenter.php', 'Tin mới nhất', '', 'no_title', '[HEADER]', 0, 1, '6', 0, 1, 'a:3:{s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(10, 'modern', 'about', 'global.about.php', 'Giới thiệu', '', 'no_title_html', '[RIGHT]', 0, 1, '6', 1, 1, ''), 
(11, 'modern', 'users', 'global.login.php', 'Đăng nhập', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''), 
(12, 'modern', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '6', 1, 3, ''), 
(13, 'modern', 'statistics', 'global.counter.php', 'Bộ đếm', '', '', '[RIGHT]', 0, 1, '0', 1, 4, ''), 
(14, 'modern', 'news', 'module.block_newsright.php', 'News Right', '', 'no_title', '[RIGHT]', 0, 1, '6', 0, 5, ''), 
(15, 'modern', 'banners', 'global.banners.php', 'Quảng cáo top banner', '', 'no_title', '[TOPADV]', 0, 1, '6', 1, 1, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(16, 'modern', 'menu', 'global.superfish.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:20;}'), 
(18, 'modern', 'page', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '6', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:274:\"© Copyright NukeViet 4. All right reserved.<br  />Xây dựng trên nền tảng <a href=\"http://nukeviet.vn/\" title=\"Mã nguồn mở NukeViet\">Mã nguồn mở NukeViet</a>. <a href=\"http://vinades.vn/\" title=\"Thiết kế web\">Thiết kế website</a> bởi VINADES.,JSC\";}'), 
(20, 'mobile_nukeviet', 'theme', 'global.menu.php', 'global menu', '', 'no_title', '[MENU_SITE]', 0, 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:6:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:10:\"statistics\";i:5;s:6:\"voting\";}}'), 
(24, 'default', 'theme', 'global.calendar_event.php', 'Sự kiện', '', 'primary_no_boder', '[HEADER_RIGHT]', 0, 1, '6', 1, 1, ''), 
(26, 'default', 'news', 'global.block_news_cat_cal.php', 'global block news cat cal', '', 'border', '[TOP]', 0, 1, '6', 1, 1, 'a:7:{s:5:\"catid\";a:1:{i:0;s:1:\"1\";}s:6:\"numrow\";i:30;s:7:\"numview\";i:10;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";s:12:\"title_length\";i:30;}'), 
(29, 'default', 'theme', 'global.block_facebook_like_box.php', 'K6CT1 on Facebook', '', '', '[LEFT]', 0, 1, '6', 1, 2, 'a:6:{s:3:\"url\";s:46:\"https://www.facebook.com/K6CT1-541749769327900\";s:6:\"height\";i:200;s:6:\"scheme\";s:5:\"light\";s:5:\"faces\";i:1;s:6:\"stream\";i:0;s:6:\"header\";i:1;}'), 
(30, 'default', 'news', 'global.block_groups.php', 'Tin mới', '', '', '[LEFT]', 0, 1, '6', 1, 3, 'a:5:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:10;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(31, 'default', 'guestbook', 'global.new.php', 'Lưu bút', '', 'primary_no_boder', '[RIGHT]', 0, 1, '6', 1, 2, 'a:2:{s:6:\"numrow\";i:5;s:6:\"lenght\";i:100;}'), 
(33, 'default', 'news', 'global.block_pa_groups.php', 'Tin mới', '/groups/Tin-moi/', 'no_title', '[HEADER]', 0, 1, '6', 0, 1, 'a:5:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:5;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";}');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_blocks_weight`
--

DROP TABLE IF EXISTS `ctypa_vi_blocks_weight`;
CREATE TABLE `ctypa_vi_blocks_weight` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `func_id` mediumint(8) NOT NULL DEFAULT '0',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_blocks_weight`
--

INSERT INTO `ctypa_vi_blocks_weight` VALUES
(19, 2, 1), 
(19, 36, 1), 
(19, 39, 1), 
(19, 42, 1), 
(19, 43, 1), 
(19, 54, 1), 
(19, 55, 1), 
(19, 56, 1), 
(19, 57, 1), 
(19, 27, 1), 
(19, 47, 1), 
(19, 11, 1), 
(19, 52, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 13, 1), 
(19, 15, 1), 
(19, 16, 1), 
(19, 51, 1), 
(19, 53, 1), 
(19, 46, 1), 
(19, 33, 1), 
(19, 32, 1), 
(19, 30, 1), 
(19, 29, 1), 
(19, 31, 1), 
(19, 28, 1), 
(19, 34, 1), 
(19, 24, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 26, 1), 
(19, 23, 1), 
(19, 18, 1), 
(19, 25, 1), 
(19, 17, 1), 
(19, 22, 1), 
(19, 19, 1), 
(19, 48, 1), 
(19, 50, 1), 
(19, 58, 1), 
(19, 35, 1), 
(2, 2, 3), 
(2, 36, 3), 
(2, 39, 3), 
(2, 42, 3), 
(2, 43, 3), 
(2, 54, 3), 
(2, 55, 3), 
(2, 56, 3), 
(2, 57, 3), 
(2, 27, 3), 
(2, 47, 3), 
(2, 11, 3), 
(2, 52, 3), 
(2, 5, 3), 
(2, 6, 3), 
(2, 7, 3), 
(2, 13, 3), 
(2, 15, 3), 
(2, 16, 3), 
(2, 51, 3), 
(2, 53, 3), 
(2, 46, 3), 
(2, 33, 3), 
(2, 32, 3), 
(2, 30, 3), 
(2, 29, 3), 
(2, 31, 3), 
(2, 28, 3), 
(2, 34, 3), 
(2, 24, 3), 
(2, 20, 3), 
(2, 21, 3), 
(2, 26, 3), 
(2, 23, 3), 
(2, 18, 3), 
(2, 25, 3), 
(2, 17, 3), 
(2, 22, 3), 
(2, 19, 3), 
(2, 48, 3), 
(2, 50, 3), 
(2, 58, 3), 
(2, 35, 3), 
(22, 2, 1), 
(22, 36, 1), 
(22, 39, 1), 
(22, 42, 1), 
(22, 43, 1), 
(22, 54, 1), 
(22, 55, 1), 
(22, 56, 1), 
(22, 57, 1), 
(22, 27, 1), 
(22, 47, 1), 
(22, 11, 1), 
(22, 52, 1), 
(22, 5, 1), 
(22, 6, 1), 
(22, 7, 1), 
(22, 13, 1), 
(22, 15, 1), 
(22, 16, 1), 
(22, 51, 1), 
(22, 53, 1), 
(22, 46, 1), 
(22, 33, 1), 
(22, 32, 1), 
(22, 30, 1), 
(22, 29, 1), 
(22, 31, 1), 
(22, 28, 1), 
(22, 34, 1), 
(22, 24, 1), 
(22, 20, 1), 
(22, 21, 1), 
(22, 26, 1), 
(22, 23, 1), 
(22, 18, 1), 
(22, 25, 1), 
(22, 17, 1), 
(22, 22, 1), 
(22, 19, 1), 
(22, 48, 1), 
(22, 50, 1), 
(22, 58, 1), 
(22, 35, 1), 
(17, 2, 1), 
(17, 36, 1), 
(17, 39, 1), 
(17, 42, 1), 
(17, 43, 1), 
(17, 54, 1), 
(17, 55, 1), 
(17, 56, 1), 
(17, 57, 1), 
(17, 27, 1), 
(17, 47, 1), 
(17, 11, 1), 
(17, 52, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 13, 1), 
(17, 15, 1), 
(17, 16, 1), 
(17, 51, 1), 
(17, 53, 1), 
(17, 46, 1), 
(17, 33, 1), 
(17, 32, 1), 
(17, 30, 1), 
(17, 29, 1), 
(17, 31, 1), 
(17, 28, 1), 
(17, 34, 1), 
(17, 24, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 26, 1), 
(17, 23, 1), 
(17, 18, 1), 
(17, 25, 1), 
(17, 17, 1), 
(17, 22, 1), 
(17, 19, 1), 
(17, 48, 1), 
(17, 50, 1), 
(17, 58, 1), 
(17, 35, 1), 
(4, 2, 1), 
(4, 36, 1), 
(4, 39, 1), 
(4, 42, 1), 
(4, 43, 1), 
(4, 54, 1), 
(4, 55, 1), 
(4, 56, 1), 
(4, 57, 1), 
(4, 27, 1), 
(4, 47, 1), 
(4, 11, 1), 
(4, 52, 1), 
(4, 5, 1), 
(4, 6, 1), 
(4, 7, 1), 
(4, 13, 1), 
(4, 15, 1), 
(4, 16, 1), 
(4, 51, 1), 
(4, 53, 1), 
(4, 46, 1), 
(4, 33, 1), 
(4, 32, 1), 
(4, 30, 1), 
(4, 29, 1), 
(4, 31, 1), 
(4, 28, 1), 
(4, 34, 1), 
(4, 24, 1), 
(4, 20, 1), 
(4, 21, 1), 
(4, 26, 1), 
(4, 23, 1), 
(4, 18, 1), 
(4, 25, 1), 
(4, 17, 1), 
(4, 22, 1), 
(4, 19, 1), 
(4, 48, 1), 
(4, 50, 1), 
(4, 58, 1), 
(4, 35, 1), 
(5, 2, 3), 
(5, 36, 3), 
(5, 39, 3), 
(5, 42, 3), 
(5, 43, 3), 
(5, 54, 3), 
(5, 55, 3), 
(5, 56, 3), 
(5, 57, 3), 
(5, 27, 3), 
(5, 47, 3), 
(5, 11, 3), 
(5, 52, 3), 
(5, 5, 3), 
(5, 6, 3), 
(5, 7, 3), 
(5, 13, 3), 
(5, 15, 3), 
(5, 16, 3), 
(5, 51, 3), 
(5, 53, 3), 
(5, 46, 3), 
(5, 33, 3), 
(5, 32, 3), 
(5, 30, 3), 
(5, 29, 3), 
(5, 31, 3), 
(5, 28, 3), 
(5, 34, 3), 
(5, 24, 3), 
(5, 20, 3), 
(5, 21, 3), 
(5, 26, 3), 
(5, 23, 3), 
(5, 18, 3), 
(5, 25, 3), 
(5, 17, 3), 
(5, 22, 3), 
(5, 19, 3), 
(5, 48, 3), 
(5, 50, 3), 
(5, 58, 3), 
(5, 35, 3), 
(6, 2, 4), 
(6, 36, 4), 
(6, 39, 4), 
(6, 42, 4), 
(6, 43, 4), 
(6, 54, 4), 
(6, 55, 4), 
(6, 56, 4), 
(6, 57, 4), 
(6, 27, 4), 
(6, 47, 4), 
(6, 11, 4), 
(6, 52, 4), 
(6, 5, 4), 
(6, 6, 4), 
(6, 7, 4), 
(6, 13, 4), 
(6, 15, 4), 
(6, 16, 4), 
(6, 51, 4), 
(6, 53, 4), 
(6, 46, 4), 
(6, 33, 4), 
(6, 32, 4), 
(6, 30, 4), 
(6, 29, 4), 
(6, 31, 4), 
(6, 28, 4), 
(6, 34, 4), 
(6, 24, 4), 
(6, 20, 4), 
(6, 21, 4), 
(6, 26, 4), 
(6, 23, 4), 
(6, 18, 4), 
(6, 25, 4), 
(6, 17, 4), 
(6, 22, 4), 
(6, 19, 4), 
(6, 48, 4), 
(6, 50, 4), 
(6, 58, 4), 
(6, 35, 4), 
(21, 2, 1), 
(21, 36, 1), 
(21, 39, 1), 
(21, 42, 1), 
(21, 43, 1), 
(21, 54, 1), 
(21, 55, 1), 
(21, 56, 1), 
(21, 57, 1), 
(21, 27, 1), 
(21, 47, 1), 
(21, 11, 1), 
(21, 52, 1), 
(21, 5, 1), 
(21, 6, 1), 
(21, 7, 1), 
(21, 13, 1), 
(21, 15, 1), 
(21, 16, 1), 
(21, 51, 1), 
(21, 53, 1), 
(21, 46, 1), 
(21, 33, 1), 
(21, 32, 1), 
(21, 30, 1), 
(21, 29, 1), 
(21, 31, 1), 
(21, 28, 1), 
(21, 34, 1), 
(21, 24, 1), 
(21, 20, 1), 
(21, 21, 1), 
(21, 26, 1), 
(21, 23, 1), 
(21, 18, 1), 
(21, 25, 1), 
(21, 17, 1), 
(21, 22, 1), 
(21, 19, 1), 
(21, 48, 1), 
(21, 50, 1), 
(21, 58, 1), 
(21, 35, 1), 
(20, 2, 1), 
(20, 36, 1), 
(20, 39, 1), 
(20, 42, 1), 
(20, 43, 1), 
(20, 54, 1), 
(20, 55, 1), 
(20, 56, 1), 
(20, 57, 1), 
(20, 27, 1), 
(20, 47, 1), 
(20, 11, 1), 
(20, 52, 1), 
(20, 5, 1), 
(20, 6, 1), 
(20, 7, 1), 
(20, 13, 1), 
(20, 15, 1), 
(20, 16, 1), 
(20, 51, 1), 
(20, 53, 1), 
(20, 46, 1), 
(20, 33, 1), 
(20, 32, 1), 
(20, 30, 1), 
(20, 29, 1), 
(20, 31, 1), 
(20, 28, 1), 
(20, 34, 1), 
(20, 24, 1), 
(20, 20, 1), 
(20, 21, 1), 
(20, 26, 1), 
(20, 23, 1), 
(20, 18, 1), 
(20, 25, 1), 
(20, 17, 1), 
(20, 22, 1), 
(20, 19, 1), 
(20, 48, 1), 
(20, 50, 1), 
(20, 58, 1), 
(20, 35, 1), 
(18, 2, 1), 
(18, 36, 1), 
(18, 39, 1), 
(18, 42, 1), 
(18, 43, 1), 
(18, 54, 1), 
(18, 55, 1), 
(18, 56, 1), 
(18, 57, 1), 
(18, 27, 1), 
(18, 47, 1), 
(18, 11, 1), 
(18, 52, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 13, 1), 
(18, 15, 1), 
(18, 16, 1), 
(18, 51, 1), 
(18, 53, 1), 
(18, 46, 1), 
(18, 33, 1), 
(18, 32, 1), 
(18, 30, 1), 
(18, 29, 1), 
(18, 31, 1), 
(18, 28, 1), 
(18, 34, 1), 
(18, 24, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 26, 1), 
(18, 23, 1), 
(18, 18, 1), 
(18, 25, 1), 
(18, 17, 1), 
(18, 22, 1), 
(18, 19, 1), 
(18, 48, 1), 
(18, 50, 1), 
(18, 58, 1), 
(18, 35, 1), 
(9, 7, 1), 
(16, 2, 1), 
(16, 36, 1), 
(16, 39, 1), 
(16, 42, 1), 
(16, 43, 1), 
(16, 54, 1), 
(16, 55, 1), 
(16, 56, 1), 
(16, 57, 1), 
(16, 27, 1), 
(16, 47, 1), 
(16, 11, 1), 
(16, 52, 1), 
(16, 5, 1), 
(16, 6, 1), 
(16, 7, 1), 
(16, 13, 1), 
(16, 15, 1), 
(16, 16, 1), 
(16, 51, 1), 
(16, 53, 1), 
(16, 46, 1), 
(16, 33, 1), 
(16, 32, 1), 
(16, 30, 1), 
(16, 29, 1), 
(16, 31, 1), 
(16, 28, 1), 
(16, 34, 1), 
(16, 24, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 26, 1), 
(16, 23, 1), 
(16, 18, 1), 
(16, 25, 1), 
(16, 17, 1), 
(16, 22, 1), 
(16, 19, 1), 
(16, 48, 1), 
(16, 50, 1), 
(16, 58, 1), 
(16, 35, 1), 
(10, 2, 1), 
(10, 36, 1), 
(10, 39, 1), 
(10, 42, 1), 
(10, 43, 1), 
(10, 54, 1), 
(10, 55, 1), 
(10, 56, 1), 
(10, 57, 1), 
(10, 27, 1), 
(10, 47, 1), 
(10, 11, 1), 
(10, 52, 1), 
(10, 5, 1), 
(10, 6, 1), 
(10, 7, 1), 
(10, 13, 1), 
(10, 15, 1), 
(10, 16, 1), 
(10, 51, 1), 
(10, 53, 1), 
(10, 46, 1), 
(10, 33, 1), 
(10, 32, 1), 
(10, 30, 1), 
(10, 29, 1), 
(10, 31, 1), 
(10, 28, 1), 
(10, 34, 1), 
(10, 24, 1), 
(10, 20, 1), 
(10, 21, 1), 
(10, 26, 1), 
(10, 23, 1), 
(10, 18, 1), 
(10, 25, 1), 
(10, 17, 1), 
(10, 22, 1), 
(10, 19, 1), 
(10, 48, 1), 
(10, 50, 1), 
(10, 58, 1), 
(10, 35, 1), 
(11, 2, 2), 
(11, 36, 2), 
(11, 39, 2), 
(11, 42, 2), 
(11, 43, 2), 
(11, 54, 2), 
(11, 55, 2), 
(11, 56, 2), 
(11, 57, 2), 
(11, 27, 2), 
(11, 47, 2), 
(11, 11, 2), 
(11, 52, 2), 
(11, 5, 2), 
(11, 6, 2), 
(11, 7, 2), 
(11, 13, 2), 
(11, 15, 2), 
(11, 16, 2), 
(11, 51, 2), 
(11, 53, 2), 
(11, 46, 2), 
(11, 33, 2), 
(11, 32, 2), 
(11, 30, 2), 
(11, 29, 2), 
(11, 31, 2), 
(11, 28, 2), 
(11, 34, 2), 
(11, 24, 2), 
(11, 20, 2), 
(11, 21, 2), 
(11, 26, 2), 
(11, 23, 2), 
(11, 18, 2), 
(11, 25, 2), 
(11, 17, 2), 
(11, 22, 2), 
(11, 19, 2), 
(11, 48, 2), 
(11, 50, 2), 
(11, 58, 2), 
(11, 35, 2), 
(12, 2, 3), 
(12, 36, 3), 
(12, 39, 3), 
(12, 42, 3), 
(12, 43, 3), 
(12, 54, 3), 
(12, 55, 3), 
(12, 56, 3), 
(12, 57, 3), 
(12, 27, 3), 
(12, 47, 3), 
(12, 11, 3), 
(12, 52, 3), 
(12, 5, 3), 
(12, 6, 3), 
(12, 7, 3), 
(12, 13, 3), 
(12, 15, 3), 
(12, 16, 3), 
(12, 51, 3), 
(12, 53, 3), 
(12, 46, 3), 
(12, 33, 3), 
(12, 32, 3), 
(12, 30, 3), 
(12, 29, 3), 
(12, 31, 3), 
(12, 28, 3), 
(12, 34, 3), 
(12, 24, 3), 
(12, 20, 3), 
(12, 21, 3), 
(12, 26, 3), 
(12, 23, 3), 
(12, 18, 3), 
(12, 25, 3), 
(12, 17, 3), 
(12, 22, 3), 
(12, 19, 3), 
(12, 48, 3), 
(12, 50, 3), 
(12, 58, 3), 
(12, 35, 3), 
(13, 2, 4), 
(13, 36, 4), 
(13, 39, 4), 
(13, 42, 4), 
(13, 43, 4), 
(13, 54, 4), 
(13, 55, 4), 
(13, 56, 4), 
(13, 57, 4), 
(13, 27, 4), 
(13, 47, 4), 
(13, 11, 4), 
(13, 52, 4), 
(13, 5, 4), 
(13, 6, 4), 
(13, 7, 4), 
(13, 13, 4), 
(13, 15, 4), 
(13, 16, 4), 
(13, 51, 4), 
(13, 53, 4), 
(13, 46, 4), 
(13, 33, 4), 
(13, 32, 4), 
(13, 30, 4), 
(13, 29, 4), 
(13, 31, 4), 
(13, 28, 4), 
(13, 34, 4), 
(13, 24, 4), 
(13, 20, 4), 
(13, 21, 4), 
(13, 26, 4), 
(13, 23, 4), 
(13, 18, 4), 
(13, 25, 4), 
(13, 17, 4), 
(13, 22, 4), 
(13, 19, 4), 
(13, 48, 4), 
(13, 50, 4), 
(13, 58, 4), 
(13, 35, 4), 
(14, 5, 5), 
(14, 6, 5), 
(14, 7, 5), 
(14, 11, 5), 
(14, 13, 5), 
(14, 15, 5), 
(14, 16, 5), 
(14, 51, 5), 
(14, 52, 5), 
(15, 2, 1), 
(15, 36, 1), 
(15, 39, 1), 
(15, 42, 1), 
(15, 43, 1), 
(15, 54, 1), 
(15, 55, 1), 
(15, 56, 1), 
(15, 57, 1), 
(15, 27, 1), 
(15, 47, 1), 
(15, 11, 1), 
(15, 52, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 13, 1), 
(15, 15, 1), 
(15, 16, 1), 
(15, 51, 1), 
(15, 53, 1), 
(15, 46, 1), 
(15, 33, 1), 
(15, 32, 1), 
(15, 30, 1), 
(15, 29, 1), 
(15, 31, 1), 
(15, 28, 1), 
(15, 34, 1), 
(15, 24, 1), 
(15, 20, 1), 
(15, 21, 1), 
(15, 26, 1), 
(15, 23, 1), 
(15, 18, 1), 
(15, 25, 1), 
(15, 17, 1), 
(15, 22, 1), 
(15, 19, 1), 
(15, 48, 1), 
(15, 50, 1), 
(15, 58, 1), 
(15, 35, 1), 
(2, 61, 1), 
(2, 60, 1), 
(2, 62, 1), 
(22, 61, 1), 
(22, 60, 1), 
(22, 62, 1), 
(19, 73, 1), 
(19, 84, 1), 
(19, 74, 1), 
(29, 7, 1), 
(29, 16, 1), 
(29, 2, 1), 
(6, 61, 1), 
(6, 60, 1), 
(6, 62, 1), 
(20, 61, 1), 
(20, 60, 1), 
(20, 62, 1), 
(18, 61, 1), 
(18, 60, 1), 
(18, 62, 1), 
(16, 61, 1), 
(16, 60, 1), 
(16, 62, 1), 
(10, 61, 1), 
(10, 60, 1), 
(10, 62, 1), 
(11, 61, 2), 
(11, 60, 2), 
(11, 62, 2), 
(12, 61, 3), 
(12, 60, 3), 
(12, 62, 3), 
(13, 61, 4), 
(13, 60, 4), 
(13, 62, 4), 
(15, 61, 1), 
(15, 60, 1), 
(15, 62, 1), 
(24, 2, 1), 
(24, 7, 1), 
(24, 16, 1), 
(24, 15, 1), 
(24, 51, 1), 
(24, 6, 1), 
(24, 13, 1), 
(24, 5, 1), 
(24, 52, 1), 
(24, 11, 1), 
(24, 24, 1), 
(24, 20, 1), 
(24, 21, 1), 
(24, 26, 1), 
(24, 23, 1), 
(24, 18, 1), 
(24, 25, 1), 
(24, 17, 1), 
(24, 22, 1), 
(24, 19, 1), 
(24, 48, 1), 
(24, 50, 1), 
(24, 58, 1), 
(24, 27, 1), 
(24, 33, 1), 
(24, 32, 1), 
(24, 30, 1), 
(24, 29, 1), 
(24, 31, 1), 
(24, 28, 1), 
(24, 34, 1), 
(24, 35, 1), 
(24, 36, 1), 
(24, 39, 1), 
(24, 42, 1), 
(24, 43, 1), 
(24, 46, 1), 
(24, 47, 1), 
(24, 53, 1), 
(24, 54, 1), 
(24, 55, 1), 
(24, 56, 1), 
(24, 57, 1), 
(26, 7, 1), 
(26, 16, 1), 
(26, 2, 1), 
(19, 63, 1), 
(24, 63, 1), 
(2, 63, 3), 
(22, 63, 1), 
(17, 63, 1), 
(4, 63, 1), 
(5, 63, 3), 
(6, 63, 4), 
(21, 63, 1), 
(20, 63, 1), 
(18, 63, 1), 
(16, 63, 1), 
(10, 63, 1), 
(11, 63, 2), 
(12, 63, 3), 
(13, 63, 4), 
(15, 63, 1), 
(26, 15, 1), 
(26, 51, 1), 
(26, 6, 1), 
(26, 13, 1), 
(26, 5, 1), 
(26, 52, 1), 
(26, 11, 1), 
(26, 24, 1), 
(26, 20, 1), 
(26, 21, 1), 
(26, 26, 1), 
(26, 23, 1), 
(26, 18, 1), 
(26, 25, 1), 
(26, 17, 1), 
(26, 22, 1), 
(26, 19, 1), 
(26, 48, 1), 
(26, 50, 1), 
(26, 58, 1), 
(26, 27, 1), 
(26, 33, 1), 
(26, 32, 1), 
(26, 30, 1), 
(26, 29, 1), 
(26, 31, 1), 
(26, 28, 1), 
(26, 34, 1), 
(26, 35, 1), 
(26, 36, 1), 
(26, 39, 1), 
(26, 42, 1), 
(26, 43, 1), 
(26, 46, 1), 
(26, 47, 1), 
(26, 53, 1), 
(26, 54, 1), 
(26, 55, 1), 
(26, 56, 1), 
(26, 57, 1), 
(26, 63, 1), 
(29, 15, 1), 
(29, 51, 1), 
(29, 6, 1), 
(29, 13, 1), 
(29, 5, 1), 
(29, 52, 1), 
(29, 11, 1), 
(29, 24, 1), 
(29, 20, 1), 
(29, 21, 1), 
(29, 26, 1), 
(29, 23, 1), 
(29, 18, 1), 
(29, 25, 1), 
(29, 17, 1), 
(29, 22, 1), 
(29, 19, 1), 
(29, 48, 1), 
(29, 50, 1), 
(29, 58, 1), 
(29, 27, 1), 
(29, 33, 1), 
(29, 32, 1), 
(29, 30, 1), 
(29, 29, 1), 
(29, 31, 1), 
(29, 28, 1), 
(29, 34, 1), 
(29, 35, 1), 
(29, 36, 1), 
(29, 39, 1), 
(29, 42, 1), 
(29, 43, 1), 
(29, 46, 1), 
(29, 47, 1), 
(29, 53, 1), 
(29, 54, 1), 
(29, 55, 1), 
(29, 56, 1), 
(29, 57, 1), 
(29, 63, 1), 
(30, 63, 2), 
(30, 7, 2), 
(30, 16, 2), 
(30, 15, 2), 
(30, 51, 2), 
(30, 6, 2), 
(30, 13, 2), 
(30, 5, 2), 
(30, 52, 2), 
(30, 11, 2), 
(30, 43, 2), 
(30, 54, 2), 
(30, 53, 2), 
(30, 39, 2), 
(30, 46, 2), 
(30, 56, 2), 
(30, 42, 2), 
(30, 57, 2), 
(30, 47, 2), 
(30, 55, 2), 
(30, 17, 2), 
(30, 25, 2), 
(30, 24, 2), 
(30, 36, 2), 
(30, 30, 2), 
(30, 29, 2), 
(30, 28, 2), 
(30, 34, 2), 
(30, 31, 2), 
(30, 35, 2), 
(30, 32, 2), 
(30, 33, 2), 
(30, 27, 2), 
(30, 58, 2), 
(30, 50, 2), 
(30, 48, 2), 
(30, 19, 2), 
(30, 22, 2), 
(30, 18, 2), 
(30, 23, 2), 
(30, 26, 2), 
(30, 21, 2), 
(30, 20, 2), 
(30, 2, 2), 
(19, 65, 1), 
(19, 71, 1), 
(19, 72, 1), 
(19, 64, 1), 
(19, 70, 1), 
(19, 66, 1), 
(19, 68, 1), 
(24, 65, 1), 
(24, 71, 1), 
(24, 72, 1), 
(24, 64, 1), 
(24, 70, 1), 
(24, 66, 1), 
(24, 68, 1), 
(29, 65, 1), 
(29, 71, 1), 
(29, 72, 1), 
(29, 64, 1), 
(29, 70, 1), 
(29, 66, 1), 
(29, 68, 1), 
(30, 65, 2), 
(30, 71, 2), 
(30, 72, 2), 
(30, 64, 2), 
(30, 70, 2), 
(30, 66, 2), 
(30, 68, 2), 
(2, 65, 3), 
(2, 71, 3), 
(2, 72, 3), 
(2, 64, 3), 
(2, 70, 3), 
(2, 66, 3), 
(2, 68, 3), 
(22, 65, 1), 
(22, 71, 1), 
(22, 72, 1), 
(22, 64, 1), 
(22, 70, 1), 
(22, 66, 1), 
(22, 68, 1), 
(17, 65, 1), 
(17, 71, 1), 
(17, 72, 1), 
(17, 64, 1), 
(17, 70, 1), 
(17, 66, 1), 
(17, 68, 1), 
(4, 65, 1), 
(4, 71, 1), 
(4, 72, 1), 
(4, 64, 1), 
(4, 70, 1), 
(4, 66, 1), 
(4, 68, 1), 
(5, 65, 3), 
(5, 71, 3), 
(5, 72, 3), 
(5, 64, 3), 
(5, 70, 3), 
(5, 66, 3), 
(5, 68, 3), 
(6, 65, 4), 
(6, 71, 4), 
(6, 72, 4), 
(6, 64, 4), 
(6, 70, 4), 
(6, 66, 4), 
(6, 68, 4), 
(21, 65, 1), 
(21, 71, 1), 
(21, 72, 1), 
(21, 64, 1), 
(21, 70, 1), 
(21, 66, 1), 
(21, 68, 1), 
(26, 65, 1), 
(26, 71, 1), 
(26, 72, 1), 
(26, 64, 1), 
(26, 70, 1), 
(26, 66, 1), 
(26, 68, 1), 
(20, 65, 1), 
(20, 71, 1), 
(20, 72, 1), 
(20, 64, 1), 
(20, 70, 1), 
(20, 66, 1), 
(20, 68, 1), 
(18, 65, 1), 
(18, 71, 1), 
(18, 72, 1), 
(18, 64, 1), 
(18, 70, 1), 
(18, 66, 1), 
(18, 68, 1), 
(16, 65, 1), 
(16, 71, 1), 
(16, 72, 1), 
(16, 64, 1), 
(16, 70, 1), 
(16, 66, 1), 
(16, 68, 1), 
(10, 65, 1), 
(10, 71, 1), 
(10, 72, 1), 
(10, 64, 1), 
(10, 70, 1), 
(10, 66, 1), 
(10, 68, 1), 
(11, 65, 2), 
(11, 71, 2), 
(11, 72, 2), 
(11, 64, 2), 
(11, 70, 2), 
(11, 66, 2), 
(11, 68, 2), 
(12, 65, 3), 
(12, 71, 3), 
(12, 72, 3), 
(12, 64, 3), 
(12, 70, 3), 
(12, 66, 3), 
(12, 68, 3), 
(13, 65, 4), 
(13, 71, 4), 
(13, 72, 4), 
(13, 64, 4), 
(13, 70, 4), 
(13, 66, 4), 
(13, 68, 4), 
(15, 65, 1), 
(15, 71, 1), 
(15, 72, 1), 
(15, 64, 1), 
(15, 70, 1), 
(15, 66, 1), 
(15, 68, 1), 
(24, 74, 1), 
(24, 73, 1), 
(24, 84, 1), 
(29, 74, 1), 
(29, 73, 1), 
(29, 84, 1), 
(30, 74, 2), 
(30, 73, 2), 
(30, 84, 2), 
(2, 74, 3), 
(2, 73, 3), 
(2, 84, 3), 
(22, 74, 1), 
(22, 73, 1), 
(22, 84, 1), 
(17, 74, 1), 
(17, 73, 1), 
(17, 84, 1), 
(4, 74, 1), 
(4, 73, 1), 
(4, 84, 1), 
(5, 74, 3), 
(5, 73, 3), 
(5, 84, 3), 
(6, 74, 4), 
(6, 73, 4), 
(6, 84, 4), 
(21, 74, 1), 
(21, 73, 1), 
(21, 84, 1), 
(26, 74, 1), 
(26, 73, 1), 
(26, 84, 1), 
(20, 74, 1), 
(20, 73, 1), 
(20, 84, 1), 
(18, 74, 1), 
(18, 73, 1), 
(18, 84, 1), 
(16, 74, 1), 
(16, 73, 1), 
(16, 84, 1), 
(10, 74, 1), 
(10, 73, 1), 
(10, 84, 1), 
(11, 74, 2), 
(11, 73, 2), 
(11, 84, 2), 
(12, 74, 3), 
(12, 73, 3), 
(12, 84, 3), 
(13, 74, 4), 
(13, 73, 4), 
(13, 84, 4), 
(15, 74, 1), 
(15, 73, 1), 
(15, 84, 1), 
(19, 85, 1), 
(19, 86, 1), 
(24, 85, 1), 
(24, 86, 1), 
(29, 85, 1), 
(29, 86, 1), 
(30, 85, 2), 
(30, 86, 2), 
(2, 85, 3), 
(2, 86, 3), 
(22, 85, 1), 
(22, 86, 1), 
(17, 85, 1), 
(17, 86, 1), 
(4, 85, 1), 
(4, 86, 1), 
(5, 85, 3), 
(5, 86, 3), 
(6, 85, 4), 
(6, 86, 4), 
(21, 85, 1), 
(21, 86, 1), 
(26, 85, 1), 
(26, 86, 1), 
(20, 85, 1), 
(20, 86, 1), 
(18, 85, 1), 
(18, 86, 1), 
(16, 85, 1), 
(16, 86, 1), 
(10, 85, 1), 
(10, 86, 1), 
(11, 85, 2), 
(11, 86, 2), 
(12, 85, 3), 
(12, 86, 3), 
(13, 85, 4), 
(13, 86, 4), 
(15, 85, 1), 
(15, 86, 1), 
(31, 2, 2), 
(31, 7, 2), 
(31, 16, 2), 
(31, 15, 2), 
(31, 51, 2), 
(31, 6, 2), 
(31, 13, 2), 
(31, 5, 2), 
(31, 52, 2), 
(31, 11, 2), 
(31, 24, 2), 
(31, 20, 2), 
(31, 21, 2), 
(31, 26, 2), 
(31, 23, 2), 
(31, 18, 2), 
(31, 25, 2), 
(31, 17, 2), 
(31, 22, 2), 
(31, 19, 2), 
(31, 48, 2), 
(31, 50, 2), 
(31, 58, 2), 
(31, 65, 2), 
(31, 71, 2), 
(31, 72, 2), 
(31, 64, 2), 
(31, 70, 2), 
(31, 66, 2), 
(31, 68, 2), 
(31, 74, 2), 
(31, 73, 2), 
(31, 84, 2), 
(31, 85, 2), 
(31, 86, 2), 
(31, 27, 2), 
(31, 33, 2), 
(31, 32, 2), 
(31, 30, 2), 
(31, 29, 2), 
(31, 31, 2), 
(31, 28, 2), 
(31, 34, 2), 
(31, 35, 2), 
(31, 36, 2), 
(31, 39, 2), 
(31, 42, 2), 
(31, 43, 2), 
(31, 46, 2), 
(31, 47, 2), 
(31, 53, 2), 
(31, 54, 2), 
(31, 55, 2), 
(31, 56, 2), 
(31, 57, 2), 
(31, 63, 2), 
(19, 87, 1), 
(24, 87, 1), 
(29, 87, 1), 
(30, 87, 2), 
(2, 87, 3), 
(22, 87, 1), 
(17, 87, 1), 
(4, 87, 1), 
(31, 87, 2), 
(5, 87, 3), 
(6, 87, 4), 
(21, 87, 1), 
(26, 87, 1), 
(20, 87, 1), 
(18, 87, 1), 
(16, 87, 1), 
(10, 87, 1), 
(11, 87, 2), 
(12, 87, 3), 
(13, 87, 4), 
(15, 87, 1), 
(19, 88, 1), 
(19, 89, 1), 
(24, 88, 1), 
(24, 89, 1), 
(29, 88, 1), 
(29, 89, 1), 
(30, 88, 2), 
(30, 89, 2), 
(2, 88, 3), 
(2, 89, 3), 
(22, 88, 1), 
(22, 89, 1), 
(17, 88, 1), 
(17, 89, 1), 
(4, 88, 1), 
(4, 89, 1), 
(31, 88, 2), 
(31, 89, 2), 
(5, 88, 3), 
(5, 89, 3), 
(6, 88, 4), 
(6, 89, 4), 
(21, 88, 1), 
(21, 89, 1), 
(26, 88, 1), 
(26, 89, 1), 
(20, 88, 1), 
(20, 89, 1), 
(18, 88, 1), 
(18, 89, 1), 
(16, 88, 1), 
(16, 89, 1), 
(10, 88, 1), 
(10, 89, 1), 
(11, 88, 2), 
(11, 89, 2), 
(12, 88, 3), 
(12, 89, 3), 
(13, 88, 4), 
(13, 89, 4), 
(15, 88, 1), 
(15, 89, 1), 
(19, 92, 1), 
(19, 94, 1), 
(19, 95, 1), 
(19, 98, 1), 
(19, 96, 1), 
(19, 97, 1), 
(19, 93, 1), 
(19, 90, 1), 
(19, 91, 1), 
(24, 92, 1), 
(24, 94, 1), 
(24, 95, 1), 
(24, 98, 1), 
(24, 96, 1), 
(24, 97, 1), 
(24, 93, 1), 
(24, 90, 1), 
(24, 91, 1), 
(29, 92, 1), 
(29, 94, 1), 
(29, 95, 1), 
(29, 98, 1), 
(29, 96, 1), 
(29, 97, 1), 
(29, 93, 1), 
(29, 90, 1), 
(29, 91, 1), 
(30, 92, 2), 
(30, 94, 2), 
(30, 95, 2), 
(30, 98, 2), 
(30, 96, 2), 
(30, 97, 2), 
(30, 93, 2), 
(30, 90, 2), 
(30, 91, 2), 
(2, 92, 3), 
(2, 94, 3), 
(2, 95, 3), 
(2, 98, 3), 
(2, 96, 3), 
(2, 97, 3), 
(2, 93, 3), 
(2, 90, 3), 
(2, 91, 3), 
(22, 92, 1), 
(22, 94, 1), 
(22, 95, 1), 
(22, 98, 1), 
(22, 96, 1), 
(22, 97, 1), 
(22, 93, 1), 
(22, 90, 1), 
(22, 91, 1), 
(17, 92, 1), 
(17, 94, 1), 
(17, 95, 1), 
(17, 98, 1), 
(17, 96, 1), 
(17, 97, 1), 
(17, 93, 1), 
(17, 90, 1), 
(17, 91, 1), 
(4, 92, 1), 
(4, 94, 1), 
(4, 95, 1), 
(4, 98, 1), 
(4, 96, 1), 
(4, 97, 1), 
(4, 93, 1), 
(4, 90, 1), 
(4, 91, 1), 
(31, 92, 2), 
(31, 94, 2), 
(31, 95, 2), 
(31, 98, 2), 
(31, 96, 2), 
(31, 97, 2), 
(31, 93, 2), 
(31, 90, 2), 
(31, 91, 2), 
(5, 92, 3), 
(5, 94, 3), 
(5, 95, 3), 
(5, 98, 3), 
(5, 96, 3), 
(5, 97, 3), 
(5, 93, 3), 
(5, 90, 3), 
(5, 91, 3), 
(6, 92, 4), 
(6, 94, 4), 
(6, 95, 4), 
(6, 98, 4), 
(6, 96, 4), 
(6, 97, 4), 
(6, 93, 4), 
(6, 90, 4), 
(6, 91, 4), 
(21, 92, 1), 
(21, 94, 1), 
(21, 95, 1), 
(21, 98, 1), 
(21, 96, 1), 
(21, 97, 1), 
(21, 93, 1), 
(21, 90, 1), 
(21, 91, 1), 
(26, 92, 1), 
(26, 94, 1), 
(26, 95, 1), 
(26, 98, 1), 
(26, 96, 1), 
(26, 97, 1), 
(26, 93, 1), 
(26, 90, 1), 
(26, 91, 1), 
(20, 92, 1), 
(20, 94, 1), 
(20, 95, 1), 
(20, 98, 1), 
(20, 96, 1), 
(20, 97, 1), 
(20, 93, 1), 
(20, 90, 1), 
(20, 91, 1), 
(18, 92, 1), 
(18, 94, 1), 
(18, 95, 1), 
(18, 98, 1), 
(18, 96, 1), 
(18, 97, 1), 
(18, 93, 1), 
(18, 90, 1), 
(18, 91, 1), 
(16, 92, 1), 
(16, 94, 1), 
(16, 95, 1), 
(16, 98, 1), 
(16, 96, 1), 
(16, 97, 1), 
(16, 93, 1), 
(16, 90, 1), 
(16, 91, 1), 
(10, 92, 1), 
(10, 94, 1), 
(10, 95, 1), 
(10, 98, 1), 
(10, 96, 1), 
(10, 97, 1), 
(10, 93, 1), 
(10, 90, 1), 
(10, 91, 1), 
(11, 92, 2), 
(11, 94, 2), 
(11, 95, 2), 
(11, 98, 2), 
(11, 96, 2), 
(11, 97, 2), 
(11, 93, 2), 
(11, 90, 2), 
(11, 91, 2), 
(12, 92, 3), 
(12, 94, 3), 
(12, 95, 3), 
(12, 98, 3), 
(12, 96, 3), 
(12, 97, 3), 
(12, 93, 3), 
(12, 90, 3), 
(12, 91, 3), 
(13, 92, 4), 
(13, 94, 4), 
(13, 95, 4), 
(13, 98, 4), 
(13, 96, 4), 
(13, 97, 4), 
(13, 93, 4), 
(13, 90, 4), 
(13, 91, 4), 
(15, 92, 1), 
(15, 94, 1), 
(15, 95, 1), 
(15, 98, 1), 
(15, 96, 1), 
(15, 97, 1), 
(15, 93, 1), 
(15, 90, 1), 
(15, 91, 1), 
(19, 99, 1), 
(24, 99, 1), 
(29, 99, 1), 
(30, 99, 2), 
(2, 99, 3), 
(22, 99, 1), 
(17, 99, 1), 
(4, 99, 1), 
(31, 99, 2), 
(5, 99, 3), 
(6, 99, 4), 
(21, 99, 1), 
(26, 99, 1), 
(20, 99, 1), 
(18, 99, 1), 
(16, 99, 1), 
(10, 99, 1), 
(11, 99, 2), 
(12, 99, 3), 
(13, 99, 4), 
(15, 99, 1), 
(33, 7, 1), 
(19, 101, 1), 
(24, 101, 1), 
(29, 101, 1), 
(30, 101, 2), 
(2, 101, 3), 
(22, 101, 1), 
(17, 101, 1), 
(4, 101, 1), 
(31, 101, 2), 
(5, 101, 3), 
(6, 101, 4), 
(21, 101, 1), 
(26, 101, 1), 
(20, 101, 1), 
(18, 101, 1), 
(16, 101, 1), 
(10, 101, 1), 
(11, 101, 2), 
(12, 101, 3), 
(13, 101, 4), 
(15, 101, 1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_comments`
--

DROP TABLE IF EXISTS `ctypa_vi_comments`;
CREATE TABLE `ctypa_vi_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `area` int(11) NOT NULL DEFAULT '0',
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `url_comment` varchar(250) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `likes` mediumint(9) NOT NULL DEFAULT '0',
  `dislikes` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `mod_id` (`module`,`area`,`id`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_contact_department`
--

DROP TABLE IF EXISTS `ctypa_vi_contact_department`;
CREATE TABLE `ctypa_vi_contact_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `yahoo` varchar(100) NOT NULL,
  `skype` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `admins` text NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_contact_department`
--

INSERT INTO `ctypa_vi_contact_department` VALUES
(1, 'Webmaster', 'Webmaster', '', '', '', '', '', '', '1/1/1/0;', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_contact_reply`
--

DROP TABLE IF EXISTS `ctypa_vi_contact_reply`;
CREATE TABLE `ctypa_vi_contact_reply` (
  `rid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_content` text,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_contact_send`
--

DROP TABLE IF EXISTS `ctypa_vi_contact_send`;
CREATE TABLE `ctypa_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(255) DEFAULT '',
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_diemex`
--

DROP TABLE IF EXISTS `ctypa_vi_diemex`;
CREATE TABLE `ctypa_vi_diemex` (
  `sbd` varchar(15) NOT NULL,
  `ho` varchar(100) NOT NULL,
  `ten` varchar(20) NOT NULL,
  `lop` varchar(10) NOT NULL,
  `ngsinh` varchar(10) NOT NULL,
  `phong` varchar(20) NOT NULL,
  `toan` float DEFAULT NULL,
  `ly` float DEFAULT NULL,
  `hoa` float DEFAULT NULL,
  `sinh` float DEFAULT NULL,
  `van` float DEFAULT NULL,
  `su` float DEFAULT NULL,
  `dia` float DEFAULT NULL,
  `anh` float DEFAULT NULL,
  `gd` float DEFAULT NULL,
  PRIMARY KEY (`sbd`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_diemex`
--

INSERT INTO `ctypa_vi_diemex` VALUES
('15025101', 'Đặng Văn Bằng', 'Bằng', 'K6CT1', '1990-09-14', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052113', 'Bkrong', 'Y Bol', 'K6CT1', '1994-07-08', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052114', 'Y Chương', '', 'K6CT1', '1994-07-09', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052118', 'Lê Thành', 'Công', 'K6CT1', '1996-11-10', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052111', 'Nguyễn Thị Anh', 'Đào', 'K6CT1', '1995-02-18', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052102', 'Nguyễn Phước', 'Đạt', 'K6CT1', '1997-02-15', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053101', 'Niê', 'Y Tiên', 'K6CT1', '1994-07-02', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052116', 'Nguyễn Hữu', 'Hiệp', 'K6CT1', '1994-10-09', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052117', 'Chu Xuân', 'Hiếu', 'K6CT1', '1996-07-27', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053113', 'Hoàng Minh', 'Hiếu', 'K6CT1', '1997-11-12', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15054102', 'Trần Văn', 'Hiếu', 'K6CT1', '1999-05-30', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052123', 'Trần Mạnh', 'Hùng', 'K6CT1', '1986-12-06', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053102', 'Phạm Thái', 'Huy', 'K6CT1', '1996-12-01', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053108', 'Trần Quốc', 'Huy', 'K6CT1', '1996-02-02', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052119', 'Huỳnh Tấn', 'Huy', 'K6CT1', '1995-09-02', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052104', 'Niê', 'H\' Jun', 'K6CT1', '1996-06-26', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052124', 'Nguyễn Viết Đăng', 'Khoa', 'K6CT1', '1994-11-28', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052105', 'Ngô Tuấn', 'Kiệt', 'K6CT1', '1996-03-28', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15054104', 'Trần Hoàng', 'Long', 'K6CT1', '1997-07-18', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052106', 'Vũ Đình', 'Lương', 'K6CT1', '1991-01-03', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052107', 'Hoàng Cơ', 'Minh', 'K6CT1', '1994-03-15', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052120', 'Nguyễn Xuân', 'Muộn', 'K6CT1', '1997-01-25', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052121', 'Phan Thành', 'Nhân', 'K6CT1', '1997-04-23', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15054119', 'Trần Trọng', 'Nhân', 'K6CT1', '1997-10-27', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053109', 'Võ Tấn', 'Nhựt', 'K6CT1', '1996-11-09', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053110', 'Mlo', 'Y Nô', 'K6CT1', '1996-07-26', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052108', 'Trương Văn', 'Phụng', 'K6CT1', '1997-08-13', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052125', 'Nguyễn Bình', 'Phương', 'K6CT1', '1997-02-26', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052109', 'Tạ Thị Mỹ', 'Phương', 'K6CT1', '1996-12-05', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053111', 'Phan Tấn', 'Tài', 'K6CT1', '1996-04-06', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15054107', 'Nguyễn Trọng', 'Thái', 'K6CT1', '1997-09-23', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052122', 'Nguyễn Sỹ', 'Thắng', 'K6CT1', '1996-10-16', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053115', 'Lê Đức', 'Thọ', 'K6CT1', '1997-05-25', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053105', 'Phạm Trọng', 'Thức', 'K6CT1', '1997-10-21', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053112', 'Nguyễn Đăng', 'Toàn', 'K6CT1', '1997-03-08', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15054110', 'Nguyễn Đăng', 'Trung', 'K6CT1', '1996-12-11', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053116', 'Trần Huỳnh Khánh', 'Tú', 'K6CT1', '1996-12-03', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053106', 'Phạm Minh', 'Tuấn', 'K6CT1', '1996-09-26', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053114', 'Hoàng Đức', 'Tuấn', 'K6CT1', '1991-07-22', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15052112', 'Nguyễn Văn', 'Tùng', 'K6CT1', '1995-02-24', '', '0', '0', '0', '0', '0', '0', '0', '0', '0'), 
('15053107', 'Thân Hà Linh', 'Uyên', 'K6CT1', '1997-04-26', '', '0', '0', '0', '0', '0', '0', '0', '0', '0');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_download`
--

DROP TABLE IF EXISTS `ctypa_vi_download`;
CREATE TABLE `ctypa_vi_download` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `introtext` text NOT NULL,
  `uploadtime` int(11) unsigned NOT NULL,
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `user_id` mediumint(8) unsigned NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `author_email` varchar(60) NOT NULL,
  `author_url` varchar(255) NOT NULL,
  `fileupload` text NOT NULL,
  `linkdirect` text NOT NULL,
  `version` varchar(20) NOT NULL,
  `filesize` int(11) NOT NULL DEFAULT '0',
  `fileimage` varchar(255) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `copyright` varchar(255) NOT NULL,
  `view_hits` int(11) NOT NULL DEFAULT '0',
  `download_hits` int(11) NOT NULL DEFAULT '0',
  `groups_comment` varchar(255) NOT NULL,
  `groups_view` varchar(255) NOT NULL,
  `groups_download` varchar(255) NOT NULL,
  `comment_hits` int(11) NOT NULL DEFAULT '0',
  `rating_detail` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `catid` (`catid`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_download`
--

INSERT INTO `ctypa_vi_download` VALUES
(1, 2, 'Bài tập 1 Vùng chọn và Layer &#91;Photoshop&#93;', 'Bai-tap-1-Vung-chon-va-Layer-Photoshop', '<span style=\"font-size:16px;\"><strong>Hướng dẫn làm bài tập</strong><br  />
<br  />
Thực hành theo những bước sau đây:</span>
<ul>
	<li><span style=\"font-size:16px;\">Mở một file mới với những tính chất và kích thước tương tự file Final</span></li>
	<li><span style=\"font-size:16px;\">Dùng những công cụ chọn vùng thích hợp, chọn và đưa những đối tượng cần sử dụng trên file Begin ra thành những Layer mới.</span></li>
	<li><span style=\"font-size:16px;\">Chuyển những đối tượng đã chuyển thành layer trên file Begin sang file mới mở</span></li>
	<li><span style=\"font-size:16px;\">Thao tác và sắp xếp các đối tượng sao cho giống trên file Final</span></li>
	<li><span style=\"font-size:16px;\">Hoàn thiện và lưu file</span></li>
	<li><span style=\"font-size:16px;\">Kết thúc bài thực hành</span></li>
</ul>
&nbsp;

<div style=\"text-align: right;\"><span style=\"font-size:16px;\">HẾT</span></div>
<br  />
&nbsp;', 'Thực hành theo những bước sau đây', 1453378149, 1453378299, 1, 'admin', 'Cô Giang', 'hiengiang@k6ct1.com', 'https://www.facebook.com/hien.giang.3', '/download/files/bt1.zip', '', 'zip', 522065, '/download/images/bt1-hung.png', 1, 'CNTT K6CT1', 8, 1, '4', '6', '6', 0, '5|1'), 
(2, 2, 'Bài tập 2 Vùng chọn và Layer &#91;Photoshop&#93;', 'Bai-tap-2-Vung-chon-va-Layer-Photoshop', '<span style=\"font-size:16px;\"><strong>Hướng dẫn làm bài tập</strong></span>
<ul>
	<li><span style=\"font-size:16px;\">Mở mội file mới với những tính chất và kích thước tương tự file Final, dùng các chức năng tô chuyển sắc tô màu nền giống màu nền file Final.</span></li>
	<li><span style=\"font-size:16px;\">Dùng chức năng Edit\\Define Pattern và Edit\\Fill để thực hiện việc tạo mẫu nền chất liệu trên file mới, dùng chức năng Edit\\Stroke tạo viền cho nền. Chú ý để tạo được mẫu Pattern khi chọn vùng nên sử dụng công cụ chọn Rectangular Marquee Tool để tạo vùng chọn mẫu, không sử dụng Feather khi chọn mẫu làm Pattern.</span></li>
	<li><span style=\"font-size:16px;\">Dùng các công cụ chọn vùng thích hợp chọn và đưa các đối tượng cần sử dụng trên file Begin ra thành các layer mới.</span></li>
	<li><span style=\"font-size:16px;\">Chuyển các đối tượng đã đưa ra thành layer trên file Begin sang file mới tạo, Thao tác sắp xếp các đối tượng sao cho giống các đối tượng trên file Final.</span></li>
	<li><span style=\"font-size:16px;\">Dùng chức năng Opacity làm trong suốt một phần đối tượng</span></li>
	<li><span style=\"font-size:16px;\">Dùng chức năng tô chuyển sắc, tạo vùng chọn tô màu và đặt các lượn sóng màu đen cho sẵn lên để tạo vùng phía trên giống file Final.</span></li>
	<li><span style=\"font-size:16px;\">Hoàn thiện và lưu file.</span></li>
	<li><span style=\"font-size:16px;\">Kết thúc bài thực hành.</span></li>
</ul>
<span style=\"font-size:16px;\">&nbsp;</span>

<div style=\"text-align: right;\"><span style=\"font-size:16px;\">HẾT</span></div>', 'Thực hành theo những bước sau:', 1453378637, 1453378637, 1, 'admin', 'Cô Giang', 'hiengiang@k6ct1.com', 'https://www.facebook.com/hien.giang.3', '/download/files/bt2.zip', '', 'zip', 636249, '/download/images/bt2-hung.png', 1, 'CNTT K6CT1', 17, 4, '4', '6', '6', 0, '5|1'), 
(3, 2, 'Bài tập 2.2 Vùng chọn và Layer &#91;Photoshop&#93;', 'Bai-tap-2-2-Vung-chon-va-Layer-Photoshop', '&nbsp;
<div class=\"introtext\"><span style=\"font-size:16px;\"><strong>Hướng dẫn làm bài tập</strong></span>
<ul>
	<li><span style=\"font-size:16px;\">Mở mội file mới với những tính chất và kích thước tương tự file Final, dùng các chức năng tô chuyển sắc tô màu nền giống màu nền file Final.</span></li>
	<li><span style=\"font-size:16px;\">Dùng chức năng Edit\\Define Pattern và Edit\\Fill để thực hiện việc tạo mẫu nền chất liệu trên file mới, dùng chức năng Edit\\Stroke tạo viền cho nền. Chú ý để tạo được mẫu Pattern khi chọn vùng nên sử dụng công cụ chọn Rectangular Marquee Tool để tạo vùng chọn mẫu, không sử dụng Feather khi chọn mẫu làm Pattern.</span></li>
	<li><span style=\"font-size:16px;\">Dùng các công cụ chọn vùng thích hợp chọn và đưa các đối tượng cần sử dụng trên file Begin ra thành các layer mới.</span></li>
	<li><span style=\"font-size:16px;\">Chuyển các đối tượng đã đưa ra thành layer trên file Begin sang file mới tạo, Thao tác sắp xếp các đối tượng sao cho giống các đối tượng trên file Final.</span></li>
	<li><span style=\"font-size:16px;\">Dùng chức năng Opacity làm trong suốt một phần đối tượng</span></li>
	<li><span style=\"font-size:16px;\">Dùng chức năng tô chuyển sắc, tạo vùng chọn tô màu và đặt các lượn sóng màu đen cho sẵn lên để tạo vùng phía trên giống file Final.</span></li>
	<li><span style=\"font-size:16px;\">Hoàn thiện và lưu file.</span></li>
	<li><span style=\"font-size:16px;\">Kết thúc bài thực hành.</span></li>
</ul>
<span style=\"font-size:16px;\">&nbsp;</span>

<div style=\"text-align: right;\"><span style=\"font-size:16px;\">HẾT</span></div>
</div>', 'Thực hành theo những bước sau', 1453379538, 1453379538, 1, 'admin', 'Cô Giang', 'hiengiang@k6ct1.com', 'https://www.facebook.com/hien.giang.3', '/download/files/bt2.2.zip', '', 'zip', 294883, '/download/images/ket-qua.jpg', 1, 'CNTT K6CT1', 18, 3, '4', '6', '6', 0, ''), 
(4, 2, 'Bài tập 3 Vùng chọn và Layer &#91;Photoshop&#93;', 'Bai-tap-3-Vung-chon-va-Layer-Photoshop', '<span style=\"font-size:16px;\">Hướng dẫn làm bài tập:<br  />
&nbsp;</span>
<ul>
	<li><span style=\"font-size:16px;\">Mở một file mới với những tính chất và kích thước tương tự file Final. Tô màu đỏ cho nền.</span></li>
	<li><span style=\"font-size:16px;\">Dùng các chức năng Edit\\Define Pattern, Edit\\Fill và chức năng tô chuyển sắc để tạo mẫu đối tượng bên phải trên file mới mở giống file Final.</span></li>
	<li><span style=\"font-size:16px;\">Dùng các công cụ chọn, tạo vùng và đưa các đối tượng cần sử dụng trên file Begin ra thành các layer mới. Di chuyển các đối tượng này sang file mới mở.</span></li>
	<li><span style=\"font-size:16px;\">Thao tác, sắp xếp các đối tượng trên file mới giống file Final. Dùng công cụ Brush Tool tô vẽ đối tượng (con cua) giống file Final. Chú ý khi tô vẽ nên sử dụng loại đầu cọ có Feather.</span></li>
	<li><span style=\"font-size:16px;\">Dùng công cụ Type Tool nhập đoạn text, hoàn thiện và lưu file.</span></li>
	<li><span style=\"font-size:16px;\">Kết thúc bài thực hành.</span></li>
</ul>

<div style=\"text-align: right;\"><span style=\"font-size:16px;\">HẾT</span></div>', 'Thực hành theo những bước sau', 1453379757, 1453379784, 1, 'admin', 'Cô Giang', 'hiengiang@k6ct1.com', 'https://www.facebook.com/hien.giang.3', '/download/files/bt3.zip', '', 'zip', 698375, '/download/images/ketqua.jpg', 1, 'CNTT K6CT1', 15, 0, '4', '6', '6', 0, ''), 
(5, 1, 'Adobe photoshop CS6 Portable', 'Adobe-photoshop-CS6-Portable', '<b>Lưu ý</b>:<br  />
- Tuy là bản <b>portable</b> nhưng các bạn cứ yên tâm là đầy đủ chức năng nhé :P<br  />
- Hiện nay trên mạng có rất nhiều bản Portable Photoshop CS6 nhưng hầu hết đều là bản bị lỗi linh tinh và được làm từ bản Photoshop Beta. Bản này là bản chính thức và không dính các lỗi linh tinh trên.<br  />
dưới đây đính kèm hai bản (bản dành cho Win 32bit và bản dành cho Win 64bit)', 'Photoshop là phần mềm chỉnh sửa và tạo ảnh mạnh mẽ và được sử dụng nhiều nhất hiện nay. Phần mềm này của hãng Adobe và hiện nay đã ra mắt phiên bản 13.0 tức là bản CS6. Việc crack Adobe photoshop hiện nay tương đối khó khăn đối với các bạn newbie. Ngoài ra, do tính tiện dụng và nhỏ gọn, nhu cầu sử dụng Adobe photoshop CS6 Portable cũng rất lớn. Đó chính là lý do của bài viết này', 1453380201, 1453380201, 1, 'admin', 'Sưu tầm', 'info@k6ct1.com', 'http://k6ct1.com', '', 'http://www.fshare.vn/file/T0J4KB2Y5T/<br />http://www.fshare.vn/file/TGJ7JWPJRT/', 'zip', 0, '/download/images/img-1347703471-1.jpg', 1, 'CNTT K6CT1', 26, 3, '4', '6', '6', 0, '5|1'), 
(6, 1, 'Adobe Photoshop CS6 Setup', 'Adobe-Photoshop-CS6-Setup', '<b>Một số tính năng mới đáng chú ý trong Adobe Photoshop CS6:</b><br  />
* Giao diện người dùng: Tông màu chính mặc định được Adobe chuyển sang màu đen xám, gần giống với tông màu chủ đạo của Lightroom và Premiere Pro, giúp những hình ảnh nổi hơn trên nền màu tối.<br  />
<br  />
<br  />
* Hoạt động: Adobe Mercury Graphics Engine sẽ xóa bỏ cảm xúc phiền hà khi phải chờ đợi chương trình nạp một lượng lớn hình ảnh. Thời gian xử lý các tiến trình biên tập được rút ngắn.<br  />
<br  />
<br  />
* Biên tập video: được thiết kế để làm cầu nối giữa chương trình iMovie của Apple và Adobe Premiere Pro, khả năng biên tập video của Photoshop bao gồm chức năng kéo/thả các vị trí. Mới có mặt lần đầu tiên trong Photoshop nên chức năng này chỉ mới ở dạng &quot;sơ khai&quot;, chưa thật sự là &quot;nhân tố đinh&quot; ở lần ra mắt này.<br  />
<br  />
<br  />
* Điều khiển tự động: một loạt chức năng tự động điều khiển, cân chỉnh mới rất hấp dẫn, phù hợp với các &quot;tay mơ&quot; khi xử lý ảnh. Sử dụng một cơ sở dữ liệu bao gồm hàng trăm ngàn ảnh được xử lý thủ công bởi những nhiếp ảnh gia chuyên nghiệp, một thuật toán tính toán được những giá trị hiệu chỉnh cho mỗi bức ảnh.<br  />
<br  />
<br  />
Chức năng Auto Levels giờ đây có thể hiệu chỉnh mỗi kênh màu sắc riêng biệt, tránh thay đổi màu sắc và mất dữ liệu hình ảnh.<br  />
* Blur: công cụ đổ bóng mờ Iris có thể dễ dàng thay đổi độ sâu của ảnh. Bộ lọc (filter) tilt-shift hoạt động tương tự các hiệu ứng của nó và cho phép điều khiển vùng bị nhòa mờ từ các ảnh chụp ban đêm.<br  />
<br  />
<br  />
* Điều chỉnh ống kính (len): một bộ lọc góc rộng thích ứng có thể giúp làm thẳng các đường uốn lượn, thường là một sản phẩm phụ của các ống kính góc rộng. Người dùng vẽ các đường gạch để sửa lại các đối tượng không phù hợp, như các tòa nhà hay cây cối.<br  />
<br  />
<br  />
* Content-Aware: Xóa bỏ một đối tượng ra khỏi ảnh giờ đây là một thao tác rất đơn giản. Photoshop CS6sẽ phân tích bức ảnh, công cụ xử lý dùng thuật toán Content-Aware để lấp đầy vùng trống của đối tượng vừa được gỡ bỏ một cách tự nhiên. Hiểu đơn giản, Content-Aware di chuyển những đối tượng trong vùng chọn và chuyển chúng đến vị trí mới, lấp đầy phông nền ảnh và pha trộn đối tượng vào trong vị trí mới.<br  />
<br  />
<br  />
* Lớp ảnh (Layer): Có thêm vài bộ lọc lớp ảnh mới và một chức năng tìm kiếm rất hữu ích cho các đồ họa viên thường xuyên xử lý những tập tin với vài trăm lớp ảnh (layer).<br  />
<br  />
<br  />
<b>Hướng dẫn cài đặt và Crack Adobe Photoshop CS6:</b><br  />
Các bạn cài đặt với chế độ là <b>Trial Mode </b>,<br  />
Nếu phải Sign In thì các bạn chọn Create New Account rồi đăng ký 1 cái account nhé, email điền lung tung cũng được vì ko phải xác nhận đâu.(Hoặc có thể dùng ID: <a href=\"mailto:kva@mailinator.com\">kva@mailinator.com</a> / Password: kvakvakva )<br  />
<br  />
Sau khi cài đặt các bạn khởi động thử và bấm start trial để khởi động thử. Nếu khởi động OK thì các bạn tắt Photoshop đi, tải Crack ở dưới về rồi giải nén. Vào thư mục amtlib.dll\\32-bit hoặc amtlib.dll\\64-bit copy file amtlib.dll vào thư mục cài đặt<br  />
<br  />
Thư mục cài đặt mặc định là : C:\\Program Files\\Adobe\\Adobe Photoshop CS6<br  />
<br  />
Sau đó, các bạn khởi động chương trình, nếu nó có hỏi số serial thì các bạn chạy file &quot;KeyGenerator Adobe PTS CS6.exe&quot; để lấy serial nhé. (Trong file Serial Adobe Master Collection CS6.txt cũng có sẵn 2 serial để các bạn dùng)', 'Photoshop CS6 có hơn 62% chức năng mới so với Photoshop CS5 tập trung phần nhiều vào những thay đổi vi kiến trúc. Ngoài ra, nhờ Adobe Mercury Graphics Engine, Photoshop giờ đây có thêm khả năng biên tập video.', 1453380663, 1453380663, 1, 'admin', 'Sưu tầm', 'info@k6ct1.com', 'http://k6ct1.com', '', 'http://www.fshare.vn/file/TJTQCNQNHT<br />http://file.sinhvienit.net/c4cc0e5d', 'zip', 0, '/download/images/cs.png', 1, 'CNTT K6CT1', 21, 8, '4', '6', '6', 0, '5|1');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_download_categories`
--

DROP TABLE IF EXISTS `ctypa_vi_download_categories`;
CREATE TABLE `ctypa_vi_download_categories` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `groups_view` varchar(255) DEFAULT '',
  `groups_download` varchar(255) DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_download_categories`
--

INSERT INTO `ctypa_vi_download_categories` VALUES
(1, 0, 'Phần mềm học tập', 'pham-mem', 'phầm mềm hỗ trợ học tập', '6', '6', 1, 1), 
(2, 0, 'Bài tập mẫu', 'bai-mau', 'bài tập mẫu', '6', '6', 2, 1), 
(3, 0, 'Ứng dụng hay', 'ung-dung-hay', 'ứng dụng hay', '6', '6', 3, 1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_download_config`
--

DROP TABLE IF EXISTS `ctypa_vi_download_config`;
CREATE TABLE `ctypa_vi_download_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_download_config`
--

INSERT INTO `ctypa_vi_download_config` VALUES
('is_addfile', '1'), 
('is_upload', '1'), 
('groups_upload', ''), 
('maxfilesize', '62914560'), 
('upload_filetype', 'pdf,zip,rar,doc,docx,xls,xlsx,png,gif,jpg,bmp,jpe,jpeg'), 
('upload_dir', 'files'), 
('temp_dir', 'temp'), 
('groups_addfile', ''), 
('is_zip', '1'), 
('is_resume', '1'), 
('max_speed', '0');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_download_report`
--

DROP TABLE IF EXISTS `ctypa_vi_download_report`;
CREATE TABLE `ctypa_vi_download_report` (
  `fid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_ip` varchar(45) NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `fid` (`fid`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_download_tmp`
--

DROP TABLE IF EXISTS `ctypa_vi_download_tmp`;
CREATE TABLE `ctypa_vi_download_tmp` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `introtext` text NOT NULL,
  `uploadtime` int(11) unsigned NOT NULL DEFAULT '0',
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(100) NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `author_email` varchar(60) NOT NULL,
  `author_url` varchar(255) NOT NULL,
  `fileupload` text NOT NULL,
  `linkdirect` text NOT NULL,
  `version` varchar(20) NOT NULL,
  `filesize` varchar(255) NOT NULL,
  `fileimage` varchar(255) NOT NULL,
  `copyright` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_guestbook`
--

DROP TABLE IF EXISTS `ctypa_vi_guestbook`;
CREATE TABLE `ctypa_vi_guestbook` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(200) NOT NULL,
  `testimonial` mediumtext NOT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_guestbook`
--

INSERT INTO `ctypa_vi_guestbook` VALUES
(2, 'Test Nội dung', 'Trần Văn Tên', 'taynguyenxanh20@yahoo.com', 'Đang nhập nội dung lưu bút... test hệ thống', 1453416127, 1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_laws_cat`
--

DROP TABLE IF EXISTS `ctypa_vi_laws_cat`;
CREATE TABLE `ctypa_vi_laws_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `thumbnail` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `orders` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `del_cache_time` int(11) NOT NULL DEFAULT '0',
  `who_view` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  `numrow` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_laws_field`
--

DROP TABLE IF EXISTS `ctypa_vi_laws_field`;
CREATE TABLE `ctypa_vi_laws_field` (
  `fieldid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `orders` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsubfield` int(11) NOT NULL DEFAULT '0',
  `subfieldid` varchar(255) NOT NULL DEFAULT '',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fieldid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_laws_organ`
--

DROP TABLE IF EXISTS `ctypa_vi_laws_organ`;
CREATE TABLE `ctypa_vi_laws_organ` (
  `organid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `orders` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsuborgan` int(11) NOT NULL DEFAULT '0',
  `suborganid` varchar(255) NOT NULL DEFAULT '',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`organid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_laws_room`
--

DROP TABLE IF EXISTS `ctypa_vi_laws_room`;
CREATE TABLE `ctypa_vi_laws_room` (
  `roomid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `orders` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsubroom` int(11) NOT NULL DEFAULT '0',
  `subroomid` varchar(255) NOT NULL DEFAULT '',
  `keywords` mediumtext NOT NULL,
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`roomid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_laws_rows`
--

DROP TABLE IF EXISTS `ctypa_vi_laws_rows`;
CREATE TABLE `ctypa_vi_laws_rows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `hometext` text NOT NULL,
  `bodytext` mediumtext NOT NULL,
  `keywords` text NOT NULL,
  `filepath` text NOT NULL,
  `otherpath` text NOT NULL,
  `roomid` int(11) NOT NULL DEFAULT '0',
  `fieldid` int(11) NOT NULL DEFAULT '0',
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `down` int(8) NOT NULL DEFAULT '0',
  `view` int(8) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '0',
  `type` int(2) NOT NULL DEFAULT '0',
  `sign` text NOT NULL,
  `signtime` int(11) NOT NULL DEFAULT '0',
  `organid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_menu`
--

DROP TABLE IF EXISTS `ctypa_vi_menu`;
CREATE TABLE `ctypa_vi_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_menu`
--

INSERT INTO `ctypa_vi_menu` VALUES
(1, 'Top Menu');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_menu_rows`
--

DROP TABLE IF EXISTS `ctypa_vi_menu_rows`;
CREATE TABLE `ctypa_vi_menu_rows` (
  `id` mediumint(5) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(5) unsigned NOT NULL,
  `mid` smallint(5) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `icon` varchar(255) DEFAULT '',
  `note` varchar(255) DEFAULT '',
  `weight` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` text,
  `groups_view` varchar(255) DEFAULT '',
  `module_name` varchar(255) DEFAULT '',
  `op` varchar(255) DEFAULT '',
  `target` tinyint(4) DEFAULT '0',
  `css` varchar(255) DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`,`mid`)
) ENGINE=MyISAM  AUTO_INCREMENT=33  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_menu_rows`
--

INSERT INTO `ctypa_vi_menu_rows` VALUES
(1, 0, 1, 'Giới thiệu', '/index.php?language=vi&nv=about', '', '', 1, 1, 0, '2,3', '6', 'about', '', 1, '', 1, 1), 
(2, 1, 1, 'Giới thiệu về NukeViet 3.0', '/index.php?language=vi&nv=about&amp;op=Gioi-thieu-ve-NukeViet-3-0', '', '', 1, 2, 1, '', '6', 'about', 'Gioi-thieu-ve-NukeViet-3-0', 1, '', 1, 1), 
(3, 1, 1, 'Giới thiệu về công ty chuyên quản NukeViet', '/index.php?language=vi&nv=about&amp;op=Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', '', '', 2, 3, 1, '', '6', 'about', 'Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', 1, '', 1, 1), 
(4, 0, 1, 'Tin Tức', '/index.php?language=vi&nv=news', '', '', 2, 4, 0, '5,6,7,8,30,31,32', '6', 'news', '', 1, '', 1, 1), 
(5, 4, 1, 'Tin tức', '/index.php?language=vi&nv=news&amp;op=Tin-tuc', '', '', 1, 5, 1, '', '6', 'news', 'Tin-tuc', 1, '', 1, 1), 
(6, 4, 1, 'Sản phẩm', '/index.php?language=vi&nv=news&amp;op=San-pham', '', '', 2, 6, 1, '', '6', 'news', 'San-pham', 1, '', 1, 1), 
(7, 4, 1, 'Đối tác', '/index.php?language=vi&nv=news&amp;op=Doi-tac', '', '', 3, 7, 1, '', '6', 'news', 'Doi-tac', 1, '', 1, 1), 
(8, 4, 1, 'Tuyển dụng', '/index.php?language=vi&nv=news&amp;op=Tuyen-dung', '', '', 4, 8, 1, '', '6', 'news', 'Tuyen-dung', 1, '', 1, 1), 
(9, 0, 1, 'Thành viên', '/index.php?language=vi&nv=users', '', '', 3, 12, 0, '10,11,12,13,14,15,16', '6', 'users', '', 1, '', 1, 1), 
(10, 9, 1, 'Đăng nhập', '/index.php?language=vi&nv=users&op=login', '', '', 1, 13, 1, '', '5', 'users', 'login', 1, '', 1, 1), 
(11, 9, 1, 'Logout', '/index.php?language=vi&nv=users&op=logout', '', '', 2, 14, 1, '', '4', 'users', 'logout', 1, '', 1, 1), 
(12, 9, 1, 'Đăng ký', '/index.php?language=vi&nv=users&op=register', '', '', 3, 15, 1, '', '5', 'users', 'register', 1, '', 1, 1), 
(13, 9, 1, 'Quên mật khẩu', '/index.php?language=vi&nv=users&op=lostpass', '', '', 4, 16, 1, '', '5', 'users', 'lostpass', 1, '', 1, 1), 
(14, 9, 1, 'Đổi mật khẩu', '/index.php?language=vi&nv=users&op=changepass', '', '', 5, 17, 1, '', '4', 'users', 'changepass', 1, '', 1, 1), 
(15, 9, 1, 'Openid', '/index.php?language=vi&nv=users&op=openid', '', '', 6, 18, 1, '', '4', 'users', 'openid', 1, '', 1, 1), 
(16, 9, 1, 'Danh sách thành viên', '/index.php?language=vi&nv=users&op=memberlist', '', '', 7, 19, 1, '', '4', 'users', 'memberlist', 1, '', 1, 1), 
(17, 0, 1, 'Liên hệ', '/index.php?language=vi&nv=contact', '', '', 7, 28, 0, '18', '6', 'contact', '', 1, '', 1, 1), 
(18, 17, 1, 'Webmaster', '/index.php?language=vi&nv=contact&amp;op=1', '', '', 1, 29, 1, '', '6', 'contact', '1', 1, '', 1, 1), 
(19, 0, 1, 'Thống kê', '/index.php?language=vi&nv=statistics', '', '', 4, 20, 0, '20,21,22,23,24', '2', 'statistics', '', 1, '', 1, 1), 
(20, 19, 1, 'Theo đường dẫn đến site', '/index.php?language=vi&nv=statistics&amp;op=allreferers', '', '', 1, 21, 1, '', '2', 'statistics', 'allreferers', 1, '', 1, 1), 
(21, 19, 1, 'Theo quốc gia', '/index.php?language=vi&nv=statistics&amp;op=allcountries', '', '', 2, 22, 1, '', '2', 'statistics', 'allcountries', 1, '', 1, 1), 
(22, 19, 1, 'Theo trình duyệt', '/index.php?language=vi&nv=statistics&amp;op=allbrowsers', '', '', 3, 23, 1, '', '2', 'statistics', 'allbrowsers', 1, '', 1, 1), 
(23, 19, 1, 'Theo hệ điều hành', '/index.php?language=vi&nv=statistics&amp;op=allos', '', '', 4, 24, 1, '', '2', 'statistics', 'allos', 1, '', 1, 1), 
(24, 19, 1, 'Máy chủ tìm kiếm', '/index.php?language=vi&nv=statistics&amp;op=allbots', '', '', 5, 25, 1, '', '2', 'statistics', 'allbots', 1, '', 1, 1), 
(25, 0, 1, 'Thăm dò ý kiến', '/index.php?language=vi&nv=voting', '', '', 5, 26, 0, '', '6', 'voting', '', 1, '', 1, 1), 
(30, 4, 1, 'Rss', '/index.php?language=vi&nv=news&op=rss', '', '', 5, 9, 1, '', '6', 'news', 'rss', 1, '', 0, 1), 
(27, 0, 1, 'Tìm kiếm', '/index.php?language=vi&nv=seek', '', '', 6, 27, 0, '', '6', 'seek', '', 1, '', 1, 1), 
(31, 4, 1, 'Đăng bài viết', '/index.php?language=vi&nv=news&op=content', '', '', 6, 10, 1, '', '6', 'news', 'content', 1, '', 0, 1), 
(32, 4, 1, 'Tìm kiếm', '/index.php?language=vi&nv=news&op=search', '', '', 7, 11, 1, '', '6', 'news', 'search', 1, '', 0, 1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_modfuncs`
--

DROP TABLE IF EXISTS `ctypa_vi_modfuncs`;
CREATE TABLE `ctypa_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `alias` varchar(55) NOT NULL DEFAULT '',
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`),
  UNIQUE KEY `alias` (`alias`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=103  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_modfuncs`
--

INSERT INTO `ctypa_vi_modfuncs` VALUES
(1, 'sitemap', 'sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(2, 'main', 'main', 'Main', 'about', 1, 0, 2, ''), 
(3, 'sitemap', 'sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(5, 'content', 'content', 'Content', 'news', 1, 0, 7, ''), 
(6, 'detail', 'detail', 'Detail', 'news', 1, 0, 5, ''), 
(7, 'main', 'main', 'Main', 'news', 1, 0, 1, ''), 
(9, 'print', 'print', 'Print', 'news', 0, 0, 0, ''), 
(10, 'rating', 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(11, 'rss', 'rss', 'Rss', 'news', 1, 0, 9, ''), 
(12, 'savefile', 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(13, 'search', 'search', 'Search', 'news', 1, 0, 6, ''), 
(14, 'sendmail', 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(15, 'topic', 'topic', 'Topic', 'news', 1, 0, 3, ''), 
(16, 'viewcat', 'viewcat', 'Viewcat', 'news', 1, 0, 2, ''), 
(17, 'active', 'active', 'Active', 'users', 1, 1, 8, ''), 
(18, 'changepass', 'changepass', 'Đổi mật khẩu', 'users', 1, 1, 6, ''), 
(19, 'editinfo', 'editinfo', 'Editinfo', 'users', 1, 0, 10, ''), 
(20, 'login', 'login', 'Đăng nhập', 'users', 1, 1, 2, ''), 
(21, 'logout', 'logout', 'Logout', 'users', 1, 1, 3, ''), 
(22, 'lostactivelink', 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 9, ''), 
(23, 'lostpass', 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 5, ''), 
(24, 'main', 'main', 'Main', 'users', 1, 0, 1, ''), 
(25, 'openid', 'openid', 'Openid', 'users', 1, 1, 7, ''), 
(26, 'register', 'register', 'Đăng ký', 'users', 1, 1, 4, ''), 
(27, 'main', 'main', 'Main', 'contact', 1, 0, 1, ''), 
(28, 'allbots', 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''), 
(29, 'allbrowsers', 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''), 
(30, 'allcountries', 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''), 
(31, 'allos', 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''), 
(32, 'allreferers', 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''), 
(33, 'main', 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(34, 'referer', 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''), 
(35, 'main', 'main', 'Main', 'voting', 1, 0, 1, ''), 
(36, 'addads', 'addads', 'Addads', 'banners', 1, 0, 1, ''), 
(37, 'cledit', 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(38, 'click', 'click', 'Click', 'banners', 0, 0, 0, ''), 
(39, 'clientinfo', 'clientinfo', 'Clientinfo', 'banners', 1, 0, 2, ''), 
(40, 'clinfo', 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(41, 'logininfo', 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(42, 'main', 'main', 'Main', 'banners', 1, 0, 3, ''), 
(43, 'stats', 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(44, 'viewmap', 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(46, 'main', 'main', 'Main', 'seek', 1, 0, 1, ''), 
(47, 'main', 'main', 'Main', 'feeds', 1, 0, 1, ''), 
(48, 'regroups', 'regroups', 'Nhóm thành viên', 'users', 1, 0, 11, ''), 
(50, 'memberlist', 'memberlist', 'Danh sách thành viên', 'users', 1, 1, 12, ''), 
(51, 'groups', 'groups', 'Groups', 'news', 1, 0, 4, ''), 
(52, 'tag', 'tag', 'Tag', 'news', 1, 0, 8, ''), 
(53, 'main', 'main', 'Main', 'page', 1, 0, 1, ''), 
(54, 'main', 'main', 'main', 'comment', 1, 0, 1, ''), 
(55, 'post', 'post', 'post', 'comment', 1, 0, 2, ''), 
(56, 'like', 'like', 'Like', 'comment', 1, 0, 3, ''), 
(57, 'delete', 'delete', 'Delete', 'comment', 1, 0, 4, ''), 
(58, 'avatar', 'avatar', 'Avatar', 'users', 1, 0, 13, ''), 
(59, 'oauth', 'oauth', 'Oauth', 'users', 0, 0, 0, ''), 
(66, 'report', 'report', 'Report', 'download', 1, 0, 6, ''), 
(65, 'main', 'main', 'Main', 'download', 1, 1, 1, ''), 
(64, 'down', 'down', 'Down', 'download', 1, 0, 4, ''), 
(63, 'main', 'main', 'Main', 'support', 1, 0, 1, ''), 
(67, 'rss', 'rss', 'Rss', 'download', 0, 0, 0, ''), 
(68, 'search', 'search', 'Search', 'download', 1, 1, 7, ''), 
(69, 'sitemap', 'sitemap', 'Sitemap', 'download', 0, 0, 0, ''), 
(70, 'upload', 'upload', 'Upload', 'download', 1, 1, 5, ''), 
(71, 'viewcat', 'viewcat', 'Viewcat', 'download', 1, 0, 2, ''), 
(72, 'viewfile', 'viewfile', 'Viewfile', 'download', 1, 0, 3, ''), 
(73, 'detail', 'detail', 'Detail', 'photo', 1, 0, 2, ''), 
(74, 'main', 'main', 'Main', 'photo', 1, 0, 1, ''), 
(75, 'pagemap', 'pagemap', 'Pagemap', 'photo', 0, 0, 0, ''), 
(76, 'process', 'process', 'Process', 'photo', 0, 0, 0, ''), 
(77, 'rating', 'rating', 'Rating', 'photo', 0, 0, 0, ''), 
(78, 'rating____', 'rating____', 'Rating____', 'photo', 0, 0, 0, ''), 
(79, 'rss', 'rss', 'Rss', 'photo', 0, 0, 0, ''), 
(80, 'search', 'search', 'Search', 'photo', 0, 0, 0, ''), 
(81, 'sitemap-image', 'sitemap-image', 'Sitemap-image', 'photo', 0, 0, 0, ''), 
(82, 'sitemap', 'sitemap', 'Sitemap', 'photo', 0, 0, 0, ''), 
(83, 'upload', 'upload', 'Upload', 'photo', 0, 0, 0, ''), 
(84, 'viewcat', 'viewcat', 'Viewcat', 'photo', 1, 0, 3, ''), 
(85, 'main', 'main', 'Main', 'guestbook', 1, 0, 1, ''), 
(86, 'send', 'send', 'Send', 'guestbook', 1, 0, 2, ''), 
(87, 'main', 'main', 'Main', 'tkblop', 1, 0, 1, ''), 
(88, 'main', 'main', 'Main', 'diemex', 1, 0, 1, ''), 
(89, 'print', 'print', 'Print', 'diemex', 1, 0, 2, ''), 
(90, 'content', 'content', 'Content', 'laws', 1, 0, 8, ''), 
(91, 'down', 'down', 'Down', 'laws', 1, 0, 9, ''), 
(92, 'main', 'main', 'Main', 'laws', 1, 0, 1, ''), 
(93, 'search', 'search', 'Search', 'laws', 1, 0, 7, ''), 
(94, 'view', 'view', 'View', 'laws', 1, 0, 2, ''), 
(95, 'viewcat', 'viewcat', 'Viewcat', 'laws', 1, 0, 3, ''), 
(96, 'viewfield', 'viewfield', 'Viewfield', 'laws', 1, 0, 5, ''), 
(97, 'vieworgan', 'vieworgan', 'Vieworgan', 'laws', 1, 0, 6, ''), 
(98, 'viewroom', 'viewroom', 'Viewroom', 'laws', 1, 0, 4, ''), 
(99, 'rss', 'rss', 'Rss', 'about', 1, 0, 1, ''), 
(100, 'Sitemap', 'Sitemap', 'Sitemap', 'video-clip', 0, 0, 0, ''), 
(101, 'main', 'main', 'Main', 'video-clip', 1, 0, 1, ''), 
(102, 'rss', 'rss', 'Rss', 'video-clip', 0, 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_modthemes`
--

DROP TABLE IF EXISTS `ctypa_vi_modthemes`;
CREATE TABLE `ctypa_vi_modthemes` (
  `func_id` mediumint(8) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_modthemes`
--

INSERT INTO `ctypa_vi_modthemes` VALUES
(0, 'body', 'mobile_nukeviet'), 
(0, 'body-right', 'modern'), 
(0, 'left-body-right', 'default'), 
(2, 'body', 'mobile_nukeviet'), 
(2, 'body', 'modern'), 
(2, 'body-right', 'default'), 
(5, 'body', 'mobile_nukeviet'), 
(5, 'body-right', 'default'), 
(5, 'body-right', 'modern'), 
(6, 'body', 'mobile_nukeviet'), 
(6, 'body-right', 'default'), 
(6, 'body-right', 'modern'), 
(7, 'body', 'mobile_nukeviet'), 
(7, 'body-right', 'modern'), 
(7, 'home', 'default'), 
(11, 'body-right', 'default'), 
(11, 'body-right', 'modern'), 
(13, 'body', 'mobile_nukeviet'), 
(13, 'body-right', 'default'), 
(13, 'body-right', 'modern'), 
(15, 'body', 'mobile_nukeviet'), 
(15, 'body-right', 'default'), 
(15, 'body-right', 'modern'), 
(16, 'body', 'mobile_nukeviet'), 
(16, 'body-right', 'default'), 
(16, 'body-right', 'modern'), 
(17, 'body', 'mobile_nukeviet'), 
(17, 'body-right', 'default'), 
(17, 'body-right', 'modern'), 
(18, 'body', 'mobile_nukeviet'), 
(18, 'body-right', 'default'), 
(18, 'body-right', 'modern'), 
(19, 'body', 'mobile_nukeviet'), 
(19, 'body-right', 'default'), 
(19, 'body-right', 'modern'), 
(20, 'body', 'mobile_nukeviet'), 
(20, 'body-right', 'default'), 
(20, 'body-right', 'modern'), 
(21, 'body', 'mobile_nukeviet'), 
(21, 'body-right', 'default'), 
(21, 'body-right', 'modern'), 
(22, 'body', 'mobile_nukeviet'), 
(22, 'body-right', 'default'), 
(22, 'body-right', 'modern'), 
(23, 'body', 'mobile_nukeviet'), 
(23, 'body-right', 'default'), 
(23, 'body-right', 'modern'), 
(24, 'body', 'mobile_nukeviet'), 
(24, 'body-right', 'default'), 
(24, 'body-right', 'modern'), 
(25, 'body', 'mobile_nukeviet'), 
(25, 'body-right', 'default'), 
(25, 'body-right', 'modern'), 
(26, 'body', 'mobile_nukeviet'), 
(26, 'body-right', 'default'), 
(26, 'body-right', 'modern'), 
(27, 'body', 'mobile_nukeviet'), 
(27, 'body-right', 'default'), 
(27, 'body-right', 'modern'), 
(28, 'body', 'mobile_nukeviet'), 
(28, 'body', 'modern'), 
(28, 'body-right', 'default'), 
(29, 'body', 'mobile_nukeviet'), 
(29, 'body', 'modern'), 
(29, 'body-right', 'default'), 
(30, 'body', 'mobile_nukeviet'), 
(30, 'body', 'modern'), 
(30, 'body-right', 'default'), 
(31, 'body', 'mobile_nukeviet'), 
(31, 'body', 'modern'), 
(31, 'body-right', 'default'), 
(32, 'body', 'mobile_nukeviet'), 
(32, 'body', 'modern'), 
(32, 'body-right', 'default'), 
(33, 'body', 'mobile_nukeviet'), 
(33, 'body', 'modern'), 
(33, 'body-right', 'default'), 
(34, 'body', 'mobile_nukeviet'), 
(34, 'body', 'modern'), 
(34, 'body-right', 'default'), 
(35, 'body', 'mobile_nukeviet'), 
(35, 'body-right', 'default'), 
(35, 'body-right', 'modern'), 
(36, 'body', 'mobile_nukeviet'), 
(36, 'body-right', 'default'), 
(36, 'body-right', 'modern'), 
(39, 'body', 'mobile_nukeviet'), 
(39, 'body-right', 'default'), 
(39, 'body-right', 'modern'), 
(42, 'body', 'mobile_nukeviet'), 
(42, 'body-right', 'default'), 
(42, 'body-right', 'modern'), 
(43, 'body', 'mobile_nukeviet'), 
(43, 'body-right', 'default'), 
(43, 'body-right', 'modern'), 
(46, 'body', 'mobile_nukeviet'), 
(46, 'body-right', 'default'), 
(46, 'body-right', 'modern'), 
(47, 'body', 'mobile_nukeviet'), 
(47, 'body', 'modern'), 
(47, 'body-right', 'default'), 
(48, 'body', 'mobile_nukeviet'), 
(48, 'body-right', 'default'), 
(48, 'body-right', 'modern'), 
(50, 'body', 'mobile_nukeviet'), 
(50, 'body-right', 'default'), 
(50, 'body-right', 'modern'), 
(51, 'body', 'mobile_nukeviet'), 
(51, 'body-right', 'default'), 
(51, 'body-right', 'modern'), 
(52, 'body', 'mobile_nukeviet'), 
(52, 'body-right', 'default'), 
(52, 'body-right', 'modern'), 
(53, 'body', 'mobile_nukeviet'), 
(53, 'body', 'modern'), 
(53, 'body-right', 'default'), 
(54, 'body', 'mobile_nukeviet'), 
(54, 'body-right', 'default'), 
(54, 'body-right', 'modern'), 
(55, 'body', 'mobile_nukeviet'), 
(55, 'body-right', 'default'), 
(55, 'body-right', 'modern'), 
(56, 'body', 'mobile_nukeviet'), 
(56, 'body-right', 'default'), 
(56, 'body-right', 'modern'), 
(57, 'body', 'mobile_nukeviet'), 
(57, 'body-right', 'default'), 
(57, 'body-right', 'modern'), 
(58, 'body-right', 'default'), 
(63, 'body', 'mobile_nukeviet'), 
(63, 'body-right', 'default'), 
(63, 'body-right', 'modern'), 
(64, 'body', 'mobile_nukeviet'), 
(64, 'body-right', 'default'), 
(64, 'body-right', 'modern'), 
(65, 'body', 'mobile_nukeviet'), 
(65, 'body-right', 'default'), 
(65, 'body-right', 'modern'), 
(66, 'body', 'mobile_nukeviet'), 
(66, 'body-right', 'default'), 
(66, 'body-right', 'modern'), 
(67, 'left-body-right', 'default'), 
(68, 'body', 'mobile_nukeviet'), 
(68, 'body-right', 'default'), 
(68, 'body-right', 'modern'), 
(69, 'left-body-right', 'default'), 
(70, 'body', 'mobile_nukeviet'), 
(70, 'body-right', 'default'), 
(70, 'body-right', 'modern'), 
(71, 'body', 'mobile_nukeviet'), 
(71, 'body-right', 'default'), 
(71, 'body-right', 'modern'), 
(72, 'body', 'mobile_nukeviet'), 
(72, 'body-right', 'default'), 
(72, 'body-right', 'modern'), 
(73, 'body', 'mobile_nukeviet'), 
(73, 'body-right', 'default'), 
(73, 'body-right', 'modern'), 
(74, 'body', 'mobile_nukeviet'), 
(74, 'body-right', 'default'), 
(74, 'body-right', 'modern'), 
(75, 'left-body-right', 'default'), 
(76, 'left-body-right', 'default'), 
(77, 'left-body-right', 'default'), 
(78, 'left-body-right', 'default'), 
(79, 'left-body-right', 'default'), 
(80, 'left-body-right', 'default'), 
(81, 'left-body-right', 'default'), 
(82, 'left-body-right', 'default'), 
(83, 'left-body-right', 'default'), 
(84, 'body', 'mobile_nukeviet'), 
(84, 'body-right', 'default'), 
(84, 'body-right', 'modern'), 
(85, 'body', 'mobile_nukeviet'), 
(85, 'body-right', 'default'), 
(85, 'body-right', 'modern'), 
(86, 'body', 'mobile_nukeviet'), 
(86, 'body-right', 'default'), 
(86, 'body-right', 'modern'), 
(87, 'body', 'mobile_nukeviet'), 
(87, 'body-right', 'default'), 
(87, 'body-right', 'modern'), 
(88, 'body', 'mobile_nukeviet'), 
(88, 'body-right', 'default'), 
(88, 'body-right', 'modern'), 
(89, 'body', 'mobile_nukeviet'), 
(89, 'body-right', 'default'), 
(89, 'body-right', 'modern'), 
(90, 'body', 'mobile_nukeviet'), 
(90, 'body-right', 'default'), 
(90, 'body-right', 'modern'), 
(91, 'body', 'mobile_nukeviet'), 
(91, 'body-right', 'default'), 
(91, 'body-right', 'modern'), 
(92, 'body', 'mobile_nukeviet'), 
(92, 'body-right', 'default'), 
(92, 'body-right', 'modern'), 
(93, 'body', 'mobile_nukeviet'), 
(93, 'body-right', 'default'), 
(93, 'body-right', 'modern'), 
(94, 'body', 'mobile_nukeviet'), 
(94, 'body-right', 'default'), 
(94, 'body-right', 'modern'), 
(95, 'body', 'mobile_nukeviet'), 
(95, 'body-right', 'default'), 
(95, 'body-right', 'modern'), 
(96, 'body', 'mobile_nukeviet'), 
(96, 'body-right', 'default'), 
(96, 'body-right', 'modern'), 
(97, 'body', 'mobile_nukeviet'), 
(97, 'body-right', 'default'), 
(97, 'body-right', 'modern'), 
(98, 'body', 'mobile_nukeviet'), 
(98, 'body-right', 'default'), 
(98, 'body-right', 'modern'), 
(99, 'body-right', 'default'), 
(100, 'left-body-right', 'default'), 
(101, 'body', 'mobile_nukeviet'), 
(101, 'body-right', 'default'), 
(101, 'body-right', 'modern'), 
(102, 'left-body-right', 'default');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_modules`
--

DROP TABLE IF EXISTS `ctypa_vi_modules`;
CREATE TABLE `ctypa_vi_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `admin_title` varchar(255) DEFAULT '',
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) DEFAULT '',
  `mobile` varchar(100) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `keywords` text,
  `groups_view` varchar(255) NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) DEFAULT '',
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  `gid` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_modules`
--

INSERT INTO `ctypa_vi_modules` VALUES
('about', 'page', 'about', 'Giới thiệu', '', 1276333182, 1, 1, '', '', '', '', '6', 1, 1, '', 0, 0), 
('news', 'news', 'news', 'Tin Tức', '', 1270400000, 1, 1, '', '', '', '', '6', 2, 1, '', 1, 0), 
('users', 'users', 'users', 'Thành viên', 'Tài khoản', 1274080277, 1, 1, '', '', '', '', '6', 3, 1, '', 0, 0), 
('contact', 'contact', 'contact', 'Liên hệ', '', 1275351337, 1, 1, '', '', '', '', '6', 19, 1, '', 0, 0), 
('statistics', 'statistics', 'statistics', 'Thống kê', '', 1276520928, 1, 1, '', '', '', 'truy cập, online, statistics', '2', 8, 1, '', 0, 0), 
('voting', 'voting', 'voting', 'Thăm dò ý kiến', '', 1275315261, 1, 1, '', '', '', '', '6', 9, 1, '', 1, 0), 
('banners', 'banners', 'banners', 'Quảng cáo', '', 1270400000, 1, 1, '', '', '', '', '6', 10, 1, '', 0, 0), 
('seek', 'seek', 'seek', 'Tìm kiếm', '', 1273474173, 1, 0, '', '', '', '', '6', 20, 1, '', 0, 0), 
('menu', 'menu', 'menu', 'Menu Site', '', 1295287334, 0, 1, '', '', '', '', '6', 11, 1, '', 0, 0), 
('feeds', 'feeds', 'feeds', 'Rss Feeds', '', 1279366705, 1, 1, '', '', '', '', '6', 12, 1, '', 0, 0), 
('page', 'page', 'page', 'Page', '', 1279366705, 1, 1, '', '', '', '', '6', 13, 1, '', 0, 0), 
('comment', 'comment', 'comment', 'Bình luận', 'Quản lý bình luận', 1279366705, 1, 1, '', '', '', '', '6', 14, 1, '', 0, 0), 
('support', 'support', 'support', 'Support', '', 1430438302, 1, 1, '', '', '', '', '6', 15, 1, '', 0, 0), 
('download', 'download', 'download', 'Tài liệu học tập', '', 1430461513, 1, 1, '', '', '', '', '6', 4, 1, '', 1, 0), 
('photo', 'photo', 'photo', 'Hình ảnh', '', 1430462036, 1, 1, '', '', '', '', '6', 5, 1, '', 1, 0), 
('guestbook', 'guestbook', 'guestbook', 'Lưu bút', '', 1430462045, 1, 1, '', '', '', '', '6', 7, 1, '', 0, 0), 
('tkblop', 'tkblop', 'tkblop', 'Thời khóa biểu', 'Thời khóa biểu', 1453200596, 1, 1, '', '', 'thời khóa biểu', 'thời khóa biểu', '6', 16, 1, '', 0, 0), 
('diemex', 'diemex', 'diemex', 'Xem Điểm', 'Xem Điểm', 1453201055, 1, 1, '', '', 'xem điểm', 'xem điểm', '6', 17, 1, '', 0, 0), 
('laws', 'laws', 'laws', 'Văn bản', 'Văn bản', 1453201173, 1, 1, '', '', 'văn bản', 'văn bản', '6', 18, 1, '', 0, 0), 
('video-clip', 'video-clip', 'video_clip', 'Video', '', 1453419495, 1, 1, '', '', 'Video', '', '6', 6, 1, '', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_10`
--

DROP TABLE IF EXISTS `ctypa_vi_news_10`;
CREATE TABLE `ctypa_vi_news_10` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=82  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_10`
--

INSERT INTO `ctypa_vi_news_10` VALUES
(81, 10, '10', 0, 1, '', 4, 1453364095, 1453364095, 1, 1453363920, 0, 2, 'Địa điểm nào cho trải nghiệm 4G miễn phí?', 'dia-diem-nao-cho-trai-nghiem-4g-mien-phi', 'Trong ngày 18/1, nhà mạng VNPT Vinaphone tổ chức 6 điểm trải nghiệm dịch vụ ứng dụng trên nền tảng công nghệ mới 4G. Trong đó TP. Hồ Chí Minh có 2 địa điểm, huyện đảo Phú Quốc (Kiên Giang) có 4 địa điểm.', '2016_01/21-11-13.jpg', '', 1, 1, '4', 1, 21, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_11`
--

DROP TABLE IF EXISTS `ctypa_vi_news_11`;
CREATE TABLE `ctypa_vi_news_11` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=84  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_11`
--

INSERT INTO `ctypa_vi_news_11` VALUES
(82, 11, '11', 0, 1, '', 0, 1453365548, 1453365548, 1, 1453365420, 0, 2, 'Chức năng và vai trò Ngành công nghệ thông tin', 'chuc-nang-va-vai-tro-nganh-cong-nghe-thong-tin', 'CNTT là ngành sử dụng máy tính và phần mềm máy tính để chuyển đổi, lưu trữ, bảo vệ, xử lý, truyền, và thu thập thông tin. Người làm việc trong ngành này thường được gọi là dân CNTT (IT specialist) hoặc cố vấn quy trình doanh nghiệp (Business Process Consultant)', '2016_01/a998.jpg', 'Làm việc với máy vi tính', 1, 1, '4', 1, 15, 0, 0, 0), 
(83, 11, '11', 0, 1, '', 0, 1453365722, 1453365722, 1, 1453365540, 0, 2, 'Học ngành Công nghệ thông tin ra trường làm gì?', 'hoc-nganh-cong-nghe-thong-tin-ra-truong-lam-gi', 'Theo quy hoạch phát triển kinh tế giai đoạn đến 2020 thì Công nghệ thông tin là một trong những ngành mũi nhọn. Trong bối cảnh đó, ngày càng nhiều công ty công nghệ trong và ngoài nước mở rộng quy mô hoạt động tại Việt Nam và hướng ra khu vực, thế giới. Vì vậy, nhân sự ngành công nghệ thông tin hứa hẹn sẽ trở thành nguồn nhân lực then chốt để phát triển lĩnh vực công nghệ trong tương lai.  Những ai theo đuổi ngành Công nghệ thông tin cần tìm hiểu rõ học ngành Công nghệ thông tin ra trường làm gì? và làm ở đâu?...khi chọn ngành này làm hành trang nghề nghiệp.', '2016_01/tu-van-ngay-hoi.jpg', '', 1, 1, '4', 1, 23, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_12`
--

DROP TABLE IF EXISTS `ctypa_vi_news_12`;
CREATE TABLE `ctypa_vi_news_12` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_13`
--

DROP TABLE IF EXISTS `ctypa_vi_news_13`;
CREATE TABLE `ctypa_vi_news_13` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_8`
--

DROP TABLE IF EXISTS `ctypa_vi_news_8`;
CREATE TABLE `ctypa_vi_news_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=80  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_8`
--

INSERT INTO `ctypa_vi_news_8` VALUES
(79, 8, '8', 0, 1, '', 2, 1453363422, 1453363449, 1, 1453363080, 0, 2, 'Đại hội Đảng lần thứ XII&#x3A; Chiều 23&#x002F;1 sẽ nghe báo cáo nhân sự', 'dai-hoi-dang-lan-thu-xii-chieu-23-1-se-nghe-bao-cao-nhan-su', 'Ngày 23/1, Đại hội làm việc tại Hội trường cả ngày. Chiều cùng ngày, Đại hội nghe báo cáo của Ban Chấp hành Trung ương khóa XI về công tác nhân sự Ban Chấp hành Trung ương khóa XII.', '2016_01/dai-hoi-dang-lan-thu-xii-chieu-231-se-nghe-bao-cao-nhan-su.jpg', 'Toàn cảnh phiên khai mạc Đại hội sáng 21&#x002F;1.', 1, 1, '4', 1, 20, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_9`
--

DROP TABLE IF EXISTS `ctypa_vi_news_9`;
CREATE TABLE `ctypa_vi_news_9` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=85  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_9`
--

INSERT INTO `ctypa_vi_news_9` VALUES
(80, 9, '9', 0, 1, '', 3, 1453363738, 1453363784, 1, 1453363500, 0, 2, 'Bộ giáo dục công bố một số thay đổi trong mùa tuyển sinh 2016', 'bo-giao-duc-cong-bo-mot-so-thay-doi-trong-mua-tuyen-sinh-2016', 'Các thông tin này được ông Bùi Văn Ga, Thứ trưởng Bộ GD&ĐT trao đổi trong buổi họp báo định kỳ của Bộ GD&ĐT chiều nay (20/10).', '2016_01/bui.jpg', 'Ông Bùi Văn Ga - Thứ trưởng Bộ GD&amp;ĐT. Ảnh của Xuân Trung', 1, 1, '4', 1, 17, 0, 5, 1), 
(84, 9, '9', 0, 1, '', 5, 1453414418, 1453414418, 1, 1453414140, 0, 2, 'Trường Trung cấp Đắk Lắk kỉ niệm 5 năm thành lập và khai giảng năm học 2015-2016', 'truong-trung-cap-dak-lak-ki-niem-5-nam-thanh-lap-va-khai-giang-nam-hoc-2015-2016', 'Sáng ngày 19 tháng 12 năm 2015, Trường Trung cấp Đắk Lắk tổ chức kỉ niệm 5 năm thành lập trường ( 2010-2015) và khai giảng năm học mới 2015-2016', '2016_01/tcdl-1.jpg', 'Ông Phan Hồng- Giám đốc Sở GDĐT đánh trống khai giảng năm học 2015-2016', 1, 1, '4', 1, 23, 0, 10, 2);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_admins`
--

DROP TABLE IF EXISTS `ctypa_vi_news_admins`;
CREATE TABLE `ctypa_vi_news_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_block`
--

DROP TABLE IF EXISTS `ctypa_vi_news_block`;
CREATE TABLE `ctypa_vi_news_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_block`
--

INSERT INTO `ctypa_vi_news_block` VALUES
(1, 83, 2), 
(1, 81, 4), 
(1, 80, 5), 
(1, 82, 3), 
(1, 79, 6), 
(1, 84, 1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_block_cat`
--

DROP TABLE IF EXISTS `ctypa_vi_news_block_cat`;
CREATE TABLE `ctypa_vi_news_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_block_cat`
--

INSERT INTO `ctypa_vi_news_block_cat` VALUES
(1, 1, 4, 'Tin mới', 'Tin-moi', '', '', 1, '', 1430433561, 1430433561), 
(2, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', '', 2, '', 1430433568, 1430433568);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_bodyhtml_1`
--

DROP TABLE IF EXISTS `ctypa_vi_news_bodyhtml_1`;
CREATE TABLE `ctypa_vi_news_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_bodyhtml_1`
--

INSERT INTO `ctypa_vi_news_bodyhtml_1` VALUES
(79, '<p>Sau đó, các đại biểu thảo luận và biểu quyết về số lượng Ban Chấp hành Trung ương khóa XII.</p><p>Ngày 24/1, Đại hội thảo luận về tiêu chuẩn, cơ cấu Ban Chấp hành Trung ương khóa XII, tiếp tục trao đổi về tiêu chuẩn, cơ cấu, danh sách đề cử Ban Chấp hành Trung ương khóa XII. Các đại biểu ghi phiếu ứng cử, đề cử vào Ban Chấp hành Trung ương khóa XII.</p><p>Theo quy chế bầu cử được thông qua, ủy viên Trung ương Đảng khóa 11 nếu không nằm trong danh sách tái cử sẽ không được ứng cử, đề cử và nhận đề cử.</p><p>Dự kiến chiều 26/1, sẽ có kết quả bầu cử Ban Chấp hành Trung ương nhiệm kỳ mới, còn việc bầu Bộ Chính trị, Ban Bí thư và Tổng Bí thư sẽ diễn ra trong ngày 27/1.</p><p style=\"text-align: right;\"><strong>Phúc Hưng - Anh Thế</strong></p>', 'http://dantri.com.vn', 2, 0, 1, 1, 1, 0), 
(80, '<div class=\"body\" itemprop=\"articleBody\"><p>Ông Bùi Văn Ga cũng cho biết, hiện Bộ GD&amp;ĐT đã soạn thảo, trình Chính phủ, Thủ tướng Chính phủ ban hành và ban hành theo thẩm quyền một số văn bản quy phạm pháp luật có ý nghĩa quan trọng đối với sự nghiệp phát triển giáo dục và đào tạo, tạo căn cứ pháp lý để giải quyết các vấn đề thực tiễn, từng bước nâng cao chất lượng giáo dục, đào tạo.</p><p>Điển hình nhất là Quy định tiêu chuẩn phân tầng, khung xếp hạng và tiêu chuẩn xếp hạng cơ sở giáo dục đại học làm cơ sở để xếp hạng các cơ sở giáo dục đại học theo định hướng ứng dụng, nghiên cứu và định hướng thực hành.</p><p>Trong những năm vừa qua, theo báo cáo của Thứ trưởng Ga, số lượng sinh viên (cả đại học, cao đẳng) ổn định ở mức 2,3 triệu sinh viên, đặc biệt số vừa học vừa làm, liên thông giảm 20%. Theo đó, tập trung đào tạo chính quy để nâng cao chất lượng.</p><p>Theo tổng kết, trong năm học 2014 – 2015, đã có 11 trường đại học được Thủ tướng phê duyệt đề án tự chủ, đặc biệt là tự chủ tài chính, các trường được phép tăng học phí, đây là những trường có tôp thí sinh chất lượng đầu vào cao. Bước này tạo điều kiện để mở rộng cho những năm tiếp theo.</p><p>Đã có 15 trường đại học dân lập xây dựng hồ sơ để chuyển đổi sang mô hình tư thục, trong đó có 1 trường đã được chuyển đổi.</p><p>Nhấn mạnh trong năm học tới, ông Bùi Văn Ga cho biết, ngành sẽ phải tập trung vào những vấn đề đang được xã hội quan tâm.</p><p>Thứ nhất, phải cơ cấu lại hệ thống đại học, cao đẳng, nâng cao hiệu quả sử dụng nguồn nhân lực. Bởi thực tế, ông Gan dẫn chứng trong nhiều năm nhiều trường đại học không tuyển sinh được, gây lãng phí nguồn lực, từ vật chất cho tới đội ngũ.</p><p>Thêm nữa, phân tầng, xếp hạng đại học cũng sẽ tiến hành theo ba hạng như trong chỉ đạo của Chính phủ.</p><p>“Đào tạo lâu nay của chúng ta là chung chung, nếu không có định hướng thì hội nhập quốc tế rất khó cạnh tranh. Hiện Bộ cũng đã xây dựng xong khung trình độ đào tạo quốc gia. Đây là văn bản quan trọng, trong quá trình trình Thủ tướng, nếu được thông qua các trường phải xây dựng lại chuẩn đầu ra cho mình” ông Ga cho biết.</p><p>Thứ hai, trong năm học tới sẽ nhân rộng mô hình tự chủ đại học để phù hợp với chuẩn đầu ra, giảm chi phí cho nhà nước.</p><p>Thứ ba, trong năm tới tiếp tục khâu kiểm định chất lượng, đổi mới công tác tuyển sinh. Năm tới sẽ đưa những giải pháp mới, hướng là tăng thêm tự chủ cho các trường, đảm bảo quyền lợi thí sinh. Tất cả sẽ được bàn thảo trong Hội nghị tổng kết năm học 2014-2015 sắp tới.</p><p>&nbsp;</p></div><div class=\"source\" style=\"text-align: right;\">Phương Thảo</div>', 'http://giaoduc.net.vn', 2, 0, 1, 1, 1, 0), 
(81, '<p>Cụ thể, tại TP. HCM, người dùng có thể trải nghiệm công nghệ 4G LTE Advanced tại số 80 Nguyễn Du, Quận 1 và số 121 Pasteur, Quận 3. Trong khi đó huyện đảo Phú Quốc có đến 4 địa điểm cung cấp trải nghiệm công nghệ mạng mới là tại số 331 Nguyễn Trung Trực khu phố 5 Dương Đông (FPT Shop), số 2 Trần Hưng Đạo thị trấn Dương Đông, Safari Vinpearl Phú Quốc và khách sạn Sài gòn Phú Quốc.</p><p align=\"center\"><img alt=\"\" src=\"http://vnreview.vn/image/14/87/50/1487501.jpg?t=1453101467269\" style=\"width: 600px; height: 418px;\" /></p><p align=\"center\"><em>Thử nghiệm bằng trang Speedtest để đo tốc độ của mạng 4G trên di động. Ảnh Thanh Niên.</em></p><p>Tại mỗi địa điểm, VNPT Vinaphone đã tiến hành đặt các smartphone của nhiều hãng khác nhau với nhiều đời máy, được cài sẵn SIM 4G, để khách hàng có thể trải nghiệm các dịch vụ trên nền tảng này.</p><p>Ngoài ra các khách hàng có thể đổi sim 4G miễn phí tại 6 điểm trải nghiệm của VinaPhone, đồng thời nhận gói cước khuyến mại miễn phí sử dụng dữ liệu 4G trong vòng 7 ngày kể từ ngày trải nghiệm.</p><p align=\"center\"><img alt=\"\" src=\"http://vnreview.vn/image/14/87/49/1487498.jpg?t=1453101467269\" style=\"width: 654px; height: 430px;\" /></p><p align=\"center\"><em>Cận cảnh SIM 4G của VNPT VinaPhone. Ảnh ICTNews.</em></p><p>Các dịch vụ 4G LTE Advanced được nhà mạng này cung cấp bao gồm xem video chất lượng cao (Mobile TV), truyền video Live streaming (Mobile Broadcast), truyền hình hội nghị (Cloud Video Conferencing) và dịch vụ sử dụng máy tính ảo (Daas).</p><p>Đây là những dịch vụ cần tốc độ và dung lượng rất cao về dữ liệu, nhạy cảm về độ trễ. Công nghệ 4G cho tốc độ trung bình cao hơn 3G khoảng 10-20 lần, độ trễ của dịch vụ thấp, đặc biệt vùng phủ sóng ổn định hơn hẳn so với 3G.</p><p>Mạng 4G LTE mà VNPT Vinaphone công bố đạt tốc độ download 336,30Mbps và upload là 39,41Mbps.</p><p>VinaPhone cho biết cước sử dụng 4G sẽ không tăng so với 3G. Dự kiến, nhà mạng này sẽ cung cấp 4G theo kiểu gói dịch vụ, chứ không tính theo dung lượng.</p><p>Trước đó, ngày 15/1, mạng di động này đã có buổi thử nghiệm công nghệ LTE-Advanced tại TP HCM với hơn 100 trạm BTS. Trong điều kiện tối ưu, tốc độ download trung bình đạt mức 95,9 Mbps – 245,63 Mbps.</p><p style=\"text-align: right;\"><strong>G.L</strong></p>', 'vnreview.vn', 0, 0, 1, 1, 1, 0), 
(82, 'Ở Việt Nam: Khái niệm CNTT được hiểu và định nghĩa trong nghị quyết Chính phủ 49/CP kí ngày 04/08/1993: Công nghệ thông tin là tập hợp các phương pháp khoa học, các phương tiện và công cụ kĩ thuật hiện đại - chủ yếu là kĩ thuật máy tính và viễn thông - nhằm tổ chức khai thác và sử dụng có hiệu quả các nguồn tài nguyên thông tin rất phong phú và tiềm năng trong mọi lĩnh vực hoạt động của con người và xã hội.<br  /><br  />Trong hệ thống giáo dục Tây phương, CNTT đã được chính thức tích hợp vào chương trình học phổ thông. Người ta đã nhanh chóng nhận ra rằng nội dung về CNTT đã có ích cho tất cả các môn học khác.<br  /><br  />Với sự ra đời của Internet mà các kết nối băng tần rộng tới tất cả các trường học, áp dụng của kiến thức, kỹ năng và hiểu biết về CNTT trong các môn học đã trở thành hiện thực.<br  />&nbsp;<h2>Một đố đặc điểm công việc của ngành công nghệ thông tin</h2><p><strong><em>Lập trình</em></strong> (thao khảo thêm trong bài giới thiệu về ngành Phát triển phần mềm): Công việc chính của lập trình viên là sử dụng những công cụ và ngôn ngữ lập trình để phân tích, thiết kế, tạo ra những phần mềm, website, trò chơi cung cấp cho thị trường. Đây là nghề đang phát triển mạnh ở nước ta và được nhiều bạn trẻ quan tâm. Các công ty phần mềm nghiên cứu, xây dựng, phát triển và cung cấp các phần mềm, các ứng dụng xây dựng website, games v.v… cho thị trường là điểm đến của các lập trình viên.</p><p><strong><em>Chế tạo, lắp ráp và sửa chữa phần cứng:</em></strong> Những người làm trong lĩnh vực này có khả năng chế tạo, sửa chữa hay lắp ráp, lắp đặt các thiết bị, linh kiện của máy tính như ổ cứng, bo mạch, bộ vi xử lý. Các công ty sản xuất, lắp ráp và sửa chữa thiết bị phần cứng đang hứa hẹn một nền công nghiệp hùng mạnh trong tương lai.</p><p><strong><em>Thiết kế giải pháp tích hợp:</em></strong> Công việc này đòi hỏi các chuyên gia phải am hiểu cả phần cứng và phần mềm, có khả năng thiết kế các giải pháp trọn gói cho một công ty, tổ chức về cả phần cứng lẫn phần mềm, dựa trên yêu cầu cụ thể. Họ làm nhiệm vụ tại các công ty cung cấp giải pháp tích hợp hiện đang trên đà phát triển tại Việt Nam.</p><p><strong><em>Quản trị hệ thông và an ninh mạng:</em></strong> Ngày nay, hầu hết các công ty, doanh nghiệp, tổ chức đều có hệ thống máy vi tính kết nối mạng. Người làm công tác quản trị hệ thống và an ninh mạng có nhiệm vụ bảo đảm cho hệ thống vận hành suôn sẻ, giải quyết trục trặc khi hệ thông gặp sự cố, đảm bảo an toàn và bảo mật cho dữ liệu. Trong lĩnh vực này, bạn sẽ làm việc tại các công ty cung cấp giải pháp về mạng và an ninh mạng, các cơ quan, doanh nghiệp v.v…</p><p style=\"text-align: center;\">&nbsp;</p><h3>Phẩm chất và kỹ năng cần thiết để có thể theo ngành công nghệ thông tin:</h3><p>- Thông minh và có óc sáng tạo<br  />- Khả năng làm việc dưới áp lực lớn<br  />- Kiên trì, nhẫn nại.<br  />- Tính chính xác trong công việc<br  />- Ham học hỏi, trau dồi kiến thức<br  />- Khả năng làm việc theo nhóm<br  />- Trình độ ngoại ngữ (để tiếp cận kho tàng phong phú về CNTT từ các nguồi sách điện tử và Internet)<br  />Và quan trọng nhất là niềm đammê với CNT<br  /><br  /><strong>Một số địa chỉ đào tạo</strong><br  /><br  />Nếu bạn muốn theo học ngành CNTT, có rất nhiều địa chỉ để bạn lựa chọn: Khoa Công nghệ thông tin của trường ĐH Bách khoa Hà Nội, trường ĐH Bách khoa TP.HCM, trường ĐH Khoa học tự nhiên Hà Nội và TP.HCM, trường ĐH Công nghệ (ĐHQG Hà Nội) v.v…và rất nhiều trường ĐH, CĐ khác.<br  /><br  />Bạn cũng có thể học công nghệ thông tin ở các trung tâm nổi tiếng chuyên đào tạo CNTT như HanoiCTT, SaigonCTT, công ty IPMAC, trung tâm in học Trí Việt (VnPro), trung tâm đào tạo lập trình viên quốc tế Aptech ở Hà Nội và TP.HCM v.v…<br  />&nbsp;</p><div class=\"khung_vang_den\">.Tin học có khác Công nghệ thông tin?<br  /><br  />Đối với ngành CNTT, đã có nhiều bạn đọc gửi e-mail về thắc mắc ngành Tin học và CNTT khác nhau như thế nào, tại sao có trường đào tạo ngành Tin học, có trường đào tạo ngành CNTT? Bằng kỹ sư CNTT và bằng cử nhân CNTT khác nhau ra sao?<br  /><br  />TS Quách Tuấn Ngọc đã trả lời cho những thắc mắc này như sau:<br  /><br  />Về thuật ngữ, Tin học được dịch từ Informatique (tiếng Pháp) là tên chuyên ngành được phổ biến từ những năm 1970 đến 1990. Tiếng Anh thì vẫn dùng phổ biến là Computer Science.<br  /><br  />Khoảng năm 1990, thế giới phổ biến dùng CNTT, dịch từ Information Technology.<br  /><br  />Đến năm 2000, thế giới lại dùng là ICT (Information and Communication Technology), cho thấy sự hội tụ giữa Tin học và Viễn thông.<br  /><br  />Hiện nay, ở Việt Nam, các trường có nơi gọi là khoa Tin học, có nơi gọi là Khoa CNTT, nhưng về nội hàm thì không khác biệt.<br  /><br  />Các trường đại học kỹ thuật hệ 5 năm như ĐHBK thì bằng tốt nghiệp mang tên bằng kỹ sư.<br  /><br  />Các trường khác đào tạo hệ 4 năm như ĐH Công nghệ... thì bằng tốt nghiệp gọi là bằng cử nhân.</div><p><br  />&nbsp;</p>.Tuy nhiên, để theo đuổi ngành CNTT bạn cũng cần phải biết những khó khăn của ngành này, hãy tham khảo thêm tại chuyên mục này để về những khó khăn đó.', '', 2, 0, 1, 1, 1, 0), 
(83, '<span style=\"font-family:verdana;\"><span style=\"font-size:13px;\">Bài viết sau sẽ cung cấp cho bạn thông tin cần thiết để định hướng rõ hơn nghề nghiệp của <span style=\"text-decoration:none;text-underline:none;\">ngành Công nghệ thông tin</span>.</span></span><br  />&nbsp;<div style=\"text-align:center\"><img alt=\"tu van ngay hoi\" height=\"427\" src=\"/uploads/news/2016_01/tu-van-ngay-hoi.jpg\" style=\"height: 427px; width: 640px;\" width=\"640\" /></div><div style=\"text-align: center;\"><span style=\"font-family:verdana;\"><span style=\"font-size:13px;\"><em>Ban tư vấn UEF giúp các em học sinh làm rõ khúc mắc: Học ngành Công nghệ thông tin ra trường làm gì?</em></span></span></div>&nbsp;<div style=\"text-align: justify;\"><span style=\"font-family:verdana;\"><span style=\"font-size:13px;\"><strong><span style=\"border:none windowtext 1.0pt;padding:0in;\">Học ngành Công nghệ thông tin ra trường làm gì?</span></strong><br  />Công nghệ thông tin (IT) ngày càng trở thành lựa chọn của nhiều bạn trẻ nhiệt huyết, yêu thích lĩnh vực công nghệ.<span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\"> Muốn tạo nên sự khác biệt tích cực cho thế giới thì IT là một trong những con đường lựa chọn đúng đắn của bạn bởi IT ngày nay là công cụ quan trọng không thể thiếu trong các lĩnh vực khoa học công nghệ.</span><br  />Cơ hội việc làm của Công nghệ thông tin cho bạn rất nhiều lựa chọn hấp dẫn :<br  />- Lập trình viên: người trực tiếp tạo ra các sản phẩm công nghệ như phần mềm, hệ thống thông tin;<br  />- Kiểm duyệt chất lượng phần mềm: trực tiếp kiểm tra chất lượng các sản phẩm công nghệ do lập trình viên tạo ra;<br  />- Chuyên viên phân tích thiết kế hệ thống, quản lý dữ liệu, quản trị mạng, kỹ thuật phần cứng máy tính;<br  />- Chuyên gia quản lý, kinh doanh, điều phối các dự án công nghệ thông tin;<br  />- Giảng dạy và nghiên cứu về công nghệ thông tin tại các cơ sở đào tạo…<br  /><strong><span style=\"border:1pt none windowtext;padding:0in;background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">Học ngành Công nghệ thông tin làm việc ở đâu?</span></strong><br  /><span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">Tốt nghiệp ngành Công nghệ thông tin bạn có thể làm việc tại:</span><br  /><span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">- Các công ty, tập đoàn về công nghệ thông tin; &nbsp;</span><br  /><span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">- Các công ty sản xuất, lắp ráp, sửa chữa trang thiết bị phần cứng;</span><br  /><span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">- Các công ty cung cấp giải pháp tích hợp;</span><br  /><span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">- Các công ty cung cấp giải pháp về mạng và an ninh mạng;</span><br  /><span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">- Bộ phận Quản trị, bộ phận IT tại các công ty, kể cả&nbsp;công ty hoạt động trong lĩnh vực Công nghệ và các lĩnh vực khác như ngân hàng, y tế, giáo dục, giải trí...</span><br  /><span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">- Giảng viên các trường đại học, cao đẳng, học viên, trung tâm có đào tạo Công nghệ thông tin.</span><br  /><span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">Thống kê của Bộ Thông tin - Truyền thông, đến năm 2020, nhân lực trong lĩnh vực IT mỗi năm tăng 13%. Theo đó, lĩnh vực Công nghệ thông tin ở Việt Nam cần đến 1 triệu lao động hoạt động. Song song đó, một sự ưu ái&nbsp;khác của thị trường lao động đối với ngành này là thực tế các cuộc khủng hoảng kinh tế gần đây đã minh chứng, nhân lực thuộc lĩnh vực công nghệ thông tin là một trong những ngành ít&nbsp;chịu sự tác động&nbsp;nhất.</span><br  /><span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">Như vậy, để thành công với những công việc trên đòi hỏi bạn phải lựa chọn cho bản thân một chương trình đào tạo Công nghệ thông tin uy tín ở các trường đại học phù hợp như Đại học Bách khoa Tp.HCM, Đại học Khoa học tự nhiên, Đại học Kinh tế Tài chính Tp.HCM (UEF), Đại học Công nghệ Tp.HCM - HUTECH, Đại học Công nghệ thông tin... </span><br  /><span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">Ngoài kiến thức chuyên môn về IT được đào tạo, sinh viên cũng cần trang bị thêm yếu tố ngoại ngữ, kỹ năng nghề nghiệp, kỹ năng mềm cần thiết. Đáp ứng nhu cầu đó, có thể nói UEF là một trong những trường tiên phong chú trọng khối kiến thức nghề toàn diện. Ngoài ra, sinh viên IT của UEF </span>còn có cơ hội tiếp cận với môi trường kinh doanh thực tế thông qua những buổi kiến tập và thực tập tại các doanh nghiệp, những chia sẻ từ các doanh nhân, chuyên gia hàng đầu trong lĩnh vực công nghệ hay tiếp cận những dự án kinh doanh các bạn tự tiến hành triển khai...Từ đó, sinh viên có cái nhìn toàn diện và sâu rộng về nghề nghiệp mình có dự định theo đuổi, trang bị thêm kiến thức và kinh nghiệm thực tế để tự tin chinh phục đỉnh cao nghề nghiệp.<br  /><span style=\"background-image:initial;background-attachment:initial;background-size:initial;background-origin:initial;background-clip:initial;background-position:initial;background-repeat:initial;\">Với những thông tin trong bài viết thì vấn đề&nbsp;<em><span style=\"border:none windowtext 1.0pt;padding:0in;\">học ngành Công nghệ thông tin ra trường làm gì?</span></em>&nbsp;<em><span style=\"border:none windowtext 1.0pt;padding:0in;\">và làm việc ở đâu? chắc chắn </span></em>không còn là nỗi lo lắng, băn khoăn của các bạn khi chọn ngành học đấy sáng tạo này.</span></span></span><br  />&nbsp;</div><div style=\"text-align: right;\"><span style=\"color:rgb(178, 34, 34);\"><strong><span style=\"font-family:verdana;\"><span style=\"font-size:13px;\">Quỳnh Anh</span></span></strong></span></div>', '', 0, 0, 1, 1, 1, 0), 
(84, 'Đến tham dự buổi lễ có ông Nguyễn Đình Hoàng- Phó Bí thư Đảng ủy khối các cơ quan tỉnh, ông Phan Hồng- Giám đốc Sở GDĐT, đại diện lãnh đạo các trường đại học, cao đẳng, trung cấp chuyên nghiệp trên địa bàn tỉnh, các doanh nghiệp liên kết đào tạo cùng cán bộ, giáo viên và học sinh toàn trường.<p style=\"text-align: justify;\">Mở đầu buổi lễ, ông Phan Hồng đọc thư của Chủ tịch nước Trương Tấn Sang gửi Ngành Giáo dục nhân dịp năm học mới 2015-2016.</p><p style=\"text-align: center;\"><img alt=\"TCDL 2\" height=\"297\" src=\"/uploads/news/2016_01/tcdl-2.jpg\" width=\"500\" /><br  /><span style=\"color:rgb(0, 0, 255);\"><em>Ông Võ Văn Chúng- Hiệu trưởng trường TC Đắk Lắk báo cáo kết quả 5 năm xây dựng và phát triển nhà trường</em></span></p><p style=\"text-align: justify;\">Ông Võ Văn Chúng- Hiệu trưởng trường Trung cấp Đắk Lắk báo cáo kết quả 5 năm xây dựng và phát triển. Trường Trung cấp Đắk Lắk thành lập ngày 3-3-2010 trên cơ sở nâng cấp Trung tâm Ngoại ngữ - Tin học Đắk Lắk. Từ khi thành lập đến nay, nhà trường đã đào tạo 6 khóa, với 1.554 học sinh (HS) thuộc 8 chuyên ngành ở các lĩnh vực: Kế toán, Tài chính - Ngân hàng, Công nghệ Thông tin, Hành chính - Văn thư, Xây dựng dân dụng - Công nghiệp, Xây dựng cầu đường, Quản lý đất đai, Trồng trọt và bảo vệ thực vật.</p><p style=\"text-align: justify;\">Với phương châm “Đào tạo gắn với thực tiễn nghề nghiệp”, nhà trường đã liên kết với hơn 40 đơn vị, doanh nghiệp cùng tham gia đào tạo thực hành nghề nghiệp. Nhờ đó chất lượng đào tạo không ngừng nâng cao, với 27,8% HS xếp loại xuất sắc, giỏi; có 72 HS đạt danh hiệu HS trung cấp chuyên nghiệp giỏi cấp trường, 16 HS đạt danh hiệu HS thực hành giỏi cấp tỉnh. Đặc biệt trên 90% HS có việc làm sau tốt nghiệp hoặc học liên thông lên bậc cao hơn. Ngoài ra, nhà trường còn dạy nghề phổ thông cho 6.740 HS trung học cơ sở; đào tạo nghề ngắn hạn cho 6.793 học viên và liên kết đào tạo trình độ trung cấp chuyên nghiệp, cao đẳng, đại học cho 2.414 học sinh, sinh viên.&nbsp;</p><p style=\"text-align: justify;\">Với những thành tích trên, 3 năm học nhà trường được công nhận Tập thể lao động xuất sắc, 4 năm học được UBND tỉnh tặng Bằng khen hoàn thành xuất sắc nhiệm vụ năm học; các tổ chức đoàn thể của trường được UBND tỉnh, Trung ương Hội Liên hiệp Thanh niên Việt Nam, Trung ương Hội Sinh viên Việt Nam, Liên đoàn Lao động tỉnh tặng Bằng khen; 1 cá nhân được tặng thưởng Huân chương Lao động hạng Ba và nhiều cán bộ quản lý, giáo viên được tặng Kỷ niệm chương &quot;Vì sự nghiệp Giáo dục&quot;, “Bảo vệ an ninh Tổ quốc”, “Vì thế hệ trẻ”…</p><p style=\"text-align: center;\"><img alt=\"\" height=\"279\" src=\"/uploads/news/2016_01/tcdl-3.jpg\" width=\"500\" /><br  /><span style=\"color:rgb(0, 0, 255);\"><em>Ông Phan Hồng trao chứng nhận Tập thể Lao động xuất sắc và Bằng khen cho các cá nhân xuất sắc</em></span></p><p style=\"text-align: justify;\">Phát biểu tại buổi lễ, ông Phan Hồng thay mặt ngành Giáo dục và Đào tạo ghi nhận và biểu dương những thành tích hoạt động của trường Trung cấp Đắk Lắk qua 5 năm xây dựng và phát triển. Trong thời gian tới, trường Trung cấp Đắk Lắk cần tiếp tục quán triệt sâu sắc các Nghị quyết của Đảng, xây dựng tập thể cán bộ, giáo viên, nhân viên có năng lực và tâm huyết với nghề, đổi mới mạnh mẽ công tác quản lý giáo dục, đẩy mạnh công tác nghiên cứu khoa học trong giáo viên và học sinh; tăng cường liên kết với các doanh nghiệp trong việc đào tạo, phát triển chương trình nhằm nâng cao hiệu quả chất lượng tay nghề cho học sinh đáp ứng được yêu cầu của nhà tuyển dụng để đáp ứng lòng tin tưởng, mong mỏi của các cấp bộ Đảng, chính quyền và nhân dân tỉnh Đắk Lắk.</p><p style=\"text-align: justify;\">Tại lễ kỷ niệm và khai giảng năm học mới, các đơn vị tài trợ đã trao 15 suất học bổng (mỗi suất trị giá 1 triệu đồng) cho các em học sinh hiếu học.&nbsp;</p>', 'http://daklak.edu.vn', 2, 0, 1, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_bodytext`
--

DROP TABLE IF EXISTS `ctypa_vi_news_bodytext`;
CREATE TABLE `ctypa_vi_news_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_bodytext`
--

INSERT INTO `ctypa_vi_news_bodytext` VALUES
(79, 'Sau đó, các đại biểu thảo luận và biểu quyết về số lượng Ban Chấp hành Trung ương khóa XII.  Ngày 24/1, Đại hội thảo luận về tiêu chuẩn, cơ cấu Ban Chấp hành Trung ương khóa XII, tiếp tục trao đổi về tiêu chuẩn, cơ cấu, danh sách đề cử Ban Chấp hành Trung ương khóa XII. Các đại biểu ghi phiếu ứng cử, đề cử vào Ban Chấp hành Trung ương khóa XII.  Theo quy chế bầu cử được thông qua, ủy viên Trung ương Đảng khóa 11 nếu không nằm trong danh sách tái cử sẽ không được ứng cử, đề cử và nhận đề cử.  Dự kiến chiều 26/1, sẽ có kết quả bầu cử Ban Chấp hành Trung ương nhiệm kỳ mới, còn việc bầu Bộ Chính trị, Ban Bí thư và Tổng Bí thư sẽ diễn ra trong ngày 27/1.  Phúc Hưng - Anh Thế'), 
(80, ' Ông Bùi Văn Ga cũng cho biết, hiện Bộ GD&amp;ĐT đã soạn thảo, trình Chính phủ, Thủ tướng Chính phủ ban hành và ban hành theo thẩm quyền một số văn bản quy phạm pháp luật có ý nghĩa quan trọng đối với sự nghiệp phát triển giáo dục và đào tạo, tạo căn cứ pháp lý để giải quyết các vấn đề thực tiễn, từng bước nâng cao chất lượng giáo dục, đào tạo.  Điển hình nhất là Quy định tiêu chuẩn phân tầng, khung xếp hạng và tiêu chuẩn xếp hạng cơ sở giáo dục đại học làm cơ sở để xếp hạng các cơ sở giáo dục đại học theo định hướng ứng dụng, nghiên cứu và định hướng thực hành.  Trong những năm vừa qua, theo báo cáo của Thứ trưởng Ga, số lượng sinh viên (cả đại học, cao đẳng) ổn định ở mức 2,3 triệu sinh viên, đặc biệt số vừa học vừa làm, liên thông giảm 20%. Theo đó, tập trung đào tạo chính quy để nâng cao chất lượng.  Theo tổng kết, trong năm học 2014 – 2015, đã có 11 trường đại học được Thủ tướng phê duyệt đề án tự chủ, đặc biệt là tự chủ tài chính, các trường được phép tăng học phí, đây là những trường có tôp thí sinh chất lượng đầu vào cao. Bước này tạo điều kiện để mở rộng cho những năm tiếp theo.  Đã có 15 trường đại học dân lập xây dựng hồ sơ để chuyển đổi sang mô hình tư thục, trong đó có 1 trường đã được chuyển đổi.  Nhấn mạnh trong năm học tới, ông Bùi Văn Ga cho biết, ngành sẽ phải tập trung vào những vấn đề đang được xã hội quan tâm.  Thứ nhất, phải cơ cấu lại hệ thống đại học, cao đẳng, nâng cao hiệu quả sử dụng nguồn nhân lực. Bởi thực tế, ông Gan dẫn chứng trong nhiều năm nhiều trường đại học không tuyển sinh được, gây lãng phí nguồn lực, từ vật chất cho tới đội ngũ.  Thêm nữa, phân tầng, xếp hạng đại học cũng sẽ tiến hành theo ba hạng như trong chỉ đạo của Chính phủ.  “Đào tạo lâu nay của chúng ta là chung chung, nếu không có định hướng thì hội nhập quốc tế rất khó cạnh tranh. Hiện Bộ cũng đã xây dựng xong khung trình độ đào tạo quốc gia. Đây là văn bản quan trọng, trong quá trình trình Thủ tướng, nếu được thông qua các trường phải xây dựng lại chuẩn đầu ra cho mình” ông Ga cho biết.  Thứ hai, trong năm học tới sẽ nhân rộng mô hình tự chủ đại học để phù hợp với chuẩn đầu ra, giảm chi phí cho nhà nước.  Thứ ba, trong năm tới tiếp tục khâu kiểm định chất lượng, đổi mới công tác tuyển sinh. Năm tới sẽ đưa những giải pháp mới, hướng là tăng thêm tự chủ cho các trường, đảm bảo quyền lợi thí sinh. Tất cả sẽ được bàn thảo trong Hội nghị tổng kết năm học 2014-2015 sắp tới.      Phương Thảo'), 
(81, 'Cụ thể, tại TP. HCM, người dùng có thể trải nghiệm công nghệ 4G LTE Advanced tại số 80 Nguyễn Du, Quận 1 và số 121 Pasteur, Quận 3. Trong khi đó huyện đảo Phú Quốc có đến 4 địa điểm cung cấp trải nghiệm công nghệ mạng mới là tại số 331 Nguyễn Trung Trực khu phố 5 Dương Đông (FPT Shop), số 2 Trần Hưng Đạo thị trấn Dương Đông, Safari Vinpearl Phú Quốc và khách sạn Sài gòn Phú Quốc.   http://vnreview.vn/image/14/87/50/1487501.jpg?t=1453101467269  Thử nghiệm bằng trang Speedtest để đo tốc độ của mạng 4G trên di động. Ảnh Thanh Niên.  Tại mỗi địa điểm, VNPT Vinaphone đã tiến hành đặt các smartphone của nhiều hãng khác nhau với nhiều đời máy, được cài sẵn SIM 4G, để khách hàng có thể trải nghiệm các dịch vụ trên nền tảng này.  Ngoài ra các khách hàng có thể đổi sim 4G miễn phí tại 6 điểm trải nghiệm của VinaPhone, đồng thời nhận gói cước khuyến mại miễn phí sử dụng dữ liệu 4G trong vòng 7 ngày kể từ ngày trải nghiệm.   http://vnreview.vn/image/14/87/49/1487498.jpg?t=1453101467269  Cận cảnh SIM 4G của VNPT VinaPhone. Ảnh ICTNews.  Các dịch vụ 4G LTE Advanced được nhà mạng này cung cấp bao gồm xem video chất lượng cao (Mobile TV), truyền video Live streaming (Mobile Broadcast), truyền hình hội nghị (Cloud Video Conferencing) và dịch vụ sử dụng máy tính ảo (Daas).  Đây là những dịch vụ cần tốc độ và dung lượng rất cao về dữ liệu, nhạy cảm về độ trễ. Công nghệ 4G cho tốc độ trung bình cao hơn 3G khoảng 10-20 lần, độ trễ của dịch vụ thấp, đặc biệt vùng phủ sóng ổn định hơn hẳn so với 3G.  Mạng 4G LTE mà VNPT Vinaphone công bố đạt tốc độ download 336,30Mbps và upload là 39,41Mbps.  VinaPhone cho biết cước sử dụng 4G sẽ không tăng so với 3G. Dự kiến, nhà mạng này sẽ cung cấp 4G theo kiểu gói dịch vụ, chứ không tính theo dung lượng.  Trước đó, ngày 15/1, mạng di động này đã có buổi thử nghiệm công nghệ LTE-Advanced tại TP HCM với hơn 100 trạm BTS. Trong điều kiện tối ưu, tốc độ download trung bình đạt mức 95,9 Mbps – 245,63 Mbps.  G.L'), 
(82, 'Ở Việt Nam: Khái niệm CNTT được hiểu và định nghĩa trong nghị quyết Chính phủ 49/CP kí ngày 04/08/1993: Công nghệ thông tin là tập hợp các phương pháp khoa học, các phương tiện và công cụ kĩ thuật hiện đại - chủ yếu là kĩ thuật máy tính và viễn thông - nhằm tổ chức khai thác và sử dụng có hiệu quả các nguồn tài nguyên thông tin rất phong phú và tiềm năng trong mọi lĩnh vực hoạt động của con người và xã hội.  Trong hệ thống giáo dục Tây phương, CNTT đã được chính thức tích hợp vào chương trình học phổ thông. Người ta đã nhanh chóng nhận ra rằng nội dung về CNTT đã có ích cho tất cả các môn học khác.  Với sự ra đời của Internet mà các kết nối băng tần rộng tới tất cả các trường học, áp dụng của kiến thức, kỹ năng và hiểu biết về CNTT trong các môn học đã trở thành hiện thực.   Một đố đặc điểm công việc của ngành công nghệ thông tin  Lập trình (thao khảo thêm trong bài giới thiệu về ngành Phát triển phần mềm): Công việc chính của lập trình viên là sử dụng những công cụ và ngôn ngữ lập trình để phân tích, thiết kế, tạo ra những phần mềm, website, trò chơi cung cấp cho thị trường. Đây là nghề đang phát triển mạnh ở nước ta và được nhiều bạn trẻ quan tâm. Các công ty phần mềm nghiên cứu, xây dựng, phát triển và cung cấp các phần mềm, các ứng dụng xây dựng website, games v.v… cho thị trường là điểm đến của các lập trình viên.  Chế tạo, lắp ráp và sửa chữa phần cứng: Những người làm trong lĩnh vực này có khả năng chế tạo, sửa chữa hay lắp ráp, lắp đặt các thiết bị, linh kiện của máy tính như ổ cứng, bo mạch, bộ vi xử lý. Các công ty sản xuất, lắp ráp và sửa chữa thiết bị phần cứng đang hứa hẹn một nền công nghiệp hùng mạnh trong tương lai.  Thiết kế giải pháp tích hợp: Công việc này đòi hỏi các chuyên gia phải am hiểu cả phần cứng và phần mềm, có khả năng thiết kế các giải pháp trọn gói cho một công ty, tổ chức về cả phần cứng lẫn phần mềm, dựa trên yêu cầu cụ thể. Họ làm nhiệm vụ tại các công ty cung cấp giải pháp tích hợp hiện đang trên đà phát triển tại Việt Nam.  Quản trị hệ thông và an ninh mạng: Ngày nay, hầu hết các công ty, doanh nghiệp, tổ chức đều có hệ thống máy vi tính kết nối mạng. Người làm công tác quản trị hệ thống và an ninh mạng có nhiệm vụ bảo đảm cho hệ thống vận hành suôn sẻ, giải quyết trục trặc khi hệ thông gặp sự cố, đảm bảo an toàn và bảo mật cho dữ liệu. Trong lĩnh vực này, bạn sẽ làm việc tại các công ty cung cấp giải pháp về mạng và an ninh mạng, các cơ quan, doanh nghiệp v.v…     Phẩm chất và kỹ năng cần thiết để có thể theo ngành công nghệ thông tin:  - Thông minh và có óc sáng tạo - Khả năng làm việc dưới áp lực lớn - Kiên trì, nhẫn nại. - Tính chính xác trong công việc - Ham học hỏi, trau dồi kiến thức - Khả năng làm việc theo nhóm - Trình độ ngoại ngữ (để tiếp cận kho tàng phong phú về CNTT từ các nguồi sách điện tử và Internet) Và quan trọng nhất là niềm đammê với CNT  Một số địa chỉ đào tạo  Nếu bạn muốn theo học ngành CNTT, có rất nhiều địa chỉ để bạn lựa chọn: Khoa Công nghệ thông tin của trường ĐH Bách khoa Hà Nội, trường ĐH Bách khoa TP.HCM, trường ĐH Khoa học tự nhiên Hà Nội và TP.HCM, trường ĐH Công nghệ (ĐHQG Hà Nội) v.v…và rất nhiều trường ĐH, CĐ khác.  Bạn cũng có thể học công nghệ thông tin ở các trung tâm nổi tiếng chuyên đào tạo CNTT như HanoiCTT, SaigonCTT, công ty IPMAC, trung tâm in học Trí Việt (VnPro), trung tâm đào tạo lập trình viên quốc tế Aptech ở Hà Nội và TP.HCM v.v…    .Tin học có khác Công nghệ thông tin?  Đối với ngành CNTT, đã có nhiều bạn đọc gửi e-mail về thắc mắc ngành Tin học và CNTT khác nhau như thế nào, tại sao có trường đào tạo ngành Tin học, có trường đào tạo ngành CNTT? Bằng kỹ sư CNTT và bằng cử nhân CNTT khác nhau ra sao?  TS Quách Tuấn Ngọc đã trả lời cho những thắc mắc này như sau:  Về thuật ngữ, Tin học được dịch từ Informatique (tiếng Pháp) là tên chuyên ngành được phổ biến từ những năm 1970 đến 1990. Tiếng Anh thì vẫn dùng phổ biến là Computer Science.  Khoảng năm 1990, thế giới phổ biến dùng CNTT, dịch từ Information Technology.  Đến năm 2000, thế giới lại dùng là ICT (Information and Communication Technology), cho thấy sự hội tụ giữa Tin học và Viễn thông.  Hiện nay, ở Việt Nam, các trường có nơi gọi là khoa Tin học, có nơi gọi là Khoa CNTT, nhưng về nội hàm thì không khác biệt.  Các trường đại học kỹ thuật hệ 5 năm như ĐHBK thì bằng tốt nghiệp mang tên bằng kỹ sư.  Các trường khác đào tạo hệ 4 năm như ĐH Công nghệ... thì bằng tốt nghiệp gọi là bằng cử nhân.     .Tuy nhiên, để theo đuổi ngành CNTT bạn cũng cần phải biết những khó khăn của ngành này, hãy tham khảo thêm tại chuyên mục này để về những khó khăn đó.'), 
(83, 'Bài viết sau sẽ cung cấp cho bạn thông tin cần thiết để định hướng rõ hơn nghề nghiệp của ngành Công nghệ thông tin.    /uploads/news/2016_01/tu-van-ngay-hoi.jpg tu van ngay hoi  Ban tư vấn UEF giúp các em học sinh làm rõ khúc mắc: Học ngành Công nghệ thông tin ra trường làm gì?    Học ngành Công nghệ thông tin ra trường làm gì? Công nghệ thông tin (IT) ngày càng trở thành lựa chọn của nhiều bạn trẻ nhiệt huyết, yêu thích lĩnh vực công nghệ. Muốn tạo nên sự khác biệt tích cực cho thế giới thì IT là một trong những con đường lựa chọn đúng đắn của bạn bởi IT ngày nay là công cụ quan trọng không thể thiếu trong các lĩnh vực khoa học công nghệ. Cơ hội việc làm của Công nghệ thông tin cho bạn rất nhiều lựa chọn hấp dẫn : - Lập trình viên: người trực tiếp tạo ra các sản phẩm công nghệ như phần mềm, hệ thống thông tin; - Kiểm duyệt chất lượng phần mềm: trực tiếp kiểm tra chất lượng các sản phẩm công nghệ do lập trình viên tạo ra; - Chuyên viên phân tích thiết kế hệ thống, quản lý dữ liệu, quản trị mạng, kỹ thuật phần cứng máy tính; - Chuyên gia quản lý, kinh doanh, điều phối các dự án công nghệ thông tin; - Giảng dạy và nghiên cứu về công nghệ thông tin tại các cơ sở đào tạo… Học ngành Công nghệ thông tin làm việc ở đâu? Tốt nghiệp ngành Công nghệ thông tin bạn có thể làm việc tại: - Các công ty, tập đoàn về công nghệ thông tin;  - Các công ty sản xuất, lắp ráp, sửa chữa trang thiết bị phần cứng; - Các công ty cung cấp giải pháp tích hợp; - Các công ty cung cấp giải pháp về mạng và an ninh mạng; - Bộ phận Quản trị, bộ phận IT tại các công ty, kể cả công ty hoạt động trong lĩnh vực Công nghệ và các lĩnh vực khác như ngân hàng, y tế, giáo dục, giải trí... - Giảng viên các trường đại học, cao đẳng, học viên, trung tâm có đào tạo Công nghệ thông tin. Thống kê của Bộ Thông tin - Truyền thông, đến năm 2020, nhân lực trong lĩnh vực IT mỗi năm tăng 13%. Theo đó, lĩnh vực Công nghệ thông tin ở Việt Nam cần đến 1 triệu lao động hoạt động. Song song đó, một sự ưu ái khác của thị trường lao động đối với ngành này là thực tế các cuộc khủng hoảng kinh tế gần đây đã minh chứng, nhân lực thuộc lĩnh vực công nghệ thông tin là một trong những ngành ít chịu sự tác động nhất. Như vậy, để thành công với những công việc trên đòi hỏi bạn phải lựa chọn cho bản thân một chương trình đào tạo Công nghệ thông tin uy tín ở các trường đại học phù hợp như Đại học Bách khoa Tp.HCM, Đại học Khoa học tự nhiên, Đại học Kinh tế Tài chính Tp.HCM (UEF), Đại học Công nghệ Tp.HCM - HUTECH, Đại học Công nghệ thông tin...  Ngoài kiến thức chuyên môn về IT được đào tạo, sinh viên cũng cần trang bị thêm yếu tố ngoại ngữ, kỹ năng nghề nghiệp, kỹ năng mềm cần thiết. Đáp ứng nhu cầu đó, có thể nói UEF là một trong những trường tiên phong chú trọng khối kiến thức nghề toàn diện. Ngoài ra, sinh viên IT của UEF còn có cơ hội tiếp cận với môi trường kinh doanh thực tế thông qua những buổi kiến tập và thực tập tại các doanh nghiệp, những chia sẻ từ các doanh nhân, chuyên gia hàng đầu trong lĩnh vực công nghệ hay tiếp cận những dự án kinh doanh các bạn tự tiến hành triển khai...Từ đó, sinh viên có cái nhìn toàn diện và sâu rộng về nghề nghiệp mình có dự định theo đuổi, trang bị thêm kiến thức và kinh nghiệm thực tế để tự tin chinh phục đỉnh cao nghề nghiệp. Với những thông tin trong bài viết thì vấn đề học ngành Công nghệ thông tin ra trường làm gì? và làm việc ở đâu? chắc chắn không còn là nỗi lo lắng, băn khoăn của các bạn khi chọn ngành học đấy sáng tạo này.    Quỳnh Anh'), 
(84, 'Đến tham dự buổi lễ có ông Nguyễn Đình Hoàng- Phó Bí thư Đảng ủy khối các cơ quan tỉnh, ông Phan Hồng- Giám đốc Sở GDĐT, đại diện lãnh đạo các trường đại học, cao đẳng, trung cấp chuyên nghiệp trên địa bàn tỉnh, các doanh nghiệp liên kết đào tạo cùng cán bộ, giáo viên và học sinh toàn trường. Mở đầu buổi lễ, ông Phan Hồng đọc thư của Chủ tịch nước Trương Tấn Sang gửi Ngành Giáo dục nhân dịp năm học mới 2015-2016.   /uploads/news/2016_01/tcdl-2.jpg TCDL 2 Ông Võ Văn Chúng- Hiệu trưởng trường TC Đắk Lắk báo cáo kết quả 5 năm xây dựng và phát triển nhà trường  Ông Võ Văn Chúng- Hiệu trưởng trường Trung cấp Đắk Lắk báo cáo kết quả 5 năm xây dựng và phát triển. Trường Trung cấp Đắk Lắk thành lập ngày 3-3-2010 trên cơ sở nâng cấp Trung tâm Ngoại ngữ - Tin học Đắk Lắk. Từ khi thành lập đến nay, nhà trường đã đào tạo 6 khóa, với 1.554 học sinh (HS) thuộc 8 chuyên ngành ở các lĩnh vực: Kế toán, Tài chính - Ngân hàng, Công nghệ Thông tin, Hành chính - Văn thư, Xây dựng dân dụng - Công nghiệp, Xây dựng cầu đường, Quản lý đất đai, Trồng trọt và bảo vệ thực vật.  Với phương châm “Đào tạo gắn với thực tiễn nghề nghiệp”, nhà trường đã liên kết với hơn 40 đơn vị, doanh nghiệp cùng tham gia đào tạo thực hành nghề nghiệp. Nhờ đó chất lượng đào tạo không ngừng nâng cao, với 27,8% HS xếp loại xuất sắc, giỏi; có 72 HS đạt danh hiệu HS trung cấp chuyên nghiệp giỏi cấp trường, 16 HS đạt danh hiệu HS thực hành giỏi cấp tỉnh. Đặc biệt trên 90% HS có việc làm sau tốt nghiệp hoặc học liên thông lên bậc cao hơn. Ngoài ra, nhà trường còn dạy nghề phổ thông cho 6.740 HS trung học cơ sở; đào tạo nghề ngắn hạn cho 6.793 học viên và liên kết đào tạo trình độ trung cấp chuyên nghiệp, cao đẳng, đại học cho 2.414 học sinh, sinh viên.   Với những thành tích trên, 3 năm học nhà trường được công nhận Tập thể lao động xuất sắc, 4 năm học được UBND tỉnh tặng Bằng khen hoàn thành xuất sắc nhiệm vụ năm học; các tổ chức đoàn thể của trường được UBND tỉnh, Trung ương Hội Liên hiệp Thanh niên Việt Nam, Trung ương Hội Sinh viên Việt Nam, Liên đoàn Lao động tỉnh tặng Bằng khen; 1 cá nhân được tặng thưởng Huân chương Lao động hạng Ba và nhiều cán bộ quản lý, giáo viên được tặng Kỷ niệm chương &quot;Vì sự nghiệp Giáo dục&quot;, “Bảo vệ an ninh Tổ quốc”, “Vì thế hệ trẻ”…   /uploads/news/2016_01/tcdl-3.jpg Ông Phan Hồng trao chứng nhận Tập thể Lao động xuất sắc và Bằng khen cho các cá nhân xuất sắc  Phát biểu tại buổi lễ, ông Phan Hồng thay mặt ngành Giáo dục và Đào tạo ghi nhận và biểu dương những thành tích hoạt động của trường Trung cấp Đắk Lắk qua 5 năm xây dựng và phát triển. Trong thời gian tới, trường Trung cấp Đắk Lắk cần tiếp tục quán triệt sâu sắc các Nghị quyết của Đảng, xây dựng tập thể cán bộ, giáo viên, nhân viên có năng lực và tâm huyết với nghề, đổi mới mạnh mẽ công tác quản lý giáo dục, đẩy mạnh công tác nghiên cứu khoa học trong giáo viên và học sinh; tăng cường liên kết với các doanh nghiệp trong việc đào tạo, phát triển chương trình nhằm nâng cao hiệu quả chất lượng tay nghề cho học sinh đáp ứng được yêu cầu của nhà tuyển dụng để đáp ứng lòng tin tưởng, mong mỏi của các cấp bộ Đảng, chính quyền và nhân dân tỉnh Đắk Lắk.  Tại lễ kỷ niệm và khai giảng năm học mới, các đơn vị tài trợ đã trao 15 suất học bổng (mỗi suất trị giá 1 triệu đồng) cho các em học sinh hiếu học. ');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_cat`
--

DROP TABLE IF EXISTS `ctypa_vi_news_cat`;
CREATE TABLE `ctypa_vi_news_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `descriptionhtml` text,
  `image` varchar(255) DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `keywords` text,
  `admins` text,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_cat`
--

INSERT INTO `ctypa_vi_news_cat` VALUES
(8, 0, 'Thời sự Trong nước', '', 'f1', '', '', '', 0, 1, 1, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 'thời sự trong nước', '', 1453360667, 1453360667, '6'), 
(9, 0, 'Tin tức Giáo dục', '', 'f2', '', '', '', 0, 2, 2, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 'tin tức giáo dục', '', 1453360712, 1453361030, '6'), 
(10, 0, 'Tin tức Chuyên ngành', '', 'f3', '', '', '', 0, 3, 3, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 'tin tức chuyên ngành', '', 1453361055, 1453361055, '6'), 
(11, 0, 'Hướng nghiệp', '', 'f4', '', '', '', 0, 4, 4, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 'hướng nghiệp', '', 1453361418, 1453361482, '6'), 
(12, 0, 'Tài liệu Học tập', '', 'f5', '', '', '', 0, 5, 5, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 'tài liệu học tập', '', 1453363001, 1453363001, '6'), 
(13, 0, 'Hướng dẫn Thực hành', '', 'f6', '', '', '', 0, 6, 6, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 'hướng dẫn thực hành', '', 1453363033, 1453363033, '6');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_config_post`
--

DROP TABLE IF EXISTS `ctypa_vi_news_config_post`;
CREATE TABLE `ctypa_vi_news_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_config_post`
--

INSERT INTO `ctypa_vi_news_config_post` VALUES
(5, 0, 0, 0, 0), 
(4, 0, 0, 0, 0), 
(1, 0, 0, 0, 0), 
(2, 0, 0, 0, 0), 
(3, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_logs`
--

DROP TABLE IF EXISTS `ctypa_vi_news_logs`;
CREATE TABLE `ctypa_vi_news_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_rows`
--

DROP TABLE IF EXISTS `ctypa_vi_news_rows`;
CREATE TABLE `ctypa_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=85  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_rows`
--

INSERT INTO `ctypa_vi_news_rows` VALUES
(80, 9, '9', 0, 1, '', 3, 1453363738, 1453363784, 1, 1453363500, 0, 2, 'Bộ giáo dục công bố một số thay đổi trong mùa tuyển sinh 2016', 'bo-giao-duc-cong-bo-mot-so-thay-doi-trong-mua-tuyen-sinh-2016', 'Các thông tin này được ông Bùi Văn Ga, Thứ trưởng Bộ GD&ĐT trao đổi trong buổi họp báo định kỳ của Bộ GD&ĐT chiều nay (20/10).', '2016_01/bui.jpg', 'Ông Bùi Văn Ga - Thứ trưởng Bộ GD&amp;ĐT. Ảnh của Xuân Trung', 1, 1, '4', 1, 17, 0, 5, 1), 
(81, 10, '10', 0, 1, '', 4, 1453364095, 1453364095, 1, 1453363920, 0, 2, 'Địa điểm nào cho trải nghiệm 4G miễn phí?', 'dia-diem-nao-cho-trai-nghiem-4g-mien-phi', 'Trong ngày 18/1, nhà mạng VNPT Vinaphone tổ chức 6 điểm trải nghiệm dịch vụ ứng dụng trên nền tảng công nghệ mới 4G. Trong đó TP. Hồ Chí Minh có 2 địa điểm, huyện đảo Phú Quốc (Kiên Giang) có 4 địa điểm.', '2016_01/21-11-13.jpg', '', 1, 1, '4', 1, 21, 0, 0, 0), 
(82, 11, '11', 0, 1, '', 0, 1453365548, 1453365548, 1, 1453365420, 0, 2, 'Chức năng và vai trò Ngành công nghệ thông tin', 'chuc-nang-va-vai-tro-nganh-cong-nghe-thong-tin', 'CNTT là ngành sử dụng máy tính và phần mềm máy tính để chuyển đổi, lưu trữ, bảo vệ, xử lý, truyền, và thu thập thông tin. Người làm việc trong ngành này thường được gọi là dân CNTT (IT specialist) hoặc cố vấn quy trình doanh nghiệp (Business Process Consultant)', '2016_01/a998.jpg', 'Làm việc với máy vi tính', 1, 1, '4', 1, 15, 0, 0, 0), 
(83, 11, '11', 0, 1, '', 0, 1453365722, 1453365722, 1, 1453365540, 0, 2, 'Học ngành Công nghệ thông tin ra trường làm gì?', 'hoc-nganh-cong-nghe-thong-tin-ra-truong-lam-gi', 'Theo quy hoạch phát triển kinh tế giai đoạn đến 2020 thì Công nghệ thông tin là một trong những ngành mũi nhọn. Trong bối cảnh đó, ngày càng nhiều công ty công nghệ trong và ngoài nước mở rộng quy mô hoạt động tại Việt Nam và hướng ra khu vực, thế giới. Vì vậy, nhân sự ngành công nghệ thông tin hứa hẹn sẽ trở thành nguồn nhân lực then chốt để phát triển lĩnh vực công nghệ trong tương lai.  Những ai theo đuổi ngành Công nghệ thông tin cần tìm hiểu rõ học ngành Công nghệ thông tin ra trường làm gì? và làm ở đâu?...khi chọn ngành này làm hành trang nghề nghiệp.', '2016_01/tu-van-ngay-hoi.jpg', '', 1, 1, '4', 1, 23, 0, 0, 0), 
(84, 9, '9', 0, 1, '', 5, 1453414418, 1453414418, 1, 1453414140, 0, 2, 'Trường Trung cấp Đắk Lắk kỉ niệm 5 năm thành lập và khai giảng năm học 2015-2016', 'truong-trung-cap-dak-lak-ki-niem-5-nam-thanh-lap-va-khai-giang-nam-hoc-2015-2016', 'Sáng ngày 19 tháng 12 năm 2015, Trường Trung cấp Đắk Lắk tổ chức kỉ niệm 5 năm thành lập trường ( 2010-2015) và khai giảng năm học mới 2015-2016', '2016_01/tcdl-1.jpg', 'Ông Phan Hồng- Giám đốc Sở GDĐT đánh trống khai giảng năm học 2015-2016', 1, 1, '4', 1, 23, 0, 10, 2), 
(79, 8, '8', 0, 1, '', 2, 1453363422, 1453363449, 1, 1453363080, 0, 2, 'Đại hội Đảng lần thứ XII&#x3A; Chiều 23&#x002F;1 sẽ nghe báo cáo nhân sự', 'dai-hoi-dang-lan-thu-xii-chieu-23-1-se-nghe-bao-cao-nhan-su', 'Ngày 23/1, Đại hội làm việc tại Hội trường cả ngày. Chiều cùng ngày, Đại hội nghe báo cáo của Ban Chấp hành Trung ương khóa XI về công tác nhân sự Ban Chấp hành Trung ương khóa XII.', '2016_01/dai-hoi-dang-lan-thu-xii-chieu-231-se-nghe-bao-cao-nhan-su.jpg', 'Toàn cảnh phiên khai mạc Đại hội sáng 21&#x002F;1.', 1, 1, '4', 1, 20, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_sources`
--

DROP TABLE IF EXISTS `ctypa_vi_news_sources`;
CREATE TABLE `ctypa_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_sources`
--

INSERT INTO `ctypa_vi_news_sources` VALUES
(1, 'vnexpress.net', 'http://vnexpress.net', '', 1, 1430433433, 1430433433), 
(2, 'dantri.com.vn', 'http://dantri.com.vn', '', 2, 1430433742, 1430433742), 
(3, 'giaoduc.net.vn', 'http://giaoduc.net.vn', '', 3, 1453363738, 1453363738), 
(4, 'vnreview.vn', '', '', 4, 1453364095, 1453364095), 
(5, 'daklak.edu.vn', 'http://daklak.edu.vn', '', 5, 1453414418, 1453414418);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_tags`
--

DROP TABLE IF EXISTS `ctypa_vi_news_tags`;
CREATE TABLE `ctypa_vi_news_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` text,
  `keywords` varchar(255) DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=1986  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_tags`
--

INSERT INTO `ctypa_vi_news_tags` VALUES
(1, 0, 'sáng-ngày', '', '', 'sáng ngày'), 
(2, 0, 'tập-trung', '', '', 'tập trung'), 
(3, 0, 'di-tích', '', '', 'di tích'), 
(4, 0, 'lãnh-đạo', '', '', 'lãnh đạo'), 
(5, 0, 'du-khách', '', '', 'du khách'), 
(6, 0, 'đông-đúc', '', '', 'đông đúc'), 
(7, 0, 'trở-lại', '', '', 'trở lại'), 
(8, 0, 'hiện-tượng', '', '', 'hiện tượng'), 
(9, 0, 'xô-đẩy', '', '', 'xô đẩy'), 
(10, 0, 'giẫm-đạp', '', '', 'giẫm đạp'), 
(11, 0, 'quỳnh-trang', '', '', 'quỳnh trang'), 
(12, 0, 'tổ-chức', '', '', 'tổ chức'), 
(13, 0, 'hùng-vương', '', '', 'hùng vương'), 
(14, 0, 'tắc-nghẽn', '', '', 'tắc nghẽn'), 
(15, 0, 'lực-lượng', '', '', 'lực lượng'), 
(16, 0, 'an-ninh', '', '', 'an ninh'), 
(17, 0, 'liên-tục', '', '', 'liên tục'), 
(18, 0, 'nhắc-nhở', '', '', 'nhắc nhở'), 
(19, 0, 'ý-thức', '', '', 'ý thức'), 
(20, 0, 'như-thế', '', '', 'như thế'), 
(21, 0, 'gọi-là', '', '', 'gọi là'), 
(22, 0, 'một-chút', '', '', 'một chút'), 
(23, 0, 'văn-minh', '', '', 'văn minh'), 
(24, 0, 'đàn-ông', '', '', 'đàn ông'), 
(25, 0, 'mồ-hôi', '', '', 'mồ hôi'), 
(26, 0, 'tươi-cười', '', '', 'tươi cười'), 
(27, 0, 'vân-hà', '', '', 'vân hà'), 
(28, 0, 'cho-biết', '', '', 'cho biết'), 
(29, 0, 'gia-đình', '', '', 'gia đình'), 
(30, 0, 'thành-viên', '', '', 'thành viên'), 
(31, 0, 'bình-an', '', '', 'bình an'), 
(32, 0, 'may-mắn', '', '', 'may mắn'), 
(33, 0, 'quyết-định', '', '', 'quyết định'), 
(34, 0, 'tranh-thủ', '', '', 'tranh thủ'), 
(35, 0, 'người-nhà', '', '', 'người nhà'), 
(36, 0, 'hà-nội', '', '', 'hà nội'), 
(37, 0, 'anh-em', '', '', 'anh em'), 
(38, 0, 'ban-đêm', '', '', 'ban đêm'), 
(39, 0, 'đảm-bảo', '', '', 'đảm bảo'), 
(40, 0, 'mát-mẻ', '', '', 'mát mẻ'), 
(41, 0, 'hy-vọng', '', '', 'hy vọng'), 
(42, 0, 'thạch-thất', '', '', 'thạch thất'), 
(43, 0, 'hôm-qua', '', '', 'hôm qua'), 
(44, 0, 'nhà-trọ', '', '', 'nhà trọ'), 
(45, 0, 'việt-trì', '', '', 'việt trì'), 
(46, 0, 'linh-thiêng', '', '', 'linh thiêng'), 
(47, 0, 'gần-gũi', '', '', 'gần gũi'), 
(48, 0, 'tự-hào', '', '', 'tự hào'), 
(49, 0, 'quê-hương', '', '', 'quê hương'), 
(50, 0, 'chủ-tịch', '', '', 'chủ tịch'), 
(51, 0, 'thành-kính', '', '', 'thành kính'), 
(52, 0, 'tuy-nhiên', '', '', 'tuy nhiên'), 
(53, 0, 'hào-hứng', '', '', 'hào hứng'), 
(54, 0, 'trong-lúc', '', '', 'trong lúc'), 
(55, 0, 'trung-tâm', '', '', 'trung tâm'), 
(56, 0, 'hỗ-trợ', '', '', 'hỗ trợ'), 
(57, 0, 'liên-lạc', '', '', 'liên lạc'), 
(58, 0, 'trường-hợp', '', '', 'trường hợp'), 
(59, 0, 'khai-báo', '', '', 'khai báo'), 
(60, 0, 'hàng-không', '', '', 'hàng không'), 
(61, 0, 'thời-tiết', '', '', 'thời tiết'), 
(62, 0, 'kéo-dài', '', '', 'kéo dài'), 
(63, 0, 'khu-vực', '', '', 'khu vực'), 
(64, 0, 'quốc-tế', '', '', 'quốc tế'), 
(65, 0, 'tân-sơn', '', '', 'tân sơn'), 
(66, 0, 'không-thể', '', '', 'không thể'), 
(67, 0, 'hạ-cánh', '', '', 'hạ cánh'), 
(68, 0, 'cần-thơ', '', '', 'cần thơ'), 
(69, 0, 'cam-ranh', '', '', 'cam ranh'), 
(70, 0, 'thay-đổi', '', '', 'thay đổi'), 
(71, 0, 'thực-hiện', '', '', 'thực hiện'), 
(72, 0, 'quy-trình', '', '', 'quy trình'), 
(73, 0, 'bảo-đảm', '', '', 'bảo đảm'), 
(74, 0, 'an-toàn', '', '', 'an toàn'), 
(75, 0, 'tuyệt-đối', '', '', 'tuyệt đối'), 
(76, 0, 'tất-cả', '', '', 'tất cả'), 
(77, 0, 'sân-bay', '', '', 'sân bay'), 
(78, 0, 'kế-hoạch', '', '', 'kế hoạch'), 
(79, 0, 'hành-khách', '', '', 'hành khách'), 
(80, 0, 'tỏ-ra', '', '', 'tỏ ra'), 
(81, 0, 'lo-lắng', '', '', 'lo lắng'), 
(82, 0, 'khi-không', '', '', 'khi không'), 
(83, 0, 'dự-định', '', '', 'dự định'), 
(84, 0, 'tân-bình', '', '', 'tân bình'), 
(85, 0, 'sấm-sét', '', '', 'sấm sét'), 
(86, 0, 'chớp-nhoáng', '', '', 'chớp nhoáng'), 
(87, 0, 'bầu-trời', '', '', 'bầu trời'), 
(88, 0, 'tuyến-đường', '', '', 'tuyến đường'), 
(89, 0, 'khí-tượng', '', '', 'khí tượng'), 
(90, 0, 'thủy-văn', '', '', 'thủy văn'), 
(91, 0, 'nam-bộ', '', '', 'nam bộ'), 
(92, 0, 'thời-điểm', '', '', 'thời điểm'), 
(93, 0, 'có-thể', '', '', 'có thể'), 
(94, 0, 'khánh-thành', '', '', 'khánh thành'), 
(95, 0, 'dự-án', '', '', 'dự án'), 
(96, 0, 'giao-thông', '', '', 'giao thông'), 
(97, 0, 'vận-tải', '', '', 'vận tải'), 
(98, 0, 'phối-hợp', '', '', 'phối hợp'), 
(99, 0, 'hoạt-động', '', '', 'hoạt động'), 
(100, 0, 'cải-tạo', '', '', 'cải tạo'), 
(101, 0, 'quốc-lộ', '', '', 'quốc lộ'), 
(102, 0, 'thi-công', '', '', 'thi công'), 
(103, 0, 'ngã-ba', '', '', 'ngã ba'), 
(104, 0, 'thống-nhất', '', '', 'thống nhất'), 
(105, 0, 'bảo-lộc', '', '', 'bảo lộc'), 
(106, 0, 'sở-hữu', '', '', 'sở hữu'), 
(107, 0, 'tín-dụng', '', '', 'tín dụng'), 
(108, 0, 'phát-biểu', '', '', 'phát biểu'), 
(109, 0, 'thứ-trưởng', '', '', 'thứ trưởng'), 
(110, 0, 'quan-trọng', '', '', 'quan trọng'), 
(111, 0, 'ý-nghĩa', '', '', 'ý nghĩa'), 
(112, 0, 'huyết-mạch', '', '', 'huyết mạch'), 
(113, 0, 'kinh-tế', '', '', 'kinh tế'), 
(114, 0, 'trọng-điểm', '', '', 'trọng điểm'), 
(115, 0, 'thời-gian', '', '', 'thời gian'), 
(116, 0, 'thúc-đẩy', '', '', 'thúc đẩy'), 
(117, 0, 'phát-triển', '', '', 'phát triển'), 
(118, 0, 'văn-hóa', '', '', 'văn hóa'), 
(119, 0, 'du-lịch', '', '', 'du lịch'), 
(120, 0, 'tai-nạn', '', '', 'tai nạn'), 
(121, 0, 'quốc-phòng', '', '', 'quốc phòng'), 
(122, 0, 'rút-ngắn', '', '', 'rút ngắn'), 
(123, 0, 'học-sinh', '', '', 'học sinh'), 
(124, 0, 'mầm-non', '', '', 'mầm non'), 
(125, 0, 'sao-mai', '', '', 'sao mai'), 
(126, 0, 'nhi-đồng', '', '', 'nhi đồng'), 
(127, 0, 'tình-trạng', '', '', 'tình trạng'), 
(128, 0, 'chăm-sóc', '', '', 'chăm sóc'), 
(129, 0, 'cấp-cứu', '', '', 'cấp cứu'), 
(130, 0, 'cửu-long', '', '', 'cửu long'), 
(131, 0, 'phát-sốt', '', '', 'phát sốt'), 
(132, 0, 'mới-hay', '', '', 'mới hay'), 
(133, 0, 'tương-tự', '', '', 'tương tự'), 
(134, 0, 'anh-đào', '', '', 'anh đào'), 
(135, 0, 'rối-loạn', '', '', 'rối loạn'), 
(136, 0, 'bánh-mì', '', '', 'bánh mì'), 
(137, 0, 'bác-sĩ', '', '', 'bác sĩ'), 
(138, 0, 'ngộ-độc', '', '', 'ngộ độc'), 
(139, 0, 'thạc-sĩ', '', '', 'thạc sĩ'), 
(140, 0, 'xử-lý', '', '', 'xử lý'), 
(141, 0, 'triệu-chứng', '', '', 'triệu chứng'), 
(142, 0, 'thực-phẩm', '', '', 'thực phẩm'), 
(143, 0, 'tiếp-tục', '', '', 'tiếp tục'), 
(144, 0, 'theo-dõi', '', '', 'theo dõi'), 
(145, 0, 'nhiễm-trùng', '', '', 'nhiễm trùng'), 
(146, 0, 'nhận-định', '', '', 'nhận định'), 
(147, 0, 'cơ-quan', '', '', 'cơ quan'), 
(148, 0, 'vệ-sinh', '', '', 'vệ sinh'), 
(149, 0, 'y-tế', '', '', 'y tế'), 
(150, 0, 'nguyên-nhân', '', '', 'nguyên nhân'), 
(151, 0, 'công-tác', '', '', 'công tác'), 
(152, 0, 'mắc-kẹt', '', '', 'mắc kẹt'), 
(153, 0, 'động-đất', '', '', 'động đất'), 
(154, 0, 'học-tập', '', '', 'học tập'), 
(155, 0, 'kinh-nghiệm', '', '', 'kinh nghiệm'), 
(156, 0, 'nâng-cao', '', '', 'nâng cao'), 
(157, 0, 'kỹ-năng', '', '', 'kỹ năng'), 
(158, 0, 'phòng-ngừa', '', '', 'phòng ngừa'), 
(159, 0, 'ứng-phó', '', '', 'ứng phó'), 
(160, 0, 'thảm-họa', '', '', 'thảm họa'), 
(161, 0, 'rung-chuyển', '', '', 'rung chuyển'), 
(162, 0, 'ngày-trước', '', '', 'ngày trước'), 
(163, 0, 'rõ-ràng', '', '', 'rõ ràng'), 
(164, 0, 'mệt-mỏi', '', '', 'mệt mỏi'), 
(165, 0, 'quan-sát', '', '', 'quan sát'), 
(166, 0, 'trở-thành', '', '', 'trở thành'), 
(167, 0, 'diễn-viên', '', '', 'diễn viên'), 
(168, 0, 'thực-hành', '', '', 'thực hành'), 
(169, 0, 'khách-sạn', '', '', 'khách sạn'), 
(170, 0, 'sợ-hãi', '', '', 'sợ hãi'), 
(171, 0, 'la-hét', '', '', 'la hét'), 
(172, 0, 'cảm-giác', '', '', 'cảm giác'), 
(173, 0, 'rung-rung', '', '', 'rung rung'), 
(174, 0, 'căng-thẳng', '', '', 'căng thẳng'), 
(175, 0, 'mất-mạng', '', '', 'mất mạng'), 
(176, 0, 'thông-báo', '', '', 'thông báo'), 
(177, 0, 'cố-gắng', '', '', 'cố gắng'), 
(178, 0, 'quê-nhà', '', '', 'quê nhà'), 
(179, 0, 'tình-hình', '', '', 'tình hình'), 
(180, 0, 'chập-chờn', '', '', 'chập chờn'), 
(181, 0, 'trao-đổi', '', '', 'trao đổi'), 
(182, 0, 'chuyên-gia', '', '', 'chuyên gia'), 
(183, 0, 'lĩnh-vực', '', '', 'lĩnh vực'), 
(184, 0, 'lịch-trình', '', '', 'lịch trình'), 
(185, 0, 'tìm-kiếm', '', '', 'tìm kiếm'), 
(186, 0, 'máy-bay', '', '', 'máy bay'), 
(187, 0, 'không-dám', '', '', 'không dám'), 
(188, 0, 'cắm-trại', '', '', 'cắm trại'), 
(189, 0, 'khổng-lồ', '', '', 'khổng lồ'), 
(190, 0, 'nhân-viên', '', '', 'nhân viên'), 
(191, 0, 'phục-vụ', '', '', 'phục vụ'), 
(192, 0, 'toàn-bộ', '', '', 'toàn bộ'), 
(193, 0, 'thông-tin', '', '', 'thông tin'), 
(194, 0, 'lo-liệu', '', '', 'lo liệu'), 
(195, 0, 'giúp-đỡ', '', '', 'giúp đỡ'), 
(196, 0, 'hỗn-loạn', '', '', 'hỗn loạn'), 
(197, 0, 'cửa-hàng', '', '', 'cửa hàng'), 
(198, 0, 'đồ-ăn', '', '', 'đồ ăn'), 
(199, 0, 'xếp-hàng', '', '', 'xếp hàng'), 
(200, 0, 'ăn-uống', '', '', 'ăn uống'), 
(201, 0, 'vấn-đề', '', '', 'vấn đề'), 
(202, 0, 'nan-giải', '', '', 'nan giải'), 
(203, 0, 'trước-khi', '', '', 'trước khi'), 
(204, 0, 'quảng-châu', '', '', 'quảng châu'), 
(205, 0, 'trở-về', '', '', 'trở về'), 
(206, 0, 'trở-lên', '', '', 'trở lên'), 
(207, 0, 'sử-dụng', '', '', 'sử dụng'), 
(208, 0, 'nội-dung', '', '', 'nội dung'), 
(209, 0, 'đi-bộ', '', '', 'đi bộ'), 
(210, 0, 'kiệt-sức', '', '', 'kiệt sức'), 
(211, 0, 'nguy-hiểm', '', '', 'nguy hiểm'), 
(212, 0, 'trầm-trọng', '', '', 'trầm trọng'), 
(213, 0, 'lãnh-sự', '', '', 'lãnh sự'), 
(214, 0, 'bảo-hiểm', '', '', 'bảo hiểm'), 
(215, 0, 'kêu-cứu', '', '', 'kêu cứu'), 
(216, 0, 'hiện-tại', '', '', 'hiện tại'), 
(217, 0, 'tạm-thời', '', '', 'tạm thời'), 
(218, 0, 'di-chuyển', '', '', 'di chuyển'), 
(219, 0, 'xác-định', '', '', 'xác định'), 
(220, 0, 'tọa-độ', '', '', 'tọa độ'), 
(221, 0, 'ổn-định', '', '', 'ổn định'), 
(222, 0, 'minh-châu', '', '', 'minh châu'), 
(223, 0, 'phụ-trách', '', '', 'phụ trách'), 
(224, 0, 'của-ông', '', '', 'của ông'), 
(225, 0, 'phú-cường', '', '', 'phú cường'), 
(226, 0, 'lặng-lẽ', '', '', 'lặng lẽ'), 
(227, 0, 'bàn-thờ', '', '', 'bàn thờ'), 
(228, 0, 'gia-tộc', '', '', 'gia tộc'), 
(229, 0, 'phảng-phất', '', '', 'phảng phất'), 
(230, 0, 'sơn-trà', '', '', 'sơn trà'), 
(231, 0, 'bí-thư', '', '', 'bí thư'), 
(232, 0, 'tử-trận', '', '', 'tử trận'), 
(233, 0, 'nhà-giáo', '', '', 'nhà giáo'), 
(234, 0, 'về-hưu', '', '', 'về hưu'), 
(235, 0, 'phong-độ', '', '', 'phong độ'), 
(236, 0, 'minh-mẫn', '', '', 'minh mẫn'), 
(237, 0, 'đối-diện', '', '', 'đối diện'), 
(238, 0, 'câu-chuyện', '', '', 'câu chuyện'), 
(239, 0, 'chiến-đấu', '', '', 'chiến đấu'), 
(240, 0, 'nhắc-lại', '', '', 'nhắc lại'), 
(241, 0, 'hòa-hợp', '', '', 'hòa hợp'), 
(242, 0, 'dân-tộc', '', '', 'dân tộc'), 
(243, 0, 'trước-hết', '', '', 'trước hết'), 
(244, 0, 'hòa-giải', '', '', 'hòa giải'), 
(245, 0, 'tức-là', '', '', 'tức là'), 
(246, 0, 'giải-thích', '', '', 'giải thích'), 
(247, 0, 'thắc-mắc', '', '', 'thắc mắc'), 
(248, 0, 'trí-nhớ', '', '', 'trí nhớ'), 
(249, 0, 'chế-độ', '', '', 'chế độ'), 
(250, 0, 'cộng-hòa', '', '', 'cộng hòa'), 
(251, 0, 'cách-mạng', '', '', 'cách mạng'), 
(252, 0, 'bắt-giam', '', '', 'bắt giam'), 
(253, 0, 'lý-tưởng', '', '', 'lý tưởng'), 
(254, 0, 'trưởng-thành', '', '', 'trưởng thành'), 
(255, 0, 'phê-phán', '', '', 'phê phán'), 
(256, 0, 'trong-khi', '', '', 'trong khi'), 
(257, 0, 'tham-gia', '', '', 'tham gia'), 
(258, 0, 'quân-đội', '', '', 'quân đội'), 
(259, 0, 'thiếu-tá', '', '', 'thiếu tá'), 
(260, 0, 'hải-quân', '', '', 'hải quân'), 
(261, 0, 'thượng-sĩ', '', '', 'thượng sĩ'), 
(262, 0, 'chủ-quyền', '', '', 'chủ quyền'), 
(263, 0, 'em-út', '', '', 'em út'), 
(264, 0, 'phong-trào', '', '', 'phong trào'), 
(265, 0, 'sinh-viên', '', '', 'sinh viên'), 
(266, 0, 'trầm-ngâm', '', '', 'trầm ngâm'), 
(267, 0, 'ngày-tết', '', '', 'ngày tết'), 
(268, 0, 'tụ-họp', '', '', 'tụ họp'), 
(269, 0, 'nhiệm-vụ', '', '', 'nhiệm vụ'), 
(270, 0, 'nhà-tôi', '', '', 'nhà tôi'), 
(271, 0, 'như-vậy', '', '', 'như vậy'), 
(272, 0, 'chấp-nhận', '', '', 'chấp nhận'), 
(273, 0, 'quần-đảo', '', '', 'quần đảo'), 
(274, 0, 'trần-bình-trọng', '', '', 'trần bình trọng'), 
(275, 0, 'thi-thể', '', '', 'thi thể'), 
(276, 0, 'ngày-sau', '', '', 'ngày sau'), 
(277, 0, 'ngoại-xâm', '', '', 'ngoại xâm'), 
(278, 0, 'tin-dữ', '', '', 'tin dữ'), 
(279, 0, 'tuần-lễ', '', '', 'tuần lễ'), 
(280, 0, 'qua-đời', '', '', 'qua đời'), 
(281, 0, 'tử-sĩ', '', '', 'tử sĩ'), 
(282, 0, 'đoàn-tụ', '', '', 'đoàn tụ'), 
(283, 0, 'kỳ-thị', '', '', 'kỳ thị'), 
(284, 0, 'tuy-vậy', '', '', 'tuy vậy'), 
(285, 0, 'rắc-rối', '', '', 'rắc rối'), 
(286, 0, 'tài-sản', '', '', 'tài sản'), 
(287, 0, 'thu-hồi', '', '', 'thu hồi'), 
(288, 0, 'thời-hạn', '', '', 'thời hạn'), 
(289, 0, 'định-cư', '', '', 'định cư'), 
(290, 0, 'thường-xuyên', '', '', 'thường xuyên'), 
(291, 0, 'lập-nghiệp', '', '', 'lập nghiệp'), 
(292, 0, 'thời-bình', '', '', 'thời bình'), 
(293, 0, 'bình-yên', '', '', 'bình yên'), 
(294, 0, 'bao-giờ', '', '', 'bao giờ'), 
(295, 0, 'chiến-tranh', '', '', 'chiến tranh'), 
(296, 0, 'đổ-máu', '', '', 'đổ máu'), 
(297, 0, 'tâm-sự', '', '', 'tâm sự'), 
(298, 0, 'quá-khứ', '', '', 'quá khứ'), 
(299, 0, 'xây-dựng', '', '', 'xây dựng'), 
(300, 0, 'công-nhân', '', '', 'công nhân'), 
(301, 0, 'bị-thương', '', '', 'bị thương'), 
(302, 0, 'sự-việc', '', '', 'sự việc'), 
(303, 0, 'nhân-công', '', '', 'nhân công'), 
(304, 0, 'bạch-đàn', '', '', 'bạch đàn'), 
(305, 0, 'quảng-hợp', '', '', 'quảng hợp'), 
(306, 0, 'quảng-trạch', '', '', 'quảng trạch'), 
(307, 0, 'tỉnh-dậy', '', '', 'tỉnh dậy'), 
(308, 0, 'sức-ép', '', '', 'sức ép'), 
(309, 0, 'tử-vong', '', '', 'tử vong'), 
(310, 0, 'tại-chỗ', '', '', 'tại chỗ'), 
(311, 0, 'quá-trình', '', '', 'quá trình'), 
(312, 0, 'phát-quang', '', '', 'phát quang'), 
(313, 0, 'an-nhơn', '', '', 'an nhơn'), 
(314, 0, 'thượng-úy', '', '', 'thượng úy'), 
(315, 0, 'đường-bộ', '', '', 'đường bộ'), 
(316, 0, 'công-an', '', '', 'công an'), 
(317, 0, 'tuần-tra', '', '', 'tuần tra'), 
(318, 0, 'kiểm-soát', '', '', 'kiểm soát'), 
(319, 0, 'bình-tân', '', '', 'bình tân'), 
(320, 0, 'an-lạc', '', '', 'an lạc'), 
(321, 0, 'bình-thuận', '', '', 'bình thuận'), 
(322, 0, 'tây-ninh', '', '', 'tây ninh'), 
(323, 0, 'phong-tỏa', '', '', 'phong tỏa'), 
(324, 0, 'khám-nghiệm', '', '', 'khám nghiệm'), 
(325, 0, 'tiến-hành', '', '', 'tiến hành'), 
(326, 0, 'nồng-độ', '', '', 'nồng độ'), 
(327, 0, 'tài-xế', '', '', 'tài xế'), 
(328, 0, 'giải-quyết', '', '', 'giải quyết'), 
(329, 0, 'kim-cương', '', '', 'kim cương'), 
(330, 0, 'cảnh-tượng', '', '', 'cảnh tượng'), 
(331, 0, 'kinh-hoàng', '', '', 'kinh hoàng'), 
(332, 0, 'thấp-thỏm', '', '', 'thấp thỏm'), 
(333, 0, 'chuẩn-bị', '', '', 'chuẩn bị'), 
(334, 0, 'quây-quần', '', '', 'quây quần'), 
(335, 0, 'nhà-hàng', '', '', 'nhà hàng'), 
(336, 0, 'số-nhân', '', '', 'số nhân'), 
(337, 0, 'ban-đầu', '', '', 'ban đầu'), 
(338, 0, 'thường-ngày', '', '', 'thường ngày'), 
(339, 0, 'bắt-đầu', '', '', 'bắt đầu'), 
(340, 0, 'đồ-đạc', '', '', 'đồ đạc'), 
(341, 0, 'nháo-nhào', '', '', 'nháo nhào'), 
(342, 0, 'lần-lượt', '', '', 'lần lượt'), 
(343, 0, 'hàng-loạt', '', '', 'hàng loạt'), 
(344, 0, 'nghiêng-ngả', '', '', 'nghiêng ngả'), 
(345, 0, 'quay-cuồng', '', '', 'quay cuồng'), 
(346, 0, 'đứng-vững', '', '', 'đứng vững'), 
(347, 0, 'sau-đó', '', '', 'sau đó'), 
(348, 0, 'hôm-sau', '', '', 'hôm sau'), 
(349, 0, 'chăn-gối', '', '', 'chăn gối'), 
(350, 0, 'ảnh-hưởng', '', '', 'ảnh hưởng'), 
(351, 0, 'hỏi-thăm', '', '', 'hỏi thăm'), 
(352, 0, 'làm-việc', '', '', 'làm việc'), 
(353, 0, 'thông-qua', '', '', 'thông qua'), 
(354, 0, 'kêu-gọi', '', '', 'kêu gọi'), 
(355, 0, 'chứng-kiến', '', '', 'chứng kiến'), 
(356, 0, 'sắp-xếp', '', '', 'sắp xếp'), 
(357, 0, 'quá-cảnh', '', '', 'quá cảnh'), 
(358, 0, 'la-liệt', '', '', 'la liệt'), 
(359, 0, 'nỗ-lực', '', '', 'nỗ lực'), 
(360, 0, 'sứ-quán', '', '', 'sứ quán'), 
(361, 0, 'xe-buýt', '', '', 'xe buýt'), 
(362, 0, 'nạn-nhân', '', '', 'nạn nhân'), 
(363, 0, 'liên-hợp', '', '', 'liên hợp'), 
(364, 0, 'tương-đương', '', '', 'tương đương'), 
(365, 0, 'xác-nhận', '', '', 'xác nhận'), 
(366, 0, 'thiệt-mạng', '', '', 'thiệt mạng'), 
(367, 0, 'tuyên-bố', '', '', 'tuyên bố'), 
(368, 0, 'quốc-tang', '', '', 'quốc tang'), 
(369, 0, 'tưởng-nhớ', '', '', 'tưởng nhớ'), 
(370, 0, 'anh-hùng', '', '', 'anh hùng'), 
(371, 0, 'liệt-sĩ', '', '', 'liệt sĩ'), 
(372, 0, 'kỷ-niệm', '', '', 'kỷ niệm'), 
(373, 0, 'lao-động', '', '', 'lao động'), 
(374, 0, 'nhà-nước', '', '', 'nhà nước'), 
(375, 0, 'tổng-bí-thư', '', '', 'tổng bí thư'), 
(376, 0, 'hương-hoa', '', '', 'hương hoa'), 
(377, 0, 'nghĩa-trang', '', '', 'nghĩa trang'), 
(378, 0, 'thành-phố', '', '', 'thành phố'), 
(379, 0, 'không-khí', '', '', 'không khí'), 
(380, 0, 'trang-nghiêm', '', '', 'trang nghiêm'), 
(381, 0, 'mặc-niệm', '', '', 'mặc niệm'), 
(382, 0, 'hy-sinh', '', '', 'hy sinh'), 
(383, 0, 'độc-lập', '', '', 'độc lập'), 
(384, 0, 'tự-do', '', '', 'tự do'), 
(385, 0, 'tổ-quốc', '', '', 'tổ quốc'), 
(386, 0, 'vòng-hoa', '', '', 'vòng hoa'), 
(387, 0, 'bày-tỏ', '', '', 'bày tỏ'), 
(388, 0, 'lòng-thành', '', '', 'lòng thành'), 
(389, 0, 'trân-trọng', '', '', 'trân trọng'), 
(390, 0, 'kháng-chiến', '', '', 'kháng chiến'), 
(391, 0, 'bảo-vệ', '', '', 'bảo vệ'), 
(392, 0, 'biên-giới', '', '', 'biên giới'), 
(393, 0, 'tây-nam', '', '', 'tây nam'), 
(394, 0, 'đặt-tên', '', '', 'đặt tên'), 
(395, 0, 'đường-trường', '', '', 'đường trường'), 
(396, 0, 'chí-minh', '', '', 'chí minh'), 
(397, 0, 'tham-dự', '', '', 'tham dự'), 
(398, 0, 'mít-tinh', '', '', 'mít tinh'), 
(399, 0, 'trọng-thể', '', '', 'trọng thể'), 
(400, 0, 'lễ-đài', '', '', 'lễ đài'), 
(401, 0, 'ngã-tư', '', '', 'ngã tư'), 
(402, 0, 'quốc-gia', '', '', 'quốc gia'), 
(403, 0, 'phi-công', '', '', 'phi công'), 
(404, 0, 'văn-nghĩa', '', '', 'văn nghĩa'), 
(405, 0, 'trung-tá', '', '', 'trung tá'), 
(406, 0, 'phát-hiện', '', '', 'phát hiện'), 
(407, 0, 'số-hiệu', '', '', 'số hiệu'), 
(408, 0, 'ủy-ban', '', '', 'ủy ban'), 
(409, 0, 'túc-trực', '', '', 'túc trực'), 
(410, 0, 'trung-tướng', '', '', 'trung tướng'), 
(411, 0, 'tổng-tham-mưu', '', '', 'tổng tham mưu'), 
(412, 0, 'nhân-dân', '', '', 'nhân dân'), 
(413, 0, 'trực-thăng', '', '', 'trực thăng'), 
(414, 0, 'quân-sự', '', '', 'quân sự'), 
(415, 0, 'quân-y', '', '', 'quân y'), 
(416, 0, 'khâm-liệm', '', '', 'khâm liệm'), 
(417, 0, 'an-táng', '', '', 'an táng'), 
(418, 0, 'bàn-bạc', '', '', 'bàn bạc'), 
(419, 0, 'mất-tích', '', '', 'mất tích'), 
(420, 0, 'vị-trí', '', '', 'vị trí'), 
(421, 0, 'huy-động', '', '', 'huy động'), 
(422, 0, 'tối-đa', '', '', 'tối đa'), 
(423, 0, 'ninh-thuận', '', '', 'ninh thuận'), 
(424, 0, 'phú-quý', '', '', 'phú quý'), 
(425, 0, 'mục-tiêu', '', '', 'mục tiêu'), 
(426, 0, 'trung-đoàn-trưởng', '', '', 'trung đoàn trưởng'), 
(427, 0, 'trung-đoàn', '', '', 'trung đoàn'), 
(428, 0, 'sư-đoàn', '', '', 'sư đoàn'), 
(429, 0, 'phi-đội', '', '', 'phi đội'), 
(430, 0, 'sĩ-quan', '', '', 'sĩ quan'), 
(431, 0, 'chỉ-huy', '', '', 'chỉ huy'), 
(432, 0, 'thế-hệ', '', '', 'thế hệ'), 
(433, 0, 'pháo-hoa', '', '', 'pháo hoa'), 
(434, 0, 'công-ty', '', '', 'công ty'), 
(435, 0, 'hóa-chất', '', '', 'hóa chất'), 
(436, 0, 'kỹ-thuật', '', '', 'kỹ thuật'), 
(437, 0, 'lắp-ráp', '', '', 'lắp ráp'), 
(438, 0, 'vận-chuyển', '', '', 'vận chuyển'), 
(439, 0, 'thời-gian-biểu', '', '', 'thời gian biểu'), 
(440, 0, 'chương-trình', '', '', 'chương trình'), 
(441, 0, 'nghệ-thuật', '', '', 'nghệ thuật'), 
(442, 0, 'thay-vì', '', '', 'thay vì'), 
(443, 0, 'trình-diễn', '', '', 'trình diễn'), 
(444, 0, 'ánh-sáng', '', '', 'ánh sáng'), 
(445, 0, 'âm-nhạc', '', '', 'âm nhạc'), 
(446, 0, 'thiết-kế', '', '', 'thiết kế'), 
(447, 0, 'chủ-đề', '', '', 'chủ đề'), 
(448, 0, 'trực-tiếp', '', '', 'trực tiếp'), 
(449, 0, 'hệ-thống', '', '', 'hệ thống'), 
(450, 0, 'bố-trí', '', '', 'bố trí'), 
(451, 0, 'dọc-đường', '', '', 'dọc đường'), 
(452, 0, 'trần-hưng-đạo', '', '', 'trần hưng đạo'), 
(453, 0, 'kết-thúc', '', '', 'kết thúc'), 
(454, 0, 'bến-thành', '', '', 'bến thành'), 
(455, 0, 'tư-vấn', '', '', 'tư vấn'), 
(456, 0, 'đơn-vị', '', '', 'đơn vị'), 
(457, 0, 'lân-cận', '', '', 'lân cận'), 
(458, 0, 'thủ-thiêm', '', '', 'thủ thiêm'), 
(459, 0, 'cầu-thủ', '', '', 'cầu thủ'), 
(460, 0, 'ngoài-ra', '', '', 'ngoài ra'), 
(461, 0, 'quảng-trường', '', '', 'quảng trường'), 
(462, 0, 'rải-rác', '', '', 'rải rác'), 
(463, 0, 'góp-phần', '', '', 'góp phần'), 
(464, 0, 'kinh-doanh', '', '', 'kinh doanh'), 
(465, 0, 'hải-triều', '', '', 'hải triều'), 
(466, 0, 'liên-quan', '', '', 'liên quan'), 
(467, 0, 'trật-tự', '', '', 'trật tự'), 
(468, 0, 'phương-án', '', '', 'phương án'), 
(469, 0, 'thế-nào', '', '', 'thế nào'), 
(470, 0, 'sài-gòn', '', '', 'sài gòn'), 
(471, 0, 'tham-quan', '', '', 'tham quan'), 
(472, 0, 'sáng-sớm', '', '', 'sáng sớm'), 
(473, 0, 'nguyễn-huệ', '', '', 'nguyễn huệ'), 
(474, 0, 'vận-hành', '', '', 'vận hành'), 
(475, 0, 'chụp-ảnh', '', '', 'chụp ảnh'), 
(476, 0, 'sạch-sẽ', '', '', 'sạch sẽ'), 
(477, 0, 'kiến-trúc', '', '', 'kiến trúc'), 
(478, 0, 'hiện-đại', '', '', 'hiện đại'), 
(479, 0, 'cổ-điển', '', '', 'cổ điển'), 
(480, 0, 'bình-thạnh', '', '', 'bình thạnh'), 
(481, 0, 'thích-thú', '', '', 'thích thú'), 
(482, 0, 'lưu-niệm', '', '', 'lưu niệm'), 
(483, 0, 'đi-chơi', '', '', 'đi chơi'), 
(484, 0, 'thua-kém', '', '', 'thua kém'), 
(485, 0, 'nhạc-nhẹ', '', '', 'nhạc nhẹ'), 
(486, 0, 'du-dương', '', '', 'du dương'), 
(487, 0, 'oi-bức', '', '', 'oi bức'), 
(488, 0, 'khó-khăn', '', '', 'khó khăn'), 
(489, 0, 'trong-sáng', '', '', 'trong sáng'), 
(490, 0, 'đô-thị', '', '', 'đô thị'), 
(491, 0, 'thanh-niên', '', '', 'thanh niên'), 
(492, 0, 'xung-phong', '', '', 'xung phong'), 
(493, 0, 'lề-đường', '', '', 'lề đường'), 
(494, 0, 'giám-đốc', '', '', 'giám đốc'), 
(495, 0, 'quản-lý', '', '', 'quản lý'), 
(496, 0, 'vĩnh-ninh', '', '', 'vĩnh ninh'), 
(497, 0, 'tự-động', '', '', 'tự động'), 
(498, 0, 'nghiên-cứu', '', '', 'nghiên cứu'), 
(499, 0, 'ngày-lễ', '', '', 'ngày lễ'), 
(500, 0, 'bán-kính', '', '', 'bán kính'), 
(501, 0, 'địa-điểm', '', '', 'địa điểm'), 
(502, 0, 'thương-mại', '', '', 'thương mại'), 
(503, 0, 'danh-sách', '', '', 'danh sách'), 
(504, 0, 'cụ-thể', '', '', 'cụ thể'), 
(505, 0, 'công-bố', '', '', 'công bố'), 
(506, 0, 'thống-kê', '', '', 'thống kê'), 
(507, 0, 'xe-điện', '', '', 'xe điện'), 
(508, 0, 'tính-toán', '', '', 'tính toán'), 
(509, 0, 'tốc-độ', '', '', 'tốc độ'), 
(510, 0, 'khai-thác', '', '', 'khai thác'), 
(511, 0, 'tự-nhiên', '', '', 'tự nhiên'), 
(512, 0, 'kinh-phí', '', '', 'kinh phí'), 
(513, 0, 'quảng-trị', '', '', 'quảng trị'), 
(514, 0, 'bà-nà', '', '', 'bà nà'), 
(515, 0, 'đẩy-xe', '', '', 'đẩy xe'), 
(516, 0, 'nhiệt-tình', '', '', 'nhiệt tình'), 
(517, 0, 'hoàng-anh', '', '', 'hoàng anh'), 
(518, 0, 'phụ-nữ', '', '', 'phụ nữ'), 
(519, 0, 'quảng-bình', '', '', 'quảng bình'), 
(520, 0, 'nguy-kịch', '', '', 'nguy kịch'), 
(521, 0, 'nằm-không', '', '', 'nằm không'), 
(522, 0, 'bộ-phận', '', '', 'bộ phận'), 
(523, 0, 'cảnh-sát', '', '', 'cảnh sát'), 
(524, 0, 'chỉ-đạo', '', '', 'chỉ đạo'), 
(525, 0, 'tiến-dũng', '', '', 'tiến dũng'), 
(526, 0, 'tín-hiệu', '', '', 'tín hiệu'), 
(527, 0, 'anh-dũng', '', '', 'anh dũng'), 
(528, 0, 'vào-khoảng', '', '', 'vào khoảng'), 
(529, 0, 'bất-ngờ', '', '', 'bất ngờ'), 
(530, 0, 'cuồn-cuộn', '', '', 'cuồn cuộn'), 
(531, 0, 'tiếng-kêu', '', '', 'tiếng kêu'), 
(532, 0, 'chới-với', '', '', 'chới với'), 
(533, 0, 'nhân-chứng', '', '', 'nhân chứng'), 
(534, 0, 'có-chồng', '', '', 'có chồng'), 
(535, 0, 'nam-nữ', '', '', 'nam nữ'), 
(536, 0, 'phạm-vi', '', '', 'phạm vi'), 
(537, 0, 'sáng-mai', '', '', 'sáng mai'), 
(538, 0, 'truy-điệu', '', '', 'truy điệu'), 
(539, 0, 'huấn-luyện', '', '', 'huấn luyện'), 
(540, 0, 'liên-hoàn', '', '', 'liên hoàn'), 
(541, 0, 'hư-hỏng', '', '', 'hư hỏng'), 
(542, 0, 'hốt-hoảng', '', '', 'hốt hoảng'), 
(543, 0, 'hành-trình', '', '', 'hành trình'), 
(544, 0, 'duy-trì', '', '', 'duy trì'), 
(545, 0, 'việc-làm', '', '', 'việc làm'), 
(546, 0, 'nghị-định', '', '', 'nghị định'), 
(547, 0, 'chi-tiết', '', '', 'chi tiết'), 
(548, 0, 'thi-hành', '', '', 'thi hành'), 
(549, 0, 'thất-nghiệp', '', '', 'thất nghiệp'), 
(550, 0, 'hiệu-lực', '', '', 'hiệu lực'), 
(551, 0, 'đào-tạo', '', '', 'đào tạo'), 
(552, 0, 'bồi-dưỡng', '', '', 'bồi dưỡng'), 
(553, 0, 'trình-độ', '', '', 'trình độ'), 
(554, 0, 'hợp-đồng', '', '', 'hợp đồng'), 
(555, 0, 'quy-định', '', '', 'quy định'), 
(556, 0, 'chấm-dứt', '', '', 'chấm dứt'), 
(557, 0, 'giới-thiệu', '', '', 'giới thiệu'), 
(558, 0, 'miễn-phí', '', '', 'miễn phí'), 
(559, 0, 'minh-họa', '', '', 'minh họa'), 
(560, 0, 'tái-cử', '', '', 'tái cử'), 
(561, 0, 'bổ-nhiệm', '', '', 'bổ nhiệm'), 
(562, 0, 'cán-bộ', '', '', 'cán bộ'), 
(563, 0, 'chức-vụ', '', '', 'chức vụ'), 
(564, 0, 'nhiệm-kỳ', '', '', 'nhiệm kỳ'), 
(565, 0, 'xã-hội', '', '', 'xã hội'), 
(566, 0, 'tự-nguyện', '', '', 'tự nguyện'), 
(567, 0, 'hưu-trí', '', '', 'hưu trí'), 
(568, 0, 'pháp-luật', '', '', 'pháp luật'), 
(569, 0, 'như-không', '', '', 'như không'), 
(570, 0, 'tỷ-lệ', '', '', 'tỷ lệ'), 
(571, 0, 'trợ-cấp', '', '', 'trợ cấp'), 
(572, 0, 'tiền-lương', '', '', 'tiền lương'), 
(573, 0, 'nguyện-vọng', '', '', 'nguyện vọng'), 
(574, 0, 'thẩm-quyền', '', '', 'thẩm quyền'), 
(575, 0, 'phù-hợp', '', '', 'phù hợp'), 
(576, 0, 'hướng-dẫn', '', '', 'hướng dẫn'), 
(577, 0, 'văn-phòng', '', '', 'văn phòng'), 
(578, 0, 'thành-lập', '', '', 'thành lập'), 
(579, 0, 'đặc-biệt', '', '', 'đặc biệt'), 
(580, 0, 'trụ-sở', '', '', 'trụ sở'), 
(581, 0, 'cho-mượn', '', '', 'cho mượn'), 
(582, 0, 'thiết-bị', '', '', 'thiết bị'), 
(583, 0, 'phương-tiện', '', '', 'phương tiện'), 
(584, 0, 'trách-nhiệm', '', '', 'trách nhiệm'), 
(585, 0, 'nghề-nghiệp', '', '', 'nghề nghiệp'), 
(586, 0, 'ngày-công', '', '', 'ngày công'), 
(587, 0, 'đăng-ký', '', '', 'đăng ký'), 
(588, 0, 'thỏa-thuận', '', '', 'thỏa thuận'), 
(589, 0, 'doanh-nghiệp', '', '', 'doanh nghiệp'), 
(590, 0, 'ủy-quyền', '', '', 'ủy quyền'), 
(591, 0, 'tối-thiểu', '', '', 'tối thiểu'), 
(592, 0, 'trúng-tuyển', '', '', 'trúng tuyển'), 
(593, 0, 'tuyển-dụng', '', '', 'tuyển dụng'), 
(594, 0, 'thông-tư', '', '', 'thông tư'), 
(595, 0, 'nội-vụ', '', '', 'nội vụ'), 
(596, 0, 'sửa-đổi', '', '', 'sửa đổi'), 
(597, 0, 'bổ-sung', '', '', 'bổ sung'), 
(598, 0, 'kết-quả', '', '', 'kết quả'), 
(599, 0, 'đầu-cơ', '', '', 'đầu cơ'), 
(600, 0, 'địa-chỉ', '', '', 'địa chỉ'), 
(601, 0, 'mô-hình', '', '', 'mô hình'), 
(602, 0, 'hợp-tác', '', '', 'hợp tác'), 
(603, 0, 'báo-cáo', '', '', 'báo cáo'), 
(604, 0, 'khả-thi', '', '', 'khả thi'), 
(605, 0, 'áp-dụng', '', '', 'áp dụng'), 
(606, 0, 'phương-pháp', '', '', 'phương pháp'), 
(607, 0, 'tác-giả', '', '', 'tác giả'), 
(608, 0, 'sự-kiện', '', '', 'sự kiện'), 
(609, 0, 'vừa-mới', '', '', 'vừa mới'), 
(610, 0, 'hoàn-thành', '', '', 'hoàn thành'), 
(611, 0, 'giảng-dạy', '', '', 'giảng dạy'), 
(612, 0, 'đại-học', '', '', 'đại học'), 
(613, 0, 'suy-nghĩ', '', '', 'suy nghĩ'), 
(614, 0, 'nghe-nói', '', '', 'nghe nói'), 
(615, 0, 'khuây-khỏa', '', '', 'khuây khỏa'), 
(616, 0, 'an-tâm', '', '', 'an tâm'), 
(617, 0, 'đau-khổ', '', '', 'đau khổ'), 
(618, 0, 'trẻ-em', '', '', 'trẻ em'), 
(619, 0, 'hòa-bình', '', '', 'hòa bình'), 
(620, 0, 'bố-mẹ', '', '', 'bố mẹ'), 
(621, 0, 'lo-sợ', '', '', 'lo sợ'), 
(622, 0, 'giết-hại', '', '', 'giết hại'), 
(623, 0, 'thập-kỷ', '', '', 'thập kỷ'), 
(624, 0, 'làm-chủ', '', '', 'làm chủ'), 
(625, 0, 'lập-quốc', '', '', 'lập quốc'), 
(626, 0, 'ký-ức', '', '', 'ký ức'), 
(627, 0, 'quan-tâm', '', '', 'quan tâm'), 
(628, 0, 'tiềm-thức', '', '', 'tiềm thức'), 
(629, 0, 'tâm-trí', '', '', 'tâm trí'), 
(630, 0, 'ngây-thơ', '', '', 'ngây thơ'), 
(631, 0, 'dễ-thương', '', '', 'dễ thương'), 
(632, 0, 'ô-tô', '', '', 'ô tô'), 
(633, 0, 'giấc-mơ', '', '', 'giấc mơ'), 
(634, 0, 'tuổi-thơ', '', '', 'tuổi thơ'), 
(635, 0, 'khủng-khiếp', '', '', 'khủng khiếp'), 
(636, 0, 'lối-thoát', '', '', 'lối thoát'), 
(637, 0, 'yên-bình', '', '', 'yên bình'), 
(638, 0, 'sống-sót', '', '', 'sống sót'), 
(639, 0, 'bao-nhiêu', '', '', 'bao nhiêu'), 
(640, 0, 'ám-ảnh', '', '', 'ám ảnh'), 
(641, 0, 'trẻ-thơ', '', '', 'trẻ thơ'), 
(642, 0, 'vô-tội', '', '', 'vô tội'), 
(643, 0, 'sát-hại', '', '', 'sát hại'), 
(644, 0, 'ung-thư', '', '', 'ung thư'), 
(645, 0, 'bẩm-sinh', '', '', 'bẩm sinh'), 
(646, 0, 'chất-độc', '', '', 'chất độc'), 
(647, 0, 'màu-da', '', '', 'màu da'), 
(648, 0, 'sáng-lập', '', '', 'sáng lập'), 
(649, 0, 'huy-chương', '', '', 'huy chương'), 
(650, 0, 'sự-nghiệp', '', '', 'sự nghiệp'), 
(651, 0, 'mỹ-thuật', '', '', 'mỹ thuật'), 
(652, 0, 'binh-sĩ', '', '', 'binh sĩ'), 
(653, 0, 'nhanh-chóng', '', '', 'nhanh chóng'), 
(654, 0, 'tranh-cãi', '', '', 'tranh cãi'), 
(655, 0, 'thực-sự', '', '', 'thực sự'), 
(656, 0, 'tiếp-diễn', '', '', 'tiếp diễn'), 
(657, 0, 'đánh-giá', '', '', 'đánh giá'), 
(658, 0, 'quan-điểm', '', '', 'quan điểm'), 
(659, 0, 'đa-số', '', '', 'đa số'), 
(660, 0, 'sụp-đổ', '', '', 'sụp đổ'), 
(661, 0, 'giải-phóng', '', '', 'giải phóng'), 
(662, 0, 'thể-hiện', '', '', 'thể hiện'), 
(663, 0, 'áp-đặt', '', '', 'áp đặt'), 
(664, 0, 'bao-vây', '', '', 'bao vây'), 
(665, 0, 'cấm-vận', '', '', 'cấm vận'), 
(666, 0, 'quan-hệ', '', '', 'quan hệ'), 
(667, 0, 'ngoại-giao', '', '', 'ngoại giao'), 
(668, 0, 'tổng-thống', '', '', 'tổng thống'), 
(669, 0, 'bình-thường', '', '', 'bình thường'), 
(670, 0, 'sai-lầm', '', '', 'sai lầm'), 
(671, 0, 'tích-cực', '', '', 'tích cực'), 
(672, 0, 'mạnh-mẽ', '', '', 'mạnh mẽ'), 
(673, 0, 'ngày-nay', '', '', 'ngày nay'), 
(674, 0, 'hưởng-thụ', '', '', 'hưởng thụ'), 
(675, 0, 'thiệt-hại', '', '', 'thiệt hại'), 
(676, 0, 'nặng-nề', '', '', 'nặng nề'), 
(677, 0, 'sức-khỏe', '', '', 'sức khỏe'), 
(678, 0, 'thủ-đô', '', '', 'thủ đô'), 
(679, 0, 'khảo-sát', '', '', 'khảo sát'), 
(680, 0, 'thị-trường', '', '', 'thị trường'), 
(681, 0, 'cơ-hội', '', '', 'cơ hội'), 
(682, 0, 'định-hướng', '', '', 'định hướng'), 
(683, 0, 'liên-hệ', '', '', 'liên hệ'), 
(684, 0, 'tổng-giám-đốc', '', '', 'tổng giám đốc'), 
(685, 0, 'nữa-là', '', '', 'nữa là'), 
(686, 0, 'tìm-hiểu', '', '', 'tìm hiểu'), 
(687, 0, 'ra-sao', '', '', 'ra sao'), 
(688, 0, 'thỉnh-thoảng', '', '', 'thỉnh thoảng'), 
(689, 0, 'phản-ứng', '', '', 'phản ứng'), 
(690, 0, 'tình-huống', '', '', 'tình huống'), 
(691, 0, 'nhà-cửa', '', '', 'nhà cửa'), 
(692, 0, 'bản-năng', '', '', 'bản năng'), 
(693, 0, 'nguy-cơ', '', '', 'nguy cơ'), 
(694, 0, 'tan-hoang', '', '', 'tan hoang'), 
(695, 0, 'thậm-chí', '', '', 'thậm chí'), 
(696, 0, 'tính-mạng', '', '', 'tính mạng'), 
(697, 0, 'ý-định', '', '', 'ý định'), 
(698, 0, 'trước-sau', '', '', 'trước sau'), 
(699, 0, 'quang-cảnh', '', '', 'quang cảnh'), 
(700, 0, 'đề-nghị', '', '', 'đề nghị'), 
(701, 0, 'thì-phải', '', '', 'thì phải'), 
(702, 0, 'trải-qua', '', '', 'trải qua'), 
(703, 0, 'thiên-tai', '', '', 'thiên tai'), 
(704, 0, 'khía-cạnh', '', '', 'khía cạnh'), 
(705, 0, 'tường-thuật', '', '', 'tường thuật'), 
(706, 0, 'diễu-binh', '', '', 'diễu binh'), 
(707, 0, 'duyệt-binh', '', '', 'duyệt binh'), 
(708, 0, 'chiến-thắng', '', '', 'chiến thắng'), 
(709, 0, 'bước-ngoặt', '', '', 'bước ngoặt'), 
(710, 0, 'trích-dẫn', '', '', 'trích dẫn'), 
(711, 0, 'quốc-khánh', '', '', 'quốc khánh'), 
(712, 0, 'hiện-diện', '', '', 'hiện diện'), 
(713, 0, 'hùng-tráng', '', '', 'hùng tráng'), 
(714, 0, 'bao-gồm', '', '', 'bao gồm'), 
(715, 0, 'chân-dung', '', '', 'chân dung'), 
(716, 0, 'thời-khắc', '', '', 'thời khắc'), 
(717, 0, 'trung-đông', '', '', 'trung đông'), 
(718, 0, 'bưu-điện', '', '', 'bưu điện'), 
(719, 0, 'phấn-khởi', '', '', 'phấn khởi'), 
(720, 0, 'cộng-sản', '', '', 'cộng sản'), 
(721, 0, 'ít-nhất', '', '', 'ít nhất'), 
(722, 0, 'khẳng-định', '', '', 'khẳng định'), 
(723, 0, 'thất-bại', '', '', 'thất bại'), 
(724, 0, 'siêu-cường', '', '', 'siêu cường'), 
(725, 0, 'phóng-viên', '', '', 'phóng viên'), 
(726, 0, 'lịch-sử', '', '', 'lịch sử'), 
(727, 0, 'sứ-mệnh', '', '', 'sứ mệnh'), 
(728, 0, 'vẻ-vang', '', '', 'vẻ vang'), 
(729, 0, 'hoàn-toàn', '', '', 'hoàn toàn'), 
(730, 0, 'kỷ-nguyên', '', '', 'kỷ nguyên'), 
(731, 0, 'đưa-tin', '', '', 'đưa tin'), 
(732, 0, 'chặt-chẽ', '', '', 'chặt chẽ'), 
(733, 0, 'hiện-nay', '', '', 'hiện nay'), 
(734, 0, 'song-phương', '', '', 'song phương'), 
(735, 0, 'năm-ngoái', '', '', 'năm ngoái'), 
(736, 0, 'sức-sống', '', '', 'sức sống'), 
(737, 0, 'diện-mạo', '', '', 'diện mạo'), 
(738, 0, 'mới-đây', '', '', 'mới đây'), 
(739, 0, 'lung-linh', '', '', 'lung linh'), 
(740, 0, 'vật-thể', '', '', 'vật thể'), 
(741, 0, 'nghi-ngờ', '', '', 'nghi ngờ'), 
(742, 0, 'dĩ-nhiên', '', '', 'dĩ nhiên'), 
(743, 0, 'nghiêm-trọng', '', '', 'nghiêm trọng'), 
(744, 0, 'lãnh-hải', '', '', 'lãnh hải'), 
(745, 0, 'xâm-phạm', '', '', 'xâm phạm'), 
(746, 0, 'tàu-ngầm', '', '', 'tàu ngầm'), 
(747, 0, 'cảnh-báo', '', '', 'cảnh báo'), 
(748, 0, 'láng-giềng', '', '', 'láng giềng'), 
(749, 0, 'ngân-sách', '', '', 'ngân sách'), 
(750, 0, 'nhấn-mạnh', '', '', 'nhấn mạnh'), 
(751, 0, 'đe-dọa', '', '', 'đe dọa'), 
(752, 0, 'đông-đảo', '', '', 'đông đảo'), 
(753, 0, 'hội-nghị', '', '', 'hội nghị'), 
(754, 0, 'hữu-nghị', '', '', 'hữu nghị'), 
(755, 0, 'đại-diện', '', '', 'đại diện'), 
(756, 0, 'liên-bang', '', '', 'liên bang'), 
(757, 0, 'mật-thiết', '', '', 'mật thiết'), 
(758, 0, 'trọng-đại', '', '', 'trọng đại'), 
(759, 0, 'thắng-lợi', '', '', 'thắng lợi'), 
(760, 0, 'sức-mạnh', '', '', 'sức mạnh'), 
(761, 0, 'đoàn-kết', '', '', 'đoàn kết'), 
(762, 0, 'sáng-suốt', '', '', 'sáng suốt'), 
(763, 0, 'tiến-bộ', '', '', 'tiến bộ'), 
(764, 0, 'thế-giới', '', '', 'thế giới'), 
(765, 0, 'ủng-hộ', '', '', 'ủng hộ'), 
(766, 0, 'thành-tựu', '', '', 'thành tựu'), 
(767, 0, 'to-lớn', '', '', 'to lớn'), 
(768, 0, 'thịnh-vượng', '', '', 'thịnh vượng'), 
(769, 0, 'tin-tưởng', '', '', 'tin tưởng'), 
(770, 0, 'ngày-càng', '', '', 'ngày càng'), 
(771, 0, 'ý-chí', '', '', 'ý chí'), 
(772, 0, 'quyết-tâm', '', '', 'quyết tâm'), 
(773, 0, 'ca-ngợi', '', '', 'ca ngợi'), 
(774, 0, 'hơn-nữa', '', '', 'hơn nữa'), 
(775, 0, 'triển-lãm', '', '', 'triển lãm'), 
(776, 0, 'giới-nghiêm', '', '', 'giới nghiêm'), 
(777, 0, 'biểu-tình', '', '', 'biểu tình'), 
(778, 0, 'công-lý', '', '', 'công lý'), 
(779, 0, 'yêu-cầu', '', '', 'yêu cầu'), 
(780, 0, 'cải-tổ', '', '', 'cải tổ'), 
(781, 0, 'làn-sóng', '', '', 'làn sóng'), 
(782, 0, 'xu-hướng', '', '', 'xu hướng'), 
(783, 0, 'thu-hút', '', '', 'thu hút'), 
(784, 0, 'bạo-động', '', '', 'bạo động'), 
(785, 0, 'phản-đối', '', '', 'phản đối'), 
(786, 0, 'liên-tiếp', '', '', 'liên tiếp'), 
(787, 0, 'bộ-máy', '', '', 'bộ máy'), 
(788, 0, 'thị-chính', '', '', 'thị chính'), 
(789, 0, 'hầu-hết', '', '', 'hầu hết'), 
(790, 0, 'vệ-binh', '', '', 'vệ binh'), 
(791, 0, 'triển-khai', '', '', 'triển khai'), 
(792, 0, 'bạo-lực', '', '', 'bạo lực'), 
(793, 0, 'mô-tả', '', '', 'mô tả'), 
(794, 0, 'báo-chí', '', '', 'báo chí'), 
(795, 0, 'phần-lớn', '', '', 'phần lớn'), 
(796, 0, 'mặc-dù', '', '', 'mặc dù'), 
(797, 0, 'mức-độ', '', '', 'mức độ'), 
(798, 0, 'xuất-phát', '', '', 'xuất phát'), 
(799, 0, 'tư-pháp', '', '', 'tư pháp'), 
(800, 0, 'giải-pháp', '', '', 'giải pháp'), 
(801, 0, 'quan-chức', '', '', 'quan chức'), 
(802, 0, 'thống-đốc', '', '', 'thống đốc'), 
(803, 0, 'chỉ-thị', '', '', 'chỉ thị'), 
(804, 0, 'giúp-ích', '', '', 'giúp ích'), 
(805, 0, 'khôi-phục', '', '', 'khôi phục'), 
(806, 0, 'gần-đây', '', '', 'gần đây'), 
(807, 0, 'nhất-là', '', '', 'nhất là'), 
(808, 0, 'phân-biệt', '', '', 'phân biệt'), 
(809, 0, 'phá-hoại', '', '', 'phá hoại'), 
(810, 0, 'xã-hội-học', '', '', 'xã hội học'), 
(811, 0, 'thảo-luận', '', '', 'thảo luận'), 
(812, 0, 'luật-pháp', '', '', 'luật pháp'), 
(813, 0, 'nghèo-nàn', '', '', 'nghèo nàn'), 
(814, 0, 'giáo-dục', '', '', 'giáo dục'), 
(815, 0, 'thủ-tướng', '', '', 'thủ tướng'), 
(816, 0, 'quan-ngại', '', '', 'quan ngại'), 
(817, 0, 'rộng-lớn', '', '', 'rộng lớn'), 
(818, 0, 'phòng-thủ', '', '', 'phòng thủ'), 
(819, 0, 'hội-đàm', '', '', 'hội đàm'), 
(820, 0, 'luân-phiên', '', '', 'luân phiên'), 
(821, 0, 'lo-ngại', '', '', 'lo ngại'), 
(822, 0, 'hành-động', '', '', 'hành động'), 
(823, 0, 'giám-sát', '', '', 'giám sát'), 
(824, 0, 'hàng-hóa', '', '', 'hàng hóa'), 
(825, 0, 'tôn-trọng', '', '', 'tôn trọng'), 
(826, 0, 'thực-dân', '', '', 'thực dân'), 
(827, 0, 'giai-đoạn', '', '', 'giai đoạn'), 
(828, 0, 'can-thiệp', '', '', 'can thiệp'), 
(829, 0, 'tiếp-sức', '', '', 'tiếp sức'), 
(830, 0, 'chấn-động', '', '', 'chấn động'), 
(831, 0, 'địa-cầu', '', '', 'địa cầu'), 
(832, 0, 'chiến-trường', '', '', 'chiến trường'), 
(833, 0, 'thay-chân', '', '', 'thay chân'), 
(834, 0, 'ngăn-cản', '', '', 'ngăn cản'), 
(835, 0, 'giang-sơn', '', '', 'giang sơn'), 
(836, 0, 'mỹ-quan', '', '', 'mỹ quan'), 
(837, 0, 'thông-điệp', '', '', 'thông điệp'), 
(838, 0, 'mở-đầu', '', '', 'mở đầu'), 
(839, 0, 'tuyên-ngôn', '', '', 'tuyên ngôn'), 
(840, 0, 'khai-sinh', '', '', 'khai sinh'), 
(841, 0, 'dân-chủ', '', '', 'dân chủ'), 
(842, 0, 'có-lẽ', '', '', 'có lẽ'), 
(843, 0, 'xuất-hiện', '', '', 'xuất hiện'), 
(844, 0, 'làm-bạn', '', '', 'làm bạn'), 
(845, 0, 'thù-địch', '', '', 'thù địch'), 
(846, 0, 'năm-một', '', '', 'năm một'), 
(847, 0, 'tồn-tại', '', '', 'tồn tại'), 
(848, 0, 'cõi-đời', '', '', 'cõi đời'), 
(849, 0, 'tương-lai', '', '', 'tương lai'), 
(850, 0, 'phấn-đấu', '', '', 'phấn đấu'), 
(851, 0, 'hàn-gắn', '', '', 'hàn gắn'), 
(852, 0, 'vết-thương', '', '', 'vết thương'), 
(853, 0, 'cường-quốc', '', '', 'cường quốc'), 
(854, 0, 'bá-chủ', '', '', 'bá chủ'), 
(855, 0, 'tưởng-tượng', '', '', 'tưởng tượng'), 
(856, 0, 'lòng-tin', '', '', 'lòng tin'), 
(857, 0, 'chiến-lược', '', '', 'chiến lược'), 
(858, 0, 'sát-thương', '', '', 'sát thương'), 
(859, 0, 'giá-trị', '', '', 'giá trị'), 
(860, 0, 'tinh-thần', '', '', 'tinh thần'), 
(861, 0, 'vật-chất', '', '', 'vật chất'), 
(862, 0, 'lập-tức', '', '', 'lập tức'), 
(863, 0, 'vững-chắc', '', '', 'vững chắc'), 
(864, 0, 'nào-là', '', '', 'nào là'), 
(865, 0, 'vai-trò', '', '', 'vai trò'), 
(866, 0, 'có-nghĩa', '', '', 'có nghĩa'), 
(867, 0, 'hồ-đồ', '', '', 'hồ đồ'), 
(868, 0, 'thách-thức', '', '', 'thách thức'), 
(869, 0, 'làm-cho', '', '', 'làm cho'), 
(870, 0, 'tổn-hại', '', '', 'tổn hại'), 
(871, 0, 'phản-bội', '', '', 'phản bội'), 
(872, 0, 'mạo-danh', '', '', 'mạo danh'), 
(873, 0, 'hãy-còn', '', '', 'hãy còn'), 
(874, 0, 'thử-thách', '', '', 'thử thách'), 
(875, 0, 'khả-năng', '', '', 'khả năng'), 
(876, 0, 'tin-cậy', '', '', 'tin cậy'), 
(877, 0, 'khoa-học', '', '', 'khoa học'), 
(878, 0, 'sở-tại', '', '', 'sở tại'), 
(879, 0, 'vệ-tinh', '', '', 'vệ tinh'), 
(880, 0, 'dấu-hiệu', '', '', 'dấu hiệu'), 
(881, 0, 'nhà-chứa', '', '', 'nhà chứa'), 
(882, 0, 'phân-tích', '', '', 'phân tích'), 
(883, 0, 'bằng-chứng', '', '', 'bằng chứng'), 
(884, 0, 'cường-độ', '', '', 'cường độ'), 
(885, 0, 'gián-đoạn', '', '', 'gián đoạn'), 
(886, 0, 'viện-trợ', '', '', 'viện trợ'), 
(887, 0, 'đàm-phán', '', '', 'đàm phán'), 
(888, 0, 'chế-tạo', '', '', 'chế tạo'), 
(889, 0, 'năng-lực', '', '', 'năng lực'), 
(890, 0, 'người-ngoài', '', '', 'người ngoài'), 
(891, 0, 'tính-chất', '', '', 'tính chất'), 
(892, 0, 'thời-đại', '', '', 'thời đại'), 
(893, 0, 'quy-mô', '', '', 'quy mô'), 
(894, 0, 'công-nghệ', '', '', 'công nghệ'), 
(895, 0, 'bộ-đội', '', '', 'bộ đội'), 
(896, 0, 'phòng-không', '', '', 'phòng không'), 
(897, 0, 'không-quân', '', '', 'không quân'), 
(898, 0, 'nổi-dậy', '', '', 'nổi dậy'), 
(899, 0, 'du-kích', '', '', 'du kích'), 
(900, 0, 'lãnh-thổ', '', '', 'lãnh thổ'), 
(901, 0, 'quân-lực', '', '', 'quân lực'), 
(902, 0, 'quân-chính', '', '', 'quân chính'), 
(903, 0, 'câu-hỏi', '', '', 'câu hỏi'), 
(904, 0, 'ngang-ngửa', '', '', 'ngang ngửa'), 
(905, 0, 'giằng-co', '', '', 'giằng co'), 
(906, 0, 'đo-ván', '', '', 'đo ván'), 
(907, 0, 'tất-nhiên', '', '', 'tất nhiên'), 
(908, 0, 'bom-nguyên-tử', '', '', 'bom nguyên tử'), 
(909, 0, 'cần-thiết', '', '', 'cần thiết'), 
(910, 0, 'xuất-sắc', '', '', 'xuất sắc'), 
(911, 0, 'trọn-vẹn', '', '', 'trọn vẹn'), 
(912, 0, 'xâm-nhập', '', '', 'xâm nhập'), 
(913, 0, 'mặt-trận', '', '', 'mặt trận'), 
(914, 0, 'đối-phó', '', '', 'đối phó'), 
(915, 0, 'tăng-cường', '', '', 'tăng cường'), 
(916, 0, 'cố-vấn', '', '', 'cố vấn'), 
(917, 0, 'leo-thang', '', '', 'leo thang'), 
(918, 0, 'xung-đột', '', '', 'xung đột'), 
(919, 0, 'nổi-tiếng', '', '', 'nổi tiếng'), 
(920, 0, 'tên-gọi', '', '', 'tên gọi'), 
(921, 0, 'bắc-bộ', '', '', 'bắc bộ'), 
(922, 0, 'tấn-công', '', '', 'tấn công'), 
(923, 0, 'khu-trục', '', '', 'khu trục'), 
(924, 0, 'không-hề', '', '', 'không hề'), 
(925, 0, 'thực-tế', '', '', 'thực tế'), 
(926, 0, 'dân-chúng', '', '', 'dân chúng'), 
(927, 0, 'hạn-chế', '', '', 'hạn chế'), 
(928, 0, 'quả-thực', '', '', 'quả thực'), 
(929, 0, 'khối-lượng', '', '', 'khối lượng'), 
(930, 0, 'tổn-thất', '', '', 'tổn thất'), 
(931, 0, 'đáng-kể', '', '', 'đáng kể'), 
(932, 0, 'vì-thế', '', '', 'vì thế'), 
(933, 0, 'trang-bị', '', '', 'trang bị'), 
(934, 0, 'siêu-âm', '', '', 'siêu âm'), 
(935, 0, 'tên-lửa', '', '', 'tên lửa'), 
(936, 0, 'tổ-hợp', '', '', 'tổ hợp'), 
(937, 0, 'nghĩa-đen', '', '', 'nghĩa đen'), 
(938, 0, 'nghĩa-bóng', '', '', 'nghĩa bóng'), 
(939, 0, 'quyết-liệt', '', '', 'quyết liệt'), 
(940, 0, 'tác-chiến', '', '', 'tác chiến'), 
(941, 0, 'hò-reo', '', '', 'hò reo'), 
(942, 0, 'khuôn-mặt', '', '', 'khuôn mặt'), 
(943, 0, 'định-vị', '', '', 'định vị'), 
(944, 0, 'giải-cứu', '', '', 'giải cứu'), 
(945, 0, 'tiếp-cận', '', '', 'tiếp cận'), 
(946, 0, 'tỉnh-táo', '', '', 'tỉnh táo'), 
(947, 0, 'quần-áo', '', '', 'quần áo'), 
(948, 0, 'chú-ý', '', '', 'chú ý'), 
(949, 0, 'thần-kỳ', '', '', 'thần kỳ'), 
(950, 0, 'thứ-bảy', '', '', 'thứ bảy'), 
(951, 0, 'quả-quyết', '', '', 'quả quyết'), 
(952, 0, 'thuyết-phục', '', '', 'thuyết phục'), 
(953, 0, 'thành-công', '', '', 'thành công'), 
(954, 0, 'khoanh-vùng', '', '', 'khoanh vùng'), 
(955, 0, 'kiến-thức', '', '', 'kiến thức'), 
(956, 0, 'phát-huy', '', '', 'phát huy'), 
(957, 0, 'tư-duy', '', '', 'tư duy'), 
(958, 0, 'thí-sinh', '', '', 'thí sinh'), 
(959, 0, 'tốt-tiếng', '', '', 'tốt tiếng'), 
(960, 0, 'kiên-trì', '', '', 'kiên trì'), 
(961, 0, 'nghiêm-khắc', '', '', 'nghiêm khắc'), 
(962, 0, 'trung-bình', '', '', 'trung bình'), 
(963, 0, 'học-viên', '', '', 'học viên'), 
(964, 0, 'trung-cấp', '', '', 'trung cấp'), 
(965, 0, 'chiến-thuật', '', '', 'chiến thuật'), 
(966, 0, 'hiệu-quả', '', '', 'hiệu quả'), 
(967, 0, 'luyện-tập', '', '', 'luyện tập'), 
(968, 0, 'xuất-bản', '', '', 'xuất bản'), 
(969, 0, 'từ-điển', '', '', 'từ điển'), 
(970, 0, 'loại-từ', '', '', 'loại từ'), 
(971, 0, 'ngữ-cảnh', '', '', 'ngữ cảnh'), 
(972, 0, 'ngữ-pháp', '', '', 'ngữ pháp'), 
(973, 0, 'sổ-tay', '', '', 'sổ tay'), 
(974, 0, 'từ-vựng', '', '', 'từ vựng'), 
(975, 0, 'tự-lập', '', '', 'tự lập'), 
(976, 0, 'số-lượng', '', '', 'số lượng'), 
(977, 0, 'giáo-viên', '', '', 'giáo viên'), 
(978, 0, 'thành-tích', '', '', 'thành tích'), 
(979, 0, 'cao-thủ', '', '', 'cao thủ'), 
(980, 0, 'bí-quyết', '', '', 'bí quyết'), 
(981, 0, 'học-hỏi', '', '', 'học hỏi'), 
(982, 0, 'số-học', '', '', 'số học'), 
(983, 0, 'khó-nghe', '', '', 'khó nghe'), 
(984, 0, 'trở-nên', '', '', 'trở nên'), 
(985, 0, 'dễ-dàng', '', '', 'dễ dàng'), 
(986, 0, 'quang-hưng', '', '', 'quang hưng'), 
(987, 0, 'thủ-thuật', '', '', 'thủ thuật'), 
(988, 0, 'linh-đan', '', '', 'linh đan'), 
(989, 0, 'văn-hội', '', '', 'văn hội'), 
(990, 0, 'làm-quen', '', '', 'làm quen'), 
(991, 0, 'quen-thuộc', '', '', 'quen thuộc'), 
(992, 0, 'rèn-luyện', '', '', 'rèn luyện'), 
(993, 0, 'hoàn-tất', '', '', 'hoàn tất'), 
(994, 0, 'uy-tín', '', '', 'uy tín'), 
(995, 0, 'diễn-đạt', '', '', 'diễn đạt'), 
(996, 0, 'trôi-chảy', '', '', 'trôi chảy'), 
(997, 0, 'phát-âm', '', '', 'phát âm'), 
(998, 0, 'bình-tĩnh', '', '', 'bình tĩnh'), 
(999, 0, 'tự-tin', '', '', 'tự tin'), 
(1000, 0, 'xác-thực', '', '', 'xác thực'), 
(1001, 0, 'môi-trường', '', '', 'môi trường'), 
(1002, 0, 'đam-mê', '', '', 'đam mê'), 
(1003, 0, 'người-ta', '', '', 'người ta'), 
(1004, 0, 'học-bổng', '', '', 'học bổng'), 
(1005, 0, 'tài-năng', '', '', 'tài năng'), 
(1006, 0, 'hoàn-cảnh', '', '', 'hoàn cảnh'), 
(1007, 0, 'sau-đây', '', '', 'sau đây'), 
(1008, 0, 'công-dân', '', '', 'công dân'), 
(1009, 0, 'tốt-nghiệp', '', '', 'tốt nghiệp'), 
(1010, 0, 'tiêu-chí', '', '', 'tiêu chí'), 
(1011, 0, 'hồ-sơ', '', '', 'hồ sơ'), 
(1012, 0, 'giấy-tờ', '', '', 'giấy tờ'), 
(1013, 0, 'tiên-hoàng', '', '', 'tiên hoàng'), 
(1014, 0, 'bến-nghé', '', '', 'bến nghé'), 
(1015, 0, 'di-động', '', '', 'di động'), 
(1016, 0, 'sản-phẩm', '', '', 'sản phẩm'), 
(1017, 0, 'hội-chợ', '', '', 'hội chợ'), 
(1018, 0, 'an-giang', '', '', 'an giang'), 
(1019, 0, 'miệt-mài', '', '', 'miệt mài'), 
(1020, 0, 'sản-xuất', '', '', 'sản xuất'), 
(1021, 0, 'chứng-nhận', '', '', 'chứng nhận'), 
(1022, 0, 'bản-quyền', '', '', 'bản quyền'), 
(1023, 0, 'biệt-danh', '', '', 'biệt danh'), 
(1024, 0, 'trìu-mến', '', '', 'trìu mến'), 
(1025, 0, 'giảng-viên', '', '', 'giảng viên'), 
(1026, 0, 'nhà-khoa-học', '', '', 'nhà khoa học'), 
(1027, 0, 'năng-suất', '', '', 'năng suất'), 
(1028, 0, 'đời-sống', '', '', 'đời sống'), 
(1029, 0, 'nông-dân', '', '', 'nông dân'), 
(1030, 0, 'ước-mơ', '', '', 'ước mơ'), 
(1031, 0, 'sinh-vật', '', '', 'sinh vật'), 
(1032, 0, 'có-ích', '', '', 'có ích'), 
(1033, 0, 'sâu-bệnh', '', '', 'sâu bệnh'), 
(1034, 0, 'biện-pháp', '', '', 'biện pháp'), 
(1035, 0, 'thân-thiện', '', '', 'thân thiện'), 
(1036, 0, 'ký-sinh', '', '', 'ký sinh'), 
(1037, 0, 'côn-trùng', '', '', 'côn trùng'), 
(1038, 0, 'hành-hạ', '', '', 'hành hạ'), 
(1039, 0, 'tế-bào', '', '', 'tế bào'), 
(1040, 0, 'rơm-rớm', '', '', 'rơm rớm'), 
(1041, 0, 'nước-mắt', '', '', 'nước mắt'), 
(1042, 0, 'thích-hợp', '', '', 'thích hợp'), 
(1043, 0, 'nhiệt-độ', '', '', 'nhiệt độ'), 
(1044, 0, 'dần-dần', '', '', 'dần dần'), 
(1045, 0, 'chủ-yếu', '', '', 'chủ yếu'), 
(1046, 0, 'nguồn-gốc', '', '', 'nguồn gốc'), 
(1047, 0, 'trưng-bày', '', '', 'trưng bày'), 
(1048, 0, 'cao-tổ', '', '', 'cao tổ'), 
(1049, 0, 'mơ-ước', '', '', 'mơ ước'), 
(1050, 0, 'ngũ-cốc', '', '', 'ngũ cốc'), 
(1051, 0, 'thu-hoạch', '', '', 'thu hoạch'), 
(1052, 0, 'tư-sản', '', '', 'tư sản'), 
(1053, 0, 'khá-giả', '', '', 'khá giả'), 
(1054, 0, 'phong-phú', '', '', 'phong phú'), 
(1055, 0, 'giá-cả', '', '', 'giá cả'), 
(1056, 0, 'phải-chăng', '', '', 'phải chăng'), 
(1057, 0, 'dược-liệu', '', '', 'dược liệu'), 
(1058, 0, 'nhân-tạo', '', '', 'nhân tạo'), 
(1059, 0, 'tác-dụng', '', '', 'tác dụng'), 
(1060, 0, 'dư-luận', '', '', 'dư luận'), 
(1061, 0, 'thủ-khoa', '', '', 'thủ khoa'), 
(1062, 0, 'ôn-tập', '', '', 'ôn tập'), 
(1063, 0, 'kiểm-tra', '', '', 'kiểm tra'), 
(1064, 0, 'hợp-lý', '', '', 'hợp lý'), 
(1065, 0, 'chủ-quan', '', '', 'chủ quan'), 
(1066, 0, 'chịu-khó', '', '', 'chịu khó'), 
(1067, 0, 'phụ-thuộc', '', '', 'phụ thuộc'), 
(1068, 0, 'tổng-cục', '', '', 'tổng cục'), 
(1069, 0, 'quy-chế', '', '', 'quy chế'), 
(1070, 0, 'khởi-điểm', '', '', 'khởi điểm'), 
(1071, 0, 'phụ-đạo', '', '', 'phụ đạo'), 
(1072, 0, 'giáo-sư', '', '', 'giáo sư'), 
(1073, 0, 'trụ-cột', '', '', 'trụ cột'), 
(1074, 0, 'thực-ra', '', '', 'thực ra'), 
(1075, 0, 'tài-liệu', '', '', 'tài liệu'), 
(1076, 0, 'ngoại-ngữ', '', '', 'ngoại ngữ'), 
(1077, 0, 'lê-thê', '', '', 'lê thê'), 
(1078, 0, 'văn-kiện', '', '', 'văn kiện'), 
(1079, 0, 'nghĩa-vụ', '', '', 'nghĩa vụ'), 
(1080, 0, 'khách-quan', '', '', 'khách quan'), 
(1081, 0, 'hiểu-biết', '', '', 'hiểu biết'), 
(1082, 0, 'nhỏ-nhoi', '', '', 'nhỏ nhoi'), 
(1083, 0, 'khi-nào', '', '', 'khi nào'), 
(1084, 0, 'tra-cứu', '', '', 'tra cứu'), 
(1085, 0, 'đi-làm', '', '', 'đi làm'), 
(1086, 0, 'lên-lớp', '', '', 'lên lớp'), 
(1087, 0, 'giám-thị', '', '', 'giám thị'), 
(1088, 0, 'vất-vả', '', '', 'vất vả'), 
(1089, 0, 'quay-cóp', '', '', 'quay cóp'), 
(1090, 0, 'ngân-hàng', '', '', 'ngân hàng'), 
(1091, 0, 'nhận-thấy', '', '', 'nhận thấy'), 
(1092, 0, 'thi-cử', '', '', 'thi cử'), 
(1093, 0, 'hết-sức', '', '', 'hết sức'), 
(1094, 0, 'thụ-động', '', '', 'thụ động'), 
(1095, 0, 'sáng-tạo', '', '', 'sáng tạo'), 
(1096, 0, 'sau-này', '', '', 'sau này'), 
(1097, 0, 'tham-khảo', '', '', 'tham khảo'), 
(1098, 0, 'am-hiểu', '', '', 'am hiểu'), 
(1099, 0, 'nhận-thức', '', '', 'nhận thức'), 
(1100, 0, 'lý-lịch', '', '', 'lý lịch'), 
(1101, 0, 'tài-chính', '', '', 'tài chính'), 
(1102, 0, 'tư-cách', '', '', 'tư cách'), 
(1103, 0, 'nghĩa-là', '', '', 'nghĩa là'), 
(1104, 0, 'sát-hạch', '', '', 'sát hạch'), 
(1105, 0, 'quản-trị', '', '', 'quản trị'), 
(1106, 0, 'căn-cứ', '', '', 'căn cứ'), 
(1107, 0, 'hàng-đầu', '', '', 'hàng đầu'), 
(1108, 0, 'sinh-học', '', '', 'sinh học'), 
(1109, 0, 'ứng-dụng', '', '', 'ứng dụng'), 
(1110, 0, 'động-vật', '', '', 'động vật'), 
(1111, 0, 'sinh-sản', '', '', 'sinh sản'), 
(1112, 0, 'học-giả', '', '', 'học giả'), 
(1113, 0, 'trí-thức', '', '', 'trí thức'), 
(1114, 0, 'năm-học', '', '', 'năm học'), 
(1115, 0, 'tiến-sĩ', '', '', 'tiến sĩ'), 
(1116, 0, 'ý-kiến', '', '', 'ý kiến'), 
(1117, 0, 'độc-giả', '', '', 'độc giả'), 
(1118, 0, 'niềm-tin', '', '', 'niềm tin'), 
(1119, 0, 'nói-chuyện', '', '', 'nói chuyện'), 
(1120, 0, 'tại-sao', '', '', 'tại sao'), 
(1121, 0, 'nền-tảng', '', '', 'nền tảng'), 
(1122, 0, 'con-số', '', '', 'con số'), 
(1123, 0, 'bắt-tay', '', '', 'bắt tay'), 
(1124, 0, 'phòng-thí-nghiệm', '', '', 'phòng thí nghiệm'), 
(1125, 0, 'tiến-độ', '', '', 'tiến độ'), 
(1126, 0, 'thuận-lợi', '', '', 'thuận lợi'), 
(1127, 0, 'kết-hợp', '', '', 'kết hợp'), 
(1128, 0, 'tập-đoàn', '', '', 'tập đoàn'), 
(1129, 0, 'tân-tạo', '', '', 'tân tạo'), 
(1130, 0, 'theo-đuổi', '', '', 'theo đuổi'), 
(1131, 0, 'thụ-tinh', '', '', 'thụ tinh'), 
(1132, 0, 'ống-nghiệm', '', '', 'ống nghiệm'), 
(1133, 0, 'vô-sinh', '', '', 'vô sinh'), 
(1134, 0, 'tinh-trùng', '', '', 'tinh trùng'), 
(1135, 0, 'phổ-biến', '', '', 'phổ biến'), 
(1136, 0, 'quai-bị', '', '', 'quai bị'), 
(1137, 0, 'bàn-tay', '', '', 'bàn tay'), 
(1138, 0, 'tấm-lòng', '', '', 'tấm lòng'), 
(1139, 0, 'hạnh-phúc', '', '', 'hạnh phúc'), 
(1140, 0, 'luận-án', '', '', 'luận án'), 
(1141, 0, 'mới-mẻ', '', '', 'mới mẻ'), 
(1142, 0, 'tiềm-năng', '', '', 'tiềm năng'), 
(1143, 0, 'trí-tuệ', '', '', 'trí tuệ'), 
(1144, 0, 'lý-do', '', '', 'lý do'), 
(1145, 0, 'từ-bỏ', '', '', 'từ bỏ'), 
(1146, 0, 'đảm-nhận', '', '', 'đảm nhận'), 
(1147, 0, 'chủ-nhiệm', '', '', 'chủ nhiệm'), 
(1148, 0, 'thông-minh', '', '', 'thông minh'), 
(1149, 0, 'hiệu-trưởng', '', '', 'hiệu trưởng'), 
(1150, 0, 'mệnh-danh', '', '', 'mệnh danh'), 
(1151, 0, 'giờ-đây', '', '', 'giờ đây'), 
(1152, 0, 'thông-thường', '', '', 'thông thường'), 
(1153, 0, 'tiểu-sử', '', '', 'tiểu sử'), 
(1154, 0, 'nhận-xét', '', '', 'nhận xét'), 
(1155, 0, 'ngón-tay', '', '', 'ngón tay'), 
(1156, 0, 'trả-lời', '', '', 'trả lời'), 
(1157, 0, 'hồi-hộp', '', '', 'hồi hộp'), 
(1158, 0, 'dương-cầm', '', '', 'dương cầm'), 
(1159, 0, 'hội-trường', '', '', 'hội trường'), 
(1160, 0, 'nhà-hát', '', '', 'nhà hát'), 
(1161, 0, 'người-ở', '', '', 'người ở'), 
(1162, 0, 'nghệ-sĩ', '', '', 'nghệ sĩ'), 
(1163, 0, 'em-gái', '', '', 'em gái'), 
(1164, 0, 'ngạc-nhiên', '', '', 'ngạc nhiên'), 
(1165, 0, 'tiếp-thu', '', '', 'tiếp thu'), 
(1166, 0, 'thần-đồng', '', '', 'thần đồng'), 
(1167, 0, 'tập-luyện', '', '', 'tập luyện'), 
(1168, 0, 'thoải-mái', '', '', 'thoải mái'), 
(1169, 0, 'khó-nhằn', '', '', 'khó nhằn'), 
(1170, 0, 'phô-diễn', '', '', 'phô diễn'), 
(1171, 0, 'một-vài', '', '', 'một vài'), 
(1172, 0, 'biểu-diễn', '', '', 'biểu diễn'), 
(1173, 0, 'cống-hiến', '', '', 'cống hiến'), 
(1174, 0, 'giấy-chứng-nhận', '', '', 'giấy chứng nhận'), 
(1175, 0, 'ưu-tiên', '', '', 'ưu tiên'), 
(1176, 0, 'khuyến-khích', '', '', 'khuyến khích'), 
(1177, 0, 'hoàn-thiện', '', '', 'hoàn thiện'), 
(1178, 0, 'dự-thi', '', '', 'dự thi'), 
(1179, 0, 'thư-ký', '', '', 'thư ký'), 
(1180, 0, 'hội-đồng', '', '', 'hội đồng'), 
(1181, 0, 'thủ-tục', '', '', 'thủ tục'), 
(1182, 0, 'khảo-thí', '', '', 'khảo thí'), 
(1183, 0, 'xuất-trình', '', '', 'xuất trình'), 
(1184, 0, 'chứng-minh', '', '', 'chứng minh'), 
(1185, 0, 'sai-sót', '', '', 'sai sót'), 
(1186, 0, 'ngày-tháng', '', '', 'ngày tháng'), 
(1187, 0, 'xem-xét', '', '', 'xem xét'), 
(1188, 0, 'khoảng-cách', '', '', 'khoảng cách'), 
(1189, 0, 'cuối-cùng', '', '', 'cuối cùng'), 
(1190, 0, 'lưu-ý', '', '', 'lưu ý'), 
(1191, 0, 'tiếp-theo', '', '', 'tiếp theo'), 
(1192, 0, 'giả-mạo', '', '', 'giả mạo'), 
(1193, 0, 'văn-bằng', '', '', 'văn bằng'), 
(1194, 0, 'chứng-chỉ', '', '', 'chứng chỉ'), 
(1195, 0, 'hợp-pháp', '', '', 'hợp pháp'), 
(1196, 0, 'ba-lô', '', '', 'ba lô'), 
(1197, 0, 'giáo-án', '', '', 'giáo án'), 
(1198, 0, 'sốt-rét', '', '', 'sốt rét'), 
(1199, 0, 'thám-báo', '', '', 'thám báo'), 
(1200, 0, 'biệt-kích', '', '', 'biệt kích'), 
(1201, 0, 'từ-trường', '', '', 'từ trường'), 
(1202, 0, 'phổ-thông', '', '', 'phổ thông'), 
(1203, 0, 'giảng-đường', '', '', 'giảng đường'), 
(1204, 0, 'tỉnh-thành', '', '', 'tỉnh thành'), 
(1205, 0, 'non-sông', '', '', 'non sông'), 
(1206, 0, 'tuổi-đời', '', '', 'tuổi đời'), 
(1207, 0, 'năm-mươi', '', '', 'năm mươi'), 
(1208, 0, 'thâm-niên', '', '', 'thâm niên'), 
(1209, 0, 'nhơn-bình', '', '', 'nhơn bình'), 
(1210, 0, 'triệu-tập', '', '', 'triệu tập'), 
(1211, 0, 'lên-đường', '', '', 'lên đường'), 
(1212, 0, 'tập-kết', '', '', 'tập kết'), 
(1213, 0, 'tiểu-ban', '', '', 'tiểu ban'), 
(1214, 0, 'tới-nơi', '', '', 'tới nơi'), 
(1215, 0, 'phân-công', '', '', 'phân công'), 
(1216, 0, 'quần-chúng', '', '', 'quần chúng'), 
(1217, 0, 'tham-mưu', '', '', 'tham mưu'), 
(1218, 0, 'trung-ương', '', '', 'trung ương'), 
(1219, 0, 'chủ-trương', '', '', 'chủ trương'), 
(1220, 0, 'chiến-khu', '', '', 'chiến khu'), 
(1221, 0, 'thầy-giáo', '', '', 'thầy giáo'), 
(1222, 0, 'sách-giáo-khoa', '', '', 'sách giáo khoa'), 
(1223, 0, 'sư-phạm', '', '', 'sư phạm'), 
(1224, 0, 'ấm-cúng', '', '', 'ấm cúng'), 
(1225, 0, 'hoàng-cầm', '', '', 'hoàng cầm'), 
(1226, 0, 'lương-thực', '', '', 'lương thực'), 
(1227, 0, 'nương-rẫy', '', '', 'nương rẫy'), 
(1228, 0, 'từ-sơn', '', '', 'từ sơn'), 
(1229, 0, 'bắc-ninh', '', '', 'bắc ninh'), 
(1230, 0, 'tiến-công', '', '', 'tiến công'), 
(1231, 0, 'quảng-nam', '', '', 'quảng nam'), 
(1232, 0, 'tổng-hợp', '', '', 'tổng hợp'), 
(1233, 0, 'bà-rịa', '', '', 'bà rịa'), 
(1234, 0, 'tô-điểm', '', '', 'tô điểm'), 
(1235, 0, 'phẩm-chất', '', '', 'phẩm chất'), 
(1236, 1, 'khai-giảng', '', '', 'khai giảng'), 
(1237, 0, 'trường-học', '', '', 'trường học'), 
(1238, 0, 'hậu-phương', '', '', 'hậu phương'), 
(1239, 0, 'cà-mau', '', '', 'cà mau'), 
(1240, 0, 'chiến-sĩ', '', '', 'chiến sĩ'), 
(1241, 0, 'tình-nguyện', '', '', 'tình nguyện'), 
(1242, 0, 'sức-lực', '', '', 'sức lực'), 
(1243, 0, 'gian-khổ', '', '', 'gian khổ'), 
(1244, 0, 'rên-rỉ', '', '', 'rên rỉ'), 
(1245, 0, 'than-vãn', '', '', 'than vãn'), 
(1246, 0, 'bất-lợi', '', '', 'bất lợi'), 
(1247, 0, 'thương-binh', '', '', 'thương binh'), 
(1248, 0, 'ngược-xuôi', '', '', 'ngược xuôi'), 
(1249, 0, 'mưu-sinh', '', '', 'mưu sinh'), 
(1250, 0, 'học-hành', '', '', 'học hành'), 
(1251, 0, 'xúc-động', '', '', 'xúc động'), 
(1252, 0, 'nụ-cười', '', '', 'nụ cười'), 
(1253, 0, 'khốc-liệt', '', '', 'khốc liệt'), 
(1254, 0, 'cuộc-đời', '', '', 'cuộc đời'), 
(1255, 0, 'mất-mát', '', '', 'mất mát'), 
(1256, 0, 'làm-sao', '', '', 'làm sao'), 
(1257, 0, 'tuyệt-vọng', '', '', 'tuyệt vọng'), 
(1258, 0, 'nghị-lực', '', '', 'nghị lực'), 
(1259, 0, 'chu-toàn', '', '', 'chu toàn'), 
(1260, 0, 'làm-cao', '', '', 'làm cao'), 
(1261, 0, 'nhường-nào', '', '', 'nhường nào'), 
(1262, 0, 'nhận-ra', '', '', 'nhận ra'), 
(1263, 0, 'thanh-bình', '', '', 'thanh bình'), 
(1264, 0, 'tri-ân', '', '', 'tri ân'), 
(1265, 0, 'bờ-bến', '', '', 'bờ bến'), 
(1266, 0, 'cha-mẹ', '', '', 'cha mẹ'), 
(1267, 0, 'sân-khấu', '', '', 'sân khấu'), 
(1268, 0, 'mái-tóc', '', '', 'mái tóc'), 
(1269, 0, 'tình-báo', '', '', 'tình báo'), 
(1270, 0, 'tra-tấn', '', '', 'tra tấn'), 
(1271, 0, 'dã-man', '', '', 'dã man'), 
(1272, 0, 'bắt-bớ', '', '', 'bắt bớ'), 
(1273, 0, 'giam-cầm', '', '', 'giam cầm'), 
(1274, 0, 'sống-lại', '', '', 'sống lại'), 
(1275, 0, 'cám-dỗ', '', '', 'cám dỗ'), 
(1276, 0, 'mua-chuộc', '', '', 'mua chuộc'), 
(1277, 0, 'can-đảm', '', '', 'can đảm'), 
(1278, 0, 'thời-chiến', '', '', 'thời chiến'), 
(1279, 0, 'thấm-thía', '', '', 'thấm thía'), 
(1280, 0, 'tuổi-trẻ', '', '', 'tuổi trẻ'), 
(1281, 0, 'hôm-nay', '', '', 'hôm nay'), 
(1282, 0, 'tư-liệu', '', '', 'tư liệu'), 
(1283, 0, 'sâu-sắc', '', '', 'sâu sắc'), 
(1284, 0, 'tóc-bạc', '', '', 'tóc bạc'), 
(1285, 0, 'hết-lòng', '', '', 'hết lòng'), 
(1286, 0, 'sống-còn', '', '', 'sống còn'), 
(1287, 0, 'sự-cố', '', '', 'sự cố'), 
(1288, 0, 'tình-yêu', '', '', 'tình yêu'), 
(1289, 0, 'nhọc-nhằn', '', '', 'nhọc nhằn'), 
(1290, 0, 'bây-giờ', '', '', 'bây giờ'), 
(1291, 0, 'bao-công', '', '', 'bao công'), 
(1292, 0, 'biết-ơn', '', '', 'biết ơn'), 
(1293, 0, 'lớn-lao', '', '', 'lớn lao'), 
(1294, 0, 'nói-lên', '', '', 'nói lên'), 
(1295, 0, 'qua-ngày', '', '', 'qua ngày'), 
(1296, 0, 'truyền-thống', '', '', 'truyền thống'), 
(1297, 0, 'đấu-tranh', '', '', 'đấu tranh'), 
(1298, 0, 'khi-quân', '', '', 'khi quân'), 
(1299, 0, 'kinh-đô', '', '', 'kinh đô'), 
(1300, 0, 'đô-hộ', '', '', 'đô hộ'), 
(1301, 0, 'chủ-nghĩa', '', '', 'chủ nghĩa'), 
(1302, 0, 'duy-tân', '', '', 'duy tân'), 
(1303, 0, 'vô-số', '', '', 'vô số'), 
(1304, 0, 'nồng-nàn', '', '', 'nồng nàn'), 
(1305, 0, 'tầng-lớp', '', '', 'tầng lớp'), 
(1306, 0, 'ra-đời', '', '', 'ra đời'), 
(1307, 0, 'làm-nên', '', '', 'làm nên'), 
(1308, 0, 'căn-bản', '', '', 'căn bản'), 
(1309, 0, 'nhưng-mà', '', '', 'nhưng mà'), 
(1310, 0, 'trường-kỳ', '', '', 'trường kỳ'), 
(1311, 0, 'đế-quốc', '', '', 'đế quốc'), 
(1312, 0, 'đương-đầu', '', '', 'đương đầu'), 
(1313, 0, 'kết-tinh', '', '', 'kết tinh'), 
(1314, 0, 'tự-cường', '', '', 'tự cường'), 
(1315, 0, 'khát-vọng', '', '', 'khát vọng'), 
(1316, 0, 'thế-kỷ', '', '', 'thế kỷ'), 
(1317, 0, 'tiêu-biểu', '', '', 'tiêu biểu'), 
(1318, 0, 'tiền-thân', '', '', 'tiền thân'), 
(1319, 0, 'cơ-bản', '', '', 'cơ bản'), 
(1320, 0, 'tham-luận', '', '', 'tham luận'), 
(1321, 0, 'tiên-phong', '', '', 'tiên phong'), 
(1322, 0, 'mại-dâm', '', '', 'mại dâm'), 
(1323, 0, 'gập-ghềnh', '', '', 'gập ghềnh'), 
(1324, 0, 'say-mê', '', '', 'say mê'), 
(1325, 0, 'sinh-ra', '', '', 'sinh ra'), 
(1326, 0, 'nho-giáo', '', '', 'nho giáo'), 
(1327, 0, 'thông-tấn-xã', '', '', 'thông tấn xã'), 
(1328, 0, 'kết-hôn', '', '', 'kết hôn'), 
(1329, 0, 'nghiệp-đoàn', '', '', 'nghiệp đoàn'), 
(1330, 0, 'ban-công', '', '', 'ban công'), 
(1331, 0, 'sử-học', '', '', 'sử học'), 
(1332, 0, 'tòa-soạn', '', '', 'tòa soạn'), 
(1333, 0, 'tạp-chí', '', '', 'tạp chí'), 
(1334, 0, 'trị-sự', '', '', 'trị sự'), 
(1335, 0, 'phát-hành', '', '', 'phát hành'), 
(1336, 0, 'làm-công', '', '', 'làm công'), 
(1337, 0, 'tiêu-cực', '', '', 'tiêu cực'), 
(1338, 0, 'cam-chịu', '', '', 'cam chịu'), 
(1339, 0, 'phục-hồi', '', '', 'phục hồi'), 
(1340, 0, 'nhân-phẩm', '', '', 'nhân phẩm'), 
(1341, 0, 'ngoại-thành', '', '', 'ngoại thành'), 
(1342, 0, 'thu-thập', '', '', 'thu thập'), 
(1343, 0, 'số-liệu', '', '', 'số liệu'), 
(1344, 0, 'tiền-tài', '', '', 'tiền tài'), 
(1345, 0, 'công-khai', '', '', 'công khai'), 
(1346, 0, 'xuân-thiện', '', '', 'xuân thiện'), 
(1347, 0, 'mâu-thuẫn', '', '', 'mâu thuẫn'), 
(1348, 0, 'trò-chuyện', '', '', 'trò chuyện'), 
(1349, 0, 'thị-trấn', '', '', 'thị trấn'), 
(1350, 0, 'thiếu-nữ', '', '', 'thiếu nữ'), 
(1351, 0, 'thái-nguyên', '', '', 'thái nguyên'), 
(1352, 0, 'hiếp-dâm', '', '', 'hiếp dâm'), 
(1353, 0, 'dâm-ô', '', '', 'dâm ô'), 
(1354, 0, 'ra-lệnh', '', '', 'ra lệnh'), 
(1355, 0, 'truy-nã', '', '', 'truy nã'), 
(1356, 0, 'hy-hữu', '', '', 'hy hữu'), 
(1357, 0, 'trình-báo', '', '', 'trình báo'), 
(1358, 0, 'sinh-nhật', '', '', 'sinh nhật'), 
(1359, 0, 'bặt-tăm', '', '', 'bặt tăm'), 
(1360, 0, 'nữ-sinh', '', '', 'nữ sinh'), 
(1361, 0, 'tệ-hại', '', '', 'tệ hại'), 
(1362, 0, 'tình-dục', '', '', 'tình dục'), 
(1363, 0, 'choáng-váng', '', '', 'choáng váng'), 
(1364, 0, 'kể-ra', '', '', 'kể ra'), 
(1365, 0, 'cảm-tình', '', '', 'cảm tình'), 
(1366, 0, 'thế-là', '', '', 'thế là'), 
(1367, 0, 'đồng-ý', '', '', 'đồng ý'), 
(1368, 0, 'nói-dối', '', '', 'nói dối'), 
(1369, 0, 'cổ-lũng', '', '', 'cổ lũng'), 
(1370, 0, 'ba-thanh', '', '', 'ba thanh'), 
(1371, 0, 'lao-lý', '', '', 'lao lý'), 
(1372, 0, 'hồn-nhiên', '', '', 'hồn nhiên'), 
(1373, 0, 'bất-hảo', '', '', 'bất hảo'), 
(1374, 0, 'bàng-hoàng', '', '', 'bàng hoàng'), 
(1375, 0, 'ngoan-ngoãn', '', '', 'ngoan ngoãn'), 
(1376, 0, 'làm-ăn', '', '', 'làm ăn'), 
(1377, 0, 'chơi-bời', '', '', 'chơi bời'), 
(1378, 0, 'dễ-dãi', '', '', 'dễ dãi'), 
(1379, 0, 'dương-công', '', '', 'dương công'), 
(1380, 0, 'buồn-rầu', '', '', 'buồn rầu'), 
(1381, 0, 'thứ-hai', '', '', 'thứ hai'), 
(1382, 0, 'khuyên-nhủ', '', '', 'khuyên nhủ'), 
(1383, 0, 'thản-nhiên', '', '', 'thản nhiên'), 
(1384, 0, 'cơ-sở', '', '', 'cơ sở'), 
(1385, 0, 'gà-trống', '', '', 'gà trống'), 
(1386, 0, 'thiếu-thốn', '', '', 'thiếu thốn'), 
(1387, 0, 'thành-thử', '', '', 'thành thử'), 
(1388, 0, 'nhiều-chuyện', '', '', 'nhiều chuyện'), 
(1389, 0, 'sâu-kín', '', '', 'sâu kín'), 
(1390, 0, 'người-lạ', '', '', 'người lạ'), 
(1391, 0, 'thị-xã', '', '', 'thị xã'), 
(1392, 0, 'thừa-thiên-huế', '', '', 'thừa thiên huế'), 
(1393, 0, 'quả-tang', '', '', 'quả tang'), 
(1394, 0, 'tân-ninh', '', '', 'tân ninh'), 
(1395, 0, 'tân-thạnh', '', '', 'tân thạnh'), 
(1396, 0, 'con-ở', '', '', 'con ở'), 
(1397, 0, 'xuất-xứ', '', '', 'xuất xứ'), 
(1398, 0, 'lừa-đảo', '', '', 'lừa đảo'), 
(1399, 0, 'biên-bản', '', '', 'biên bản'), 
(1400, 0, 'đánh-lừa', '', '', 'đánh lừa'), 
(1401, 0, 'ấn-tượng', '', '', 'ấn tượng'), 
(1402, 0, 'quốc-tịch', '', '', 'quốc tịch'), 
(1403, 0, 'tài-khoản', '', '', 'tài khoản'), 
(1404, 0, 'giao-dịch', '', '', 'giao dịch'), 
(1405, 0, 'chiếm-đoạt', '', '', 'chiếm đoạt'), 
(1406, 0, 'hành-vi', '', '', 'hành vi'), 
(1407, 0, 'trường-đua', '', '', 'trường đua'), 
(1408, 0, 'sinh-sống', '', '', 'sinh sống'), 
(1409, 0, 'phi-vụ', '', '', 'phi vụ'), 
(1410, 0, 'mua-bán', '', '', 'mua bán'), 
(1411, 0, 'thủ-đoạn', '', '', 'thủ đoạn'), 
(1412, 0, 'gây-sự', '', '', 'gây sự'), 
(1413, 0, 'nhầm-lẫn', '', '', 'nhầm lẫn'), 
(1414, 0, 'nhập-khẩu', '', '', 'nhập khẩu'), 
(1415, 0, 'thủy-sản', '', '', 'thủy sản'), 
(1416, 0, 'tội-phạm', '', '', 'tội phạm'), 
(1417, 0, 'mù-quáng', '', '', 'mù quáng'), 
(1418, 0, 'cảnh-giác', '', '', 'cảnh giác'), 
(1419, 0, 'cao-độ', '', '', 'cao độ'), 
(1420, 0, 'ngọc-bích', '', '', 'ngọc bích'), 
(1421, 0, 'trị-giá', '', '', 'trị giá'), 
(1422, 0, 'nước-hoa', '', '', 'nước hoa'), 
(1423, 0, 'tự-xưng', '', '', 'tự xưng'), 
(1424, 0, 'nhắn-tin', '', '', 'nhắn tin'), 
(1425, 0, 'hồng-vân', '', '', 'hồng vân'), 
(1426, 0, 'mậu-dịch', '', '', 'mậu dịch'), 
(1427, 0, 'ngọc-lan', '', '', 'ngọc lan'), 
(1428, 0, 'xét-xử', '', '', 'xét xử'), 
(1429, 0, 'cáo-trạng', '', '', 'cáo trạng'), 
(1430, 0, 'truy-tố', '', '', 'truy tố'), 
(1431, 0, 'giày-dép', '', '', 'giày dép'), 
(1432, 0, 'thẩm-vấn', '', '', 'thẩm vấn'), 
(1433, 0, 'bồi-thường', '', '', 'bồi thường'), 
(1434, 0, 'linh-kiện', '', '', 'linh kiện'), 
(1435, 0, 'lệ-phí', '', '', 'lệ phí'), 
(1436, 0, 'kiểm-sát', '', '', 'kiểm sát'), 
(1437, 0, 'tử-tế', '', '', 'tử tế'), 
(1438, 0, 'người-yêu', '', '', 'người yêu'), 
(1439, 0, 'gặp-mặt', '', '', 'gặp mặt'), 
(1440, 0, 'từ-liêm', '', '', 'từ liêm'), 
(1441, 0, 'khẩn-cấp', '', '', 'khẩn cấp'), 
(1442, 0, 'hải-đăng', '', '', 'hải đăng'), 
(1443, 0, 'an-bình', '', '', 'an bình'), 
(1444, 0, 'tượng-sơn', '', '', 'tượng sơn'), 
(1445, 0, 'trái-phép', '', '', 'trái phép'), 
(1446, 0, 'máy-tính', '', '', 'máy tính'), 
(1447, 0, 'viễn-thông', '', '', 'viễn thông'), 
(1448, 0, 'luật-hình', '', '', 'luật hình'), 
(1449, 0, 'ký-túc', '', '', 'ký túc'), 
(1450, 0, 'công-nghiệp', '', '', 'công nghiệp'), 
(1451, 0, 'diễn-đàn', '', '', 'diễn đàn'), 
(1452, 0, 'tâm-lý', '', '', 'tâm lý'), 
(1453, 0, 'hoang-mang', '', '', 'hoang mang'), 
(1454, 0, 'giật-gân', '', '', 'giật gân'), 
(1455, 0, 'sự-thật', '', '', 'sự thật'), 
(1456, 0, 'chuyển-hướng', '', '', 'chuyển hướng'), 
(1457, 0, 'mục-đích', '', '', 'mục đích'), 
(1458, 0, 'quảng-cáo', '', '', 'quảng cáo'), 
(1459, 0, 'khiêu-dâm', '', '', 'khiêu dâm'), 
(1460, 0, 'bình-thắng', '', '', 'bình thắng'), 
(1461, 0, 'tân-phú-đông', '', '', 'tân phú đông'), 
(1462, 0, 'tiền-giang', '', '', 'tiền giang'), 
(1463, 0, 'thuyền-trưởng', '', '', 'thuyền trưởng'), 
(1464, 0, 'bàn-giao', '', '', 'bàn giao'), 
(1465, 0, 'xe-đạp', '', '', 'xe đạp'), 
(1466, 0, 'ăn-trộm', '', '', 'ăn trộm'), 
(1467, 0, 'tiền-tiêu', '', '', 'tiền tiêu'), 
(1468, 0, 'trộm-cắp', '', '', 'trộm cắp'), 
(1469, 0, 'quốc-văn', '', '', 'quốc văn'), 
(1470, 0, 'tam-thái', '', '', 'tam thái'), 
(1471, 0, 'xuân-phú', '', '', 'xuân phú'), 
(1472, 0, 'tụ-tập', '', '', 'tụ tập'), 
(1473, 0, 'sòng-bạc', '', '', 'sòng bạc'), 
(1474, 0, 'con-bạc', '', '', 'con bạc'), 
(1475, 0, 'sát-phạt', '', '', 'sát phạt'), 
(1476, 0, 'khống-chế', '', '', 'khống chế'), 
(1477, 0, 'tang-vật', '', '', 'tang vật'), 
(1478, 0, 'mô-tô', '', '', 'mô tô'), 
(1479, 0, 'gá-bạc', '', '', 'gá bạc'), 
(1480, 0, 'tết-nguyên-đán', '', '', 'tết nguyên đán'), 
(1481, 0, 'ma-túy', '', '', 'ma túy'), 
(1482, 0, 'thanh-oai', '', '', 'thanh oai'), 
(1483, 0, 'trinh-sát', '', '', 'trinh sát'), 
(1484, 0, 'tàng-trữ', '', '', 'tàng trữ'), 
(1485, 0, 'bạch-mai', '', '', 'bạch mai'), 
(1486, 0, 'nhà-ở', '', '', 'nhà ở'), 
(1487, 0, 'giáp-ranh', '', '', 'giáp ranh'), 
(1488, 0, 'quận-huyện', '', '', 'quận huyện'), 
(1489, 0, 'tẩu-thoát', '', '', 'tẩu thoát'), 
(1490, 0, 'bảo-quản', '', '', 'bảo quản'), 
(1491, 0, 'thủ-phạm', '', '', 'thủ phạm'), 
(1492, 0, 'tin-đồn', '', '', 'tin đồn'), 
(1493, 0, 'anh-tuấn', '', '', 'anh tuấn'), 
(1494, 0, 'trạng-thái', '', '', 'trạng thái'), 
(1495, 0, 'cư-dân', '', '', 'cư dân'), 
(1496, 0, 'trâm-anh', '', '', 'trâm anh'), 
(1497, 0, 'phát-tán', '', '', 'phát tán'), 
(1498, 0, 'thao-tác', '', '', 'thao tác'), 
(1499, 0, 'đại-gia', '', '', 'đại gia'), 
(1500, 0, 'sẵn-sàng', '', '', 'sẵn sàng'), 
(1501, 0, 'bất-chính', '', '', 'bất chính'), 
(1502, 0, 'can-lộc', '', '', 'can lộc'), 
(1503, 0, 'thạch-đỉnh', '', '', 'thạch đỉnh'), 
(1504, 0, 'thạch-hà', '', '', 'thạch hà'), 
(1505, 0, 'vĩnh-long', '', '', 'vĩnh long'), 
(1506, 0, 'tiến-lộc', '', '', 'tiến lộc'), 
(1507, 0, 'xuân-trường', '', '', 'xuân trường'), 
(1508, 0, 'yên-đức', '', '', 'yên đức'), 
(1509, 0, 'thế-công', '', '', 'thế công'), 
(1510, 0, 'thiên-lộc', '', '', 'thiên lộc'), 
(1511, 0, 'xuân-lam', '', '', 'xuân lam'), 
(1512, 0, 'tiêu-xài', '', '', 'tiêu xài'), 
(1513, 0, 'trốn-tránh', '', '', 'trốn tránh'), 
(1514, 0, 'bình-dương', '', '', 'bình dương'), 
(1515, 0, 'lợi-dụng', '', '', 'lợi dụng'), 
(1516, 0, 'nhẹ-dạ', '', '', 'nhẹ dạ'), 
(1517, 0, 'dính-dáng', '', '', 'dính dáng'), 
(1518, 0, 'ngay-tức-khắc', '', '', 'ngay tức khắc'), 
(1519, 0, 'kịch-bản', '', '', 'kịch bản'), 
(1520, 0, 'tiếng-động', '', '', 'tiếng động'), 
(1521, 0, 'sơ-thẩm', '', '', 'sơ thẩm'), 
(1522, 0, 'tố-giác', '', '', 'tố giác'), 
(1523, 0, 'nhập-cảnh', '', '', 'nhập cảnh'), 
(1524, 0, 'cố-định', '', '', 'cố định'), 
(1525, 0, 'tiền-của', '', '', 'tiền của'), 
(1526, 0, 'tòa-án', '', '', 'tòa án'), 
(1527, 0, 'tổng-đài', '', '', 'tổng đài'), 
(1528, 0, 'thiếu-úy', '', '', 'thiếu úy'), 
(1529, 0, 'hoảng-sợ', '', '', 'hoảng sợ'), 
(1530, 0, 'thủy-tiên', '', '', 'thủy tiên'), 
(1531, 0, 'tù-treo', '', '', 'tù treo'), 
(1532, 0, 'trang-phục', '', '', 'trang phục'), 
(1533, 0, 'nhân-vật', '', '', 'nhân vật'), 
(1534, 0, 'bí-ẩn', '', '', 'bí ẩn'), 
(1535, 0, 'khác-thường', '', '', 'khác thường'), 
(1536, 0, 'họ-hàng', '', '', 'họ hàng'), 
(1537, 0, 'xổ-số', '', '', 'xổ số'), 
(1538, 0, 'giải-thưởng', '', '', 'giải thưởng'), 
(1539, 0, 'sơn-tây', '', '', 'sơn tây'), 
(1540, 0, 'kể-trên', '', '', 'kể trên'), 
(1541, 0, 'bộ-hành', '', '', 'bộ hành'), 
(1542, 0, 'bài-học', '', '', 'bài học'), 
(1543, 0, 'ngậm-ngùi', '', '', 'ngậm ngùi'), 
(1544, 0, 'ngón-tay-giữa', '', '', 'ngón tay giữa'), 
(1545, 0, 'chế-giễu', '', '', 'chế giễu'), 
(1546, 0, 'xúc-phạm', '', '', 'xúc phạm'), 
(1547, 0, 'cặp-đôi', '', '', 'cặp đôi'), 
(1548, 0, 'cô-dâu', '', '', 'cô dâu'), 
(1549, 0, 'lộng-lẫy', '', '', 'lộng lẫy'), 
(1550, 0, 'nhẹ-nhàng', '', '', 'nhẹ nhàng'), 
(1551, 0, 'phá-kỷ-lục', '', '', 'phá kỷ lục'), 
(1552, 0, 'đám-cưới', '', '', 'đám cưới'), 
(1553, 0, 'sở-khanh', '', '', 'sở khanh'), 
(1554, 0, 'gặp-gỡ', '', '', 'gặp gỡ'), 
(1555, 0, 'nấu-nướng', '', '', 'nấu nướng'), 
(1556, 0, 'độc-thân', '', '', 'độc thân'), 
(1557, 0, 'câu-lạc-bộ', '', '', 'câu lạc bộ'), 
(1558, 0, 'có-vẻ', '', '', 'có vẻ'), 
(1559, 0, 'hẹn-hò', '', '', 'hẹn hò'), 
(1560, 0, 'nhiếp-ảnh', '', '', 'nhiếp ảnh'), 
(1561, 0, 'thời-trang', '', '', 'thời trang'), 
(1562, 0, 'hơi-hướng', '', '', 'hơi hướng'), 
(1563, 0, 'lãng-mạn', '', '', 'lãng mạn'), 
(1564, 0, 'kết-bạn', '', '', 'kết bạn'), 
(1565, 0, 'tình-tứ', '', '', 'tình tứ'), 
(1566, 0, 'tán-gẫu', '', '', 'tán gẫu'), 
(1567, 0, 'lứa-tuổi', '', '', 'lứa tuổi'), 
(1568, 0, 'lái-xe', '', '', 'lái xe'), 
(1569, 0, 'ngỏ-lời', '', '', 'ngỏ lời'), 
(1570, 0, 'thưởng-thức', '', '', 'thưởng thức'), 
(1571, 0, 'giãi-bày', '', '', 'giãi bày'), 
(1572, 0, 'tay-chơi', '', '', 'tay chơi'), 
(1573, 0, 'đồ-nghề', '', '', 'đồ nghề'), 
(1574, 0, 'máy-ảnh', '', '', 'máy ảnh'), 
(1575, 0, 'tình-nhân', '', '', 'tình nhân'), 
(1576, 0, 'khách-địa', '', '', 'khách địa'), 
(1577, 0, 'đi-dạo', '', '', 'đi dạo'), 
(1578, 0, 'mua-sắm', '', '', 'mua sắm'), 
(1579, 0, 'thú-vị', '', '', 'thú vị'), 
(1580, 0, 'nhất-nhất', '', '', 'nhất nhất'), 
(1581, 0, 'nhận-lời', '', '', 'nhận lời'), 
(1582, 0, 'nghỉ-ngơi', '', '', 'nghỉ ngơi'), 
(1583, 0, 'dằng-dặc', '', '', 'dằng dặc'), 
(1584, 0, 'từ-thiện', '', '', 'từ thiện'), 
(1585, 0, 'phiêu-lưu', '', '', 'phiêu lưu'), 
(1586, 0, 'lợi-nhuận', '', '', 'lợi nhuận'), 
(1587, 0, 'ban-ngày', '', '', 'ban ngày'), 
(1588, 0, 'tình-cờ', '', '', 'tình cờ'), 
(1589, 0, 'nhà-văn', '', '', 'nhà văn'), 
(1590, 0, 'tinh-nghịch', '', '', 'tinh nghịch'), 
(1591, 0, 'xứng-đáng', '', '', 'xứng đáng'), 
(1592, 0, 'cân-nhắc', '', '', 'cân nhắc'), 
(1593, 0, 'từ-chối', '', '', 'từ chối'), 
(1594, 0, 'nghỉ-việc', '', '', 'nghỉ việc'), 
(1595, 0, 'nhà-máy', '', '', 'nhà máy'), 
(1596, 0, 'thu-nhập', '', '', 'thu nhập'), 
(1597, 0, 'tốt-đẹp', '', '', 'tốt đẹp'), 
(1598, 0, 'hảo-tâm', '', '', 'hảo tâm'), 
(1599, 0, 'thái-độ', '', '', 'thái độ'), 
(1600, 0, 'hàng-xóm', '', '', 'hàng xóm'), 
(1601, 0, 'mồ-côi', '', '', 'mồ côi'), 
(1602, 0, 'ngay-cả', '', '', 'ngay cả'), 
(1603, 0, 'ngớ-ngẩn', '', '', 'ngớ ngẩn'), 
(1604, 0, 'nhìn-nhận', '', '', 'nhìn nhận'), 
(1605, 0, 'gầy-gò', '', '', 'gầy gò'), 
(1606, 0, 'mảnh-dẻ', '', '', 'mảnh dẻ'), 
(1607, 0, 'xúc-xích', '', '', 'xúc xích'), 
(1608, 0, 'no-nê', '', '', 'no nê'), 
(1609, 0, 'nhặt-nhạnh', '', '', 'nhặt nhạnh'), 
(1610, 0, 'thức-ăn', '', '', 'thức ăn'), 
(1611, 0, 'tỏ-vẻ', '', '', 'tỏ vẻ'), 
(1612, 0, 'hài-lòng', '', '', 'hài lòng'), 
(1613, 0, 'tồi-tệ', '', '', 'tồi tệ'), 
(1614, 0, 'phóng-xạ', '', '', 'phóng xạ'), 
(1615, 0, 'tàn-phá', '', '', 'tàn phá'), 
(1616, 0, 'phá-vỡ', '', '', 'phá vỡ'), 
(1617, 0, 'lộ-diện', '', '', 'lộ diện'), 
(1618, 0, 'buộc-tội', '', '', 'buộc tội'), 
(1619, 0, 'ngoại-tình', '', '', 'ngoại tình'), 
(1620, 0, 'tò-mò', '', '', 'tò mò'), 
(1621, 0, 'thiên-thần', '', '', 'thiên thần'), 
(1622, 0, 'khoảnh-khắc', '', '', 'khoảnh khắc'), 
(1623, 0, 'chiêm-ngưỡng', '', '', 'chiêm ngưỡng'), 
(1624, 0, 'cảm-xúc', '', '', 'cảm xúc'), 
(1625, 0, 'tuyệt-vời', '', '', 'tuyệt vời'), 
(1626, 0, 'cám-ơn', '', '', 'cám ơn'), 
(1627, 0, 'khỏe-mạnh', '', '', 'khỏe mạnh'), 
(1628, 0, 'tri-kỷ', '', '', 'tri kỷ'), 
(1629, 0, 'tâm-trạng', '', '', 'tâm trạng'), 
(1630, 0, 'khóc-thầm', '', '', 'khóc thầm'), 
(1631, 0, 'héo-hắt', '', '', 'héo hắt'), 
(1632, 0, 'cầu-cứu', '', '', 'cầu cứu'), 
(1633, 0, 'trẻ-ranh', '', '', 'trẻ ranh'), 
(1634, 0, 'luật-sư', '', '', 'luật sư'), 
(1635, 0, 'trình-bày', '', '', 'trình bày'), 
(1636, 0, 'trang-trải', '', '', 'trang trải'), 
(1637, 0, 'thiết-yếu', '', '', 'thiết yếu'), 
(1638, 0, 'thám-tử', '', '', 'thám tử'), 
(1639, 0, 'ly-hôn', '', '', 'ly hôn'), 
(1640, 0, 'ra-tòa', '', '', 'ra tòa'), 
(1641, 0, 'nhân-tình', '', '', 'nhân tình'), 
(1642, 0, 'làm-phiền', '', '', 'làm phiền'), 
(1643, 0, 'kế-toán', '', '', 'kế toán'), 
(1644, 0, 'hùng-hổ', '', '', 'hùng hổ'), 
(1645, 0, 'chấp-thuận', '', '', 'chấp thuận'), 
(1646, 0, 'tiết-lộ', '', '', 'tiết lộ'), 
(1647, 0, 'tin-tức', '', '', 'tin tức'), 
(1648, 0, 'qui-định', '', '', 'qui định'), 
(1649, 0, 'chu-cấp', '', '', 'chu cấp'), 
(1650, 0, 'nhan-sắc', '', '', 'nhan sắc'), 
(1651, 0, 'nói-thật', '', '', 'nói thật'), 
(1652, 0, 'thông-cảm', '', '', 'thông cảm'), 
(1653, 0, 'năn-nỉ', '', '', 'năn nỉ'), 
(1654, 0, 'xin-lỗi', '', '', 'xin lỗi'), 
(1655, 0, 'cương-quyết', '', '', 'cương quyết'), 
(1656, 0, 'chu-đáo', '', '', 'chu đáo'), 
(1657, 0, 'hạn-hẹp', '', '', 'hạn hẹp'), 
(1658, 0, 'loanh-quanh', '', '', 'loanh quanh'), 
(1659, 0, 'xinh-đẹp', '', '', 'xinh đẹp'), 
(1660, 0, 'hấp-dẫn', '', '', 'hấp dẫn'), 
(1661, 0, 'thăm-viếng', '', '', 'thăm viếng'), 
(1662, 0, 'gia-hạn', '', '', 'gia hạn'), 
(1663, 0, 'bình-tâm', '', '', 'bình tâm'), 
(1664, 0, 'trước-kia', '', '', 'trước kia'), 
(1665, 0, 'rành-mạch', '', '', 'rành mạch'), 
(1666, 0, 'sóng-gió', '', '', 'sóng gió'), 
(1667, 0, 'thói-quen', '', '', 'thói quen'), 
(1668, 0, 'đề-huề', '', '', 'đề huề'), 
(1669, 0, 'con-nước', '', '', 'con nước'), 
(1670, 0, 'tự-ái', '', '', 'tự ái'), 
(1671, 0, 'yếu-đuối', '', '', 'yếu đuối'), 
(1672, 0, 'trung-học', '', '', 'trung học'), 
(1673, 0, 'quân-nhân', '', '', 'quân nhân'), 
(1674, 0, 'ngắn-ngủi', '', '', 'ngắn ngủi'), 
(1675, 0, 'nghỉ-phép', '', '', 'nghỉ phép'), 
(1676, 0, 'món-ăn', '', '', 'món ăn'), 
(1677, 0, 'ngay-ngắn', '', '', 'ngay ngắn'), 
(1678, 0, 'tủ-lạnh', '', '', 'tủ lạnh'), 
(1679, 0, 'qua-loa', '', '', 'qua loa'), 
(1680, 0, 'tươm-tất', '', '', 'tươm tất'), 
(1681, 0, 'khoai-tây', '', '', 'khoai tây'), 
(1682, 0, 'manh-mối', '', '', 'manh mối'), 
(1683, 0, 'phần-thưởng', '', '', 'phần thưởng'), 
(1684, 0, 'quảng-đông', '', '', 'quảng đông'), 
(1685, 0, 'bàn-tán', '', '', 'bàn tán'), 
(1686, 0, 'dòm-ngó', '', '', 'dòm ngó'), 
(1687, 0, 'ngon-miệng', '', '', 'ngon miệng'), 
(1688, 0, 'tận-tình', '', '', 'tận tình'), 
(1689, 0, 'chối-từ', '', '', 'chối từ'), 
(1690, 0, 'dinh-dưỡng', '', '', 'dinh dưỡng'), 
(1691, 0, 'thân-hình', '', '', 'thân hình'), 
(1692, 0, 'phì-nộn', '', '', 'phì nộn'), 
(1693, 0, 'trông-thấy', '', '', 'trông thấy'), 
(1694, 0, 'gọn-gàng', '', '', 'gọn gàng'), 
(1695, 0, 'tiêu-chuẩn', '', '', 'tiêu chuẩn'), 
(1696, 0, 'cầu-hôn', '', '', 'cầu hôn'), 
(1697, 0, 'cạnh-tranh', '', '', 'cạnh tranh'), 
(1698, 0, 'vỗ-béo', '', '', 'vỗ béo'), 
(1699, 0, 'trái-tim', '', '', 'trái tim'), 
(1700, 0, 'dạ-dày', '', '', 'dạ dày'), 
(1701, 0, 'châm-ngôn', '', '', 'châm ngôn'), 
(1702, 0, 'để-ý', '', '', 'để ý'), 
(1703, 0, 'tình-cảm', '', '', 'tình cảm'), 
(1704, 0, 'quen-thân', '', '', 'quen thân'), 
(1705, 0, 'nấu-ăn', '', '', 'nấu ăn'), 
(1706, 0, 'lục-đục', '', '', 'lục đục'), 
(1707, 0, 'nguội-lạnh', '', '', 'nguội lạnh'), 
(1708, 0, 'ở-đời', '', '', 'ở đời'), 
(1709, 0, 'triệt-để', '', '', 'triệt để'), 
(1710, 0, 'vì-sao', '', '', 'vì sao'), 
(1711, 0, 'càu-nhàu', '', '', 'càu nhàu'), 
(1712, 0, 'quát-mắng', '', '', 'quát mắng'), 
(1713, 0, 'thanh-minh', '', '', 'thanh minh'), 
(1714, 0, 'chê-bai', '', '', 'chê bai'), 
(1715, 0, 'cao-lương', '', '', 'cao lương'), 
(1716, 0, 'mỹ-vị', '', '', 'mỹ vị'), 
(1717, 0, 'phê-bình', '', '', 'phê bình'), 
(1718, 0, 'ẩm-thực', '', '', 'ẩm thực'), 
(1719, 0, 'ngán-ngẩm', '', '', 'ngán ngẩm'), 
(1720, 0, 'thế-gian', '', '', 'thế gian'), 
(1721, 0, 'tương-đối', '', '', 'tương đối'), 
(1722, 0, 'xa-xăm', '', '', 'xa xăm'), 
(1723, 0, 'khi-xưa', '', '', 'khi xưa'), 
(1724, 0, 'kêu-ca', '', '', 'kêu ca'), 
(1725, 0, 'lâu-nay', '', '', 'lâu nay'), 
(1726, 0, 'ngóc-ngách', '', '', 'ngóc ngách'), 
(1727, 0, 'thầm-thì', '', '', 'thầm thì'), 
(1728, 0, 'quên-mình', '', '', 'quên mình'), 
(1729, 0, 'xao-xuyến', '', '', 'xao xuyến'), 
(1730, 0, 'ngẫu-nhiên', '', '', 'ngẫu nhiên'), 
(1731, 0, 'vô-tình', '', '', 'vô tình'), 
(1732, 0, 'ngờ-đâu', '', '', 'ngờ đâu'), 
(1733, 0, 'vương-vấn', '', '', 'vương vấn'), 
(1734, 0, 'hoài-niệm', '', '', 'hoài niệm'), 
(1735, 0, 'nhắn-nhủ', '', '', 'nhắn nhủ'), 
(1736, 0, 'đa-mang', '', '', 'đa mang'), 
(1737, 0, 'nhỏ-nhặt', '', '', 'nhỏ nhặt'), 
(1738, 0, 'mỉm-cười', '', '', 'mỉm cười'), 
(1739, 0, 'tươi-tắn', '', '', 'tươi tắn'), 
(1740, 0, 'hôn-nhân', '', '', 'hôn nhân'), 
(1741, 0, 'lửa-tình', '', '', 'lửa tình'), 
(1742, 0, 'gặm-nhấm', '', '', 'gặm nhấm'), 
(1743, 0, 'khó-chịu', '', '', 'khó chịu'), 
(1744, 0, 'lặt-vặt', '', '', 'lặt vặt'), 
(1745, 0, 'hủy-hoại', '', '', 'hủy hoại'), 
(1746, 0, 'tranh-giành', '', '', 'tranh giành'), 
(1747, 0, 'ổn-thỏa', '', '', 'ổn thỏa'), 
(1748, 0, 'ác-cảm', '', '', 'ác cảm'), 
(1749, 0, 'tóm-lại', '', '', 'tóm lại'), 
(1750, 0, 'tha-thứ', '', '', 'tha thứ'), 
(1751, 0, 'nhỏ-nhen', '', '', 'nhỏ nhen'), 
(1752, 0, 'tan-vỡ', '', '', 'tan vỡ'), 
(1753, 0, 'kiềm-chế', '', '', 'kiềm chế'), 
(1754, 0, 'ưu-điểm', '', '', 'ưu điểm'), 
(1755, 0, 'chỉ-trích', '', '', 'chỉ trích'), 
(1756, 0, 'đức-tính', '', '', 'đức tính'), 
(1757, 0, 'ấm-áp', '', '', 'ấm áp'), 
(1758, 0, 'sơ-sài', '', '', 'sơ sài'), 
(1759, 0, 'thôn-quê', '', '', 'thôn quê'), 
(1760, 0, 'nuôi-dưỡng', '', '', 'nuôi dưỡng'), 
(1761, 0, 'khắc-khổ', '', '', 'khắc khổ'), 
(1762, 0, 'lo-nghĩ', '', '', 'lo nghĩ'), 
(1763, 0, 'lãng-phí', '', '', 'lãng phí'), 
(1764, 0, 'tiết-kiệm', '', '', 'tiết kiệm'), 
(1765, 0, 'bủn-xỉn', '', '', 'bủn xỉn'), 
(1766, 0, 'giật-mình', '', '', 'giật mình'), 
(1767, 0, 'xa-lạ', '', '', 'xa lạ'), 
(1768, 0, 'khách-hàng', '', '', 'khách hàng'), 
(1769, 0, 'bông-đùa', '', '', 'bông đùa'), 
(1770, 0, 'trêu-ghẹo', '', '', 'trêu ghẹo'), 
(1771, 0, 'sàn-sạt', '', '', 'sàn sạt'), 
(1772, 0, 'rung-động', '', '', 'rung động'), 
(1773, 0, 'e-ấp', '', '', 'e ấp'), 
(1774, 0, 'dịu-dàng', '', '', 'dịu dàng'), 
(1775, 0, 'mềm-mại', '', '', 'mềm mại'), 
(1776, 0, 'tâm-hồn', '', '', 'tâm hồn'), 
(1777, 0, 'thở-dài', '', '', 'thở dài'), 
(1778, 0, 'nho-nhỏ', '', '', 'nho nhỏ'), 
(1779, 0, 'thở-than', '', '', 'thở than'), 
(1780, 0, 'chiêm-bao', '', '', 'chiêm bao'), 
(1781, 0, 'giải-trí', '', '', 'giải trí'), 
(1782, 0, 'lăn-tăn', '', '', 'lăn tăn'), 
(1783, 0, 'sống-sượng', '', '', 'sống sượng'), 
(1784, 0, 'phân-vân', '', '', 'phân vân'), 
(1785, 0, 'do-dự', '', '', 'do dự'), 
(1786, 0, 'mủi-lòng', '', '', 'mủi lòng'), 
(1787, 0, 'quân-tử', '', '', 'quân tử'), 
(1788, 0, 'tha-hồ', '', '', 'tha hồ'), 
(1789, 0, 'ngẩn-ngơ', '', '', 'ngẩn ngơ'), 
(1790, 0, 'so-sánh', '', '', 'so sánh'), 
(1791, 0, 'tận-tụy', '', '', 'tận tụy'), 
(1792, 0, 'phàn-nàn', '', '', 'phàn nàn'), 
(1793, 0, 'tượng-trưng', '', '', 'tượng trưng'), 
(1794, 0, 'hớn-hở', '', '', 'hớn hở'), 
(1795, 0, 'tâm-niệm', '', '', 'tâm niệm'), 
(1796, 0, 'nhà-riêng', '', '', 'nhà riêng'), 
(1797, 0, 'hiện-thực', '', '', 'hiện thực'), 
(1798, 0, 'giống-hệt', '', '', 'giống hệt'), 
(1799, 0, 'khái-niệm', '', '', 'khái niệm'), 
(1800, 0, 'êm-ái', '', '', 'êm ái'), 
(1801, 0, 'định-nghĩa', '', '', 'định nghĩa'), 
(1802, 0, 'giảm-nhẹ', '', '', 'giảm nhẹ'), 
(1803, 0, 'đau-đớn', '', '', 'đau đớn'), 
(1804, 0, 'tự-tử', '', '', 'tự tử'), 
(1805, 0, 'phân-loại', '', '', 'phân loại'), 
(1806, 0, 'kháng-sinh', '', '', 'kháng sinh'), 
(1807, 0, 'hôn-mê', '', '', 'hôn mê'), 
(1808, 0, 'tổn-thương', '', '', 'tổn thương'), 
(1809, 0, 'tùy-theo', '', '', 'tùy theo'), 
(1810, 0, 'tự-chủ', '', '', 'tự chủ'), 
(1811, 0, 'phần-nào', '', '', 'phần nào'), 
(1812, 0, 'bào-chữa', '', '', 'bào chữa'), 
(1813, 0, 'tâm-linh', '', '', 'tâm linh'), 
(1814, 0, 'tiếng-nói', '', '', 'tiếng nói'), 
(1815, 0, 'ba-tiêu', '', '', 'ba tiêu'), 
(1816, 0, 'tâm-thần', '', '', 'tâm thần'), 
(1817, 0, 'nhất-trí', '', '', 'nhất trí'), 
(1818, 0, 'triển-vọng', '', '', 'triển vọng'), 
(1819, 0, 'phạm-pháp', '', '', 'phạm pháp'), 
(1820, 0, 'ngộ-sát', '', '', 'ngộ sát'), 
(1821, 0, 'cố-sát', '', '', 'cố sát'), 
(1822, 0, 'chung-thân', '', '', 'chung thân'), 
(1823, 0, 'tự-sát', '', '', 'tự sát'), 
(1824, 0, 'nóng-sốt', '', '', 'nóng sốt'), 
(1825, 0, 'hội-chẩn', '', '', 'hội chẩn'), 
(1826, 0, 'phẫu-thuật', '', '', 'phẫu thuật'), 
(1827, 0, 'thời-kỳ', '', '', 'thời kỳ'), 
(1828, 0, 'khả-quan', '', '', 'khả quan'), 
(1829, 0, 'biến-chứng', '', '', 'biến chứng'), 
(1830, 0, 'tạo-hình', '', '', 'tạo hình'), 
(1831, 0, 'thẩm-mỹ', '', '', 'thẩm mỹ'), 
(1832, 0, 'khuyến-cáo', '', '', 'khuyến cáo'), 
(1833, 0, 'kịp-thời', '', '', 'kịp thời'), 
(1834, 0, 'cách-duy', '', '', 'cách duy'), 
(1835, 0, 'tiêu-dùng', '', '', 'tiêu dùng'), 
(1836, 0, 'ngoài-trời', '', '', 'ngoài trời'), 
(1837, 0, 'ngăn-ngừa', '', '', 'ngăn ngừa'), 
(1838, 0, 'vi-khuẩn', '', '', 'vi khuẩn'), 
(1839, 0, 'mầm-bệnh', '', '', 'mầm bệnh'), 
(1840, 0, 'tách-biệt', '', '', 'tách biệt'), 
(1841, 0, 'ăn-sống', '', '', 'ăn sống'), 
(1842, 0, 'chế-biến', '', '', 'chế biến'), 
(1843, 0, 'thị-uy', '', '', 'thị uy'), 
(1844, 0, 'loại-bỏ', '', '', 'loại bỏ'), 
(1845, 0, 'lâu-ngày', '', '', 'lâu ngày'), 
(1846, 0, 'sản-sinh', '', '', 'sản sinh'), 
(1847, 0, 'phá-hủy', '', '', 'phá hủy'), 
(1848, 0, 'loại-trừ', '', '', 'loại trừ'), 
(1849, 0, 'thực-quản', '', '', 'thực quản'), 
(1850, 0, 'tác-động', '', '', 'tác động'), 
(1851, 0, 'thần-kinh', '', '', 'thần kinh'), 
(1852, 0, 'lo-âu', '', '', 'lo âu'), 
(1853, 0, 'ức-chế', '', '', 'ức chế'), 
(1854, 0, 'hô-hấp', '', '', 'hô hấp'), 
(1855, 0, 'rượu-bia', '', '', 'rượu bia'), 
(1856, 0, 'tác-nhân', '', '', 'tác nhân'), 
(1857, 0, 'phấn-chấn', '', '', 'phấn chấn'), 
(1858, 0, 'động-tác', '', '', 'động tác'), 
(1859, 0, 'phản-xạ', '', '', 'phản xạ'), 
(1860, 0, 'ước-lượng', '', '', 'ước lượng'), 
(1861, 0, 'nên-người', '', '', 'nên người'), 
(1862, 0, 'kích-động', '', '', 'kích động'), 
(1863, 0, 'ẩu-đả', '', '', 'ẩu đả'), 
(1864, 0, 'phần-nhiều', '', '', 'phần nhiều'), 
(1865, 0, 'y-học', '', '', 'y học'), 
(1866, 0, 'thuật-ngữ', '', '', 'thuật ngữ'), 
(1867, 0, 'hội-chứng', '', '', 'hội chứng'), 
(1868, 0, 'ám-chỉ', '', '', 'ám chỉ'), 
(1869, 0, 'tiêu-thụ', '', '', 'tiêu thụ'), 
(1870, 0, 'ngủ-gà', '', '', 'ngủ gà'), 
(1871, 0, 'lẫn-lộn', '', '', 'lẫn lộn'), 
(1872, 0, 'bất-động', '', '', 'bất động'), 
(1873, 0, 'tư-thế', '', '', 'tư thế'), 
(1874, 0, 'hạ-đường', '', '', 'hạ đường'), 
(1875, 0, 'thu-hẹp', '', '', 'thu hẹp'), 
(1876, 0, 'đồng-tử', '', '', 'đồng tử'), 
(1877, 0, 'huyết-áp', '', '', 'huyết áp'), 
(1878, 0, 'tạp-chất', '', '', 'tạp chất'), 
(1879, 0, 'thận-trọng', '', '', 'thận trọng'), 
(1880, 0, 'quá-chén', '', '', 'quá chén'), 
(1881, 0, 'tai-biến', '', '', 'tai biến'), 
(1882, 0, 'tác-hại', '', '', 'tác hại'), 
(1883, 0, 'nhiệt-đới', '', '', 'nhiệt đới'), 
(1884, 0, 'hành-quân', '', '', 'hành quân'), 
(1885, 0, 'hiên-ngang', '', '', 'hiên ngang'), 
(1886, 0, 'ông-bà', '', '', 'ông bà'), 
(1887, 0, 'năm-xưa', '', '', 'năm xưa'), 
(1888, 0, 'hội-tụ', '', '', 'hội tụ'), 
(1889, 0, 'oanh-liệt', '', '', 'oanh liệt'), 
(1890, 0, 'bà-con', '', '', 'bà con'), 
(1891, 0, 'tư-trang', '', '', 'tư trang'), 
(1892, 0, 'càn-quét', '', '', 'càn quét'), 
(1893, 0, 'áp-lực', '', '', 'áp lực'), 
(1894, 0, 'phục-kích', '', '', 'phục kích'), 
(1895, 0, 'đồng-chí', '', '', 'đồng chí'), 
(1896, 0, 'đồng-bào', '', '', 'đồng bào'), 
(1897, 0, 'ruột-thịt', '', '', 'ruột thịt'), 
(1898, 0, 'trường-sơn', '', '', 'trường sơn'), 
(1899, 0, 'dụng-cụ', '', '', 'dụng cụ'), 
(1900, 0, 'tĩnh-mạch', '', '', 'tĩnh mạch'), 
(1901, 0, 'bàn-mổ', '', '', 'bàn mổ'), 
(1902, 0, 'đèn-pin', '', '', 'đèn pin'), 
(1903, 0, 'cá-nhân', '', '', 'cá nhân'), 
(1904, 0, 'gang-tấc', '', '', 'gang tấc'), 
(1905, 0, 'trận-địa', '', '', 'trận địa'), 
(1906, 0, 'thạch-sùng', '', '', 'thạch sùng'), 
(1907, 0, 'miễn-dịch', '', '', 'miễn dịch'), 
(1908, 0, 'khó-thở', '', '', 'khó thở'), 
(1909, 0, 'thuốc-nam', '', '', 'thuốc nam'), 
(1910, 0, 'mách-bảo', '', '', 'mách bảo'), 
(1911, 0, 'lên-cơn', '', '', 'lên cơn'), 
(1912, 0, 'gia-truyền', '', '', 'gia truyền'), 
(1913, 0, 'toàn-thân', '', '', 'toàn thân'), 
(1914, 0, 'tiếp-nhận', '', '', 'tiếp nhận'), 
(1915, 0, 'rỉ-tai', '', '', 'rỉ tai'), 
(1916, 0, 'thần-dược', '', '', 'thần dược'), 
(1917, 0, 'kinh-dị', '', '', 'kinh dị'), 
(1918, 0, 'giun-đất', '', '', 'giun đất'), 
(1919, 0, 'trị-bệnh', '', '', 'trị bệnh'), 
(1920, 0, 'thuyên-giảm', '', '', 'thuyên giảm'), 
(1921, 0, 'sinh-dục', '', '', 'sinh dục'), 
(1922, 0, 'lạm-dụng', '', '', 'lạm dụng'), 
(1923, 0, 'quý-châu', '', '', 'quý châu'), 
(1924, 0, 'tái-phát', '', '', 'tái phát'), 
(1925, 0, 'thuốc-lá', '', '', 'thuốc lá'), 
(1926, 0, 'lang-vườn', '', '', 'lang vườn'), 
(1927, 0, 'khởi-phát', '', '', 'khởi phát'), 
(1928, 0, 'súc-vật', '', '', 'súc vật'), 
(1929, 0, 'chỉ-định', '', '', 'chỉ định'), 
(1930, 0, 'đôi-khi', '', '', 'đôi khi'), 
(1931, 0, 'khò-khè', '', '', 'khò khè'), 
(1932, 0, 'đầy-đủ', '', '', 'đầy đủ'), 
(1933, 0, 'tập-thể', '', '', 'tập thể'), 
(1934, 0, 'trưởng-phòng', '', '', 'trưởng phòng'), 
(1935, 0, 'tổng-số', '', '', 'tổng số'), 
(1936, 0, 'vi-phạm', '', '', 'vi phạm'), 
(1937, 0, 'súp-lơ', '', '', 'súp lơ'), 
(1938, 0, 'thăng-bằng', '', '', 'thăng bằng'), 
(1939, 0, 'thoái-hóa', '', '', 'thoái hóa'), 
(1940, 0, 'nguyên-liệu', '', '', 'nguyên liệu'), 
(1941, 0, 'bình-khánh', '', '', 'bình khánh'), 
(1942, 0, 'đột-xuất', '', '', 'đột xuất'), 
(1943, 0, 'bến-cát', '', '', 'bến cát'), 
(1944, 0, 'tân-hiệp', '', '', 'tân hiệp'), 
(1945, 0, 'tân-uyên', '', '', 'tân uyên'), 
(1946, 0, 'phân-chia', '', '', 'phân chia'), 
(1947, 0, 'bảo-hộ', '', '', 'bảo hộ'), 
(1948, 0, 'tiểu-học', '', '', 'tiểu học'), 
(1949, 0, 'âm-đạo', '', '', 'âm đạo'), 
(1950, 0, 'sản-khoa', '', '', 'sản khoa'), 
(1951, 0, 'huyết-học', '', '', 'huyết học'), 
(1952, 0, 'tử-cung', '', '', 'tử cung'), 
(1953, 0, 'toàn-phần', '', '', 'toàn phần'), 
(1954, 0, 'tái-tạo', '', '', 'tái tạo'), 
(1955, 0, 'sản-phụ', '', '', 'sản phụ'), 
(1956, 0, 'trợ-lý', '', '', 'trợ lý'), 
(1957, 0, 'nội-khoa', '', '', 'nội khoa'), 
(1958, 0, 'sàng-lọc', '', '', 'sàng lọc'), 
(1959, 0, 'lớn-tuổi', '', '', 'lớn tuổi'), 
(1960, 0, 'chi-phí', '', '', 'chi phí'), 
(1961, 0, 'toàn-cầu', '', '', 'toàn cầu'), 
(1962, 0, 'gia-tăng', '', '', 'gia tăng'), 
(1963, 0, 'khí-hậu', '', '', 'khí hậu'), 
(1964, 0, 'ô-nhiễm', '', '', 'ô nhiễm'), 
(1965, 0, 'lành-mạnh', '', '', 'lành mạnh'), 
(1966, 0, 'dân-cư', '', '', 'dân cư'), 
(1967, 0, 'phải-chi', '', '', 'phải chi'), 
(1968, 0, 'cho-phép', '', '', 'cho phép'), 
(1969, 0, 'khởi-công', '', '', 'khởi công'), 
(1970, 0, 'khẩn-trương', '', '', 'khẩn trương'), 
(1971, 0, 'nhân-dịp', '', '', 'nhân dịp'), 
(1972, 0, 'tuyên-truyền', '', '', 'tuyên truyền'), 
(1973, 0, 'phòng-bệnh', '', '', 'phòng bệnh'), 
(1974, 0, 'diện-tích', '', '', 'diện tích'), 
(1975, 0, 'tiền-đề', '', '', 'tiền đề'), 
(1976, 0, 'lâu-dài', '', '', 'lâu dài'), 
(1977, 0, 'tiến-tới', '', '', 'tiến tới'), 
(1978, 0, 'phong-cách', '', '', 'phong cách'), 
(1979, 0, 'nhu-cầu', '', '', 'nhu cầu'), 
(1980, 1, 'đại-hội-đảng-xii', '', '', 'đại hội đảng XII'), 
(1981, 1, 'đại-hội-đảng', '', '', 'đại hội Đảng'), 
(1982, 2, 'hướng-nghiệp', '', '', 'hướng nghiệp'), 
(1983, 2, 'cntt', '', '', 'cntt'), 
(1984, 1, 'trung-cap-dak-lak', '', '', 'trung cap dak lak'), 
(1985, 2, 'k6ct1', '', '', 'k6ct1');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_tags_id`
--

DROP TABLE IF EXISTS `ctypa_vi_news_tags_id`;
CREATE TABLE `ctypa_vi_news_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65) NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_news_tags_id`
--

INSERT INTO `ctypa_vi_news_tags_id` VALUES
(84, 1985, 'K6CT1'), 
(84, 1984, 'trung cap dak lak'), 
(84, 1236, 'khai giảng'), 
(83, 1983, 'cntt'), 
(83, 1982, 'hướng nghiệp'), 
(82, 1983, 'cntt'), 
(82, 1982, 'hướng nghiệp'), 
(79, 1981, 'đại hội Đảng'), 
(79, 1980, 'đại hội đảng XII');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_news_topics`
--

DROP TABLE IF EXISTS `ctypa_vi_news_topics`;
CREATE TABLE `ctypa_vi_news_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_page`
--

DROP TABLE IF EXISTS `ctypa_vi_page`;
CREATE TABLE `ctypa_vi_page` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_page_config`
--

DROP TABLE IF EXISTS `ctypa_vi_page_config`;
CREATE TABLE `ctypa_vi_page_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_page_config`
--

INSERT INTO `ctypa_vi_page_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_photo_album`
--

DROP TABLE IF EXISTS `ctypa_vi_photo_album`;
CREATE TABLE `ctypa_vi_photo_album` (
  `album_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `model` varchar(255) NOT NULL DEFAULT '',
  `capturedate` varchar(255) NOT NULL DEFAULT '0',
  `capturelocal` varchar(255) NOT NULL DEFAULT '',
  `folder` varchar(255) NOT NULL DEFAULT '',
  `layout` varchar(50) NOT NULL DEFAULT '',
  `num_photo` mediumint(3) unsigned NOT NULL DEFAULT '0',
  `viewed` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `favorite` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `groups_view` varchar(255) DEFAULT '',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  `date_modified` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`album_id`),
  KEY `category_id` (`category_id`),
  KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_photo_category`
--

DROP TABLE IF EXISTS `ctypa_vi_photo_category`;
CREATE TABLE `ctypa_vi_photo_category` (
  `category_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort_order` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `layout` varchar(50) NOT NULL DEFAULT '',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `num_album` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  `date_modified` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_photo_category`
--

INSERT INTO `ctypa_vi_photo_category` VALUES
(1, 0, 'Hình ảnh hoạt động', 'hinh-anh-hoat-dong', '', 'Nukeviet', 'nukeviet, module nukeviet, theme nukeviet', 'nukeviet, module nukeviet, theme nukeviet', 1, 1, 0, '', 'viewcat_grid', 0, '', 1, 1, 4, 1, '6', 1430462351, 1430462351);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_photo_favorite`
--

DROP TABLE IF EXISTS `ctypa_vi_photo_favorite`;
CREATE TABLE `ctypa_vi_photo_favorite` (
  `favorite_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `row_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`favorite_id`),
  KEY `row_id` (`row_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_photo_rating`
--

DROP TABLE IF EXISTS `ctypa_vi_photo_rating`;
CREATE TABLE `ctypa_vi_photo_rating` (
  `rating_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `row_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rating_id`),
  KEY `row_id` (`row_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_photo_rows`
--

DROP TABLE IF EXISTS `ctypa_vi_photo_rows`;
CREATE TABLE `ctypa_vi_photo_rows` (
  `row_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `defaults` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `size` int(11) unsigned NOT NULL DEFAULT '0',
  `width` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `height` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mime` varchar(100) NOT NULL DEFAULT '',
  `file` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `favorite` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  `date_modified` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`row_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=21  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_photo_setting`
--

DROP TABLE IF EXISTS `ctypa_vi_photo_setting`;
CREATE TABLE `ctypa_vi_photo_setting` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_photo_setting`
--

INSERT INTO `ctypa_vi_photo_setting` VALUES
('home_view', 'home_view_grid_by_cat'), 
('album_view', 'album_view_grid'), 
('per_page_album', '30'), 
('per_page_photo', '30'), 
('structure_upload', 'Ym'), 
('maxupload', '134217728'), 
('active_logo', '1'), 
('autologosize1', '50'), 
('autologosize2', '40'), 
('autologosize3', '30'), 
('module_logo', 'images/logo.png');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_referer_stats`
--

DROP TABLE IF EXISTS `ctypa_vi_referer_stats`;
CREATE TABLE `ctypa_vi_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_referer_stats`
--

INSERT INTO `ctypa_vi_referer_stats` VALUES
('1dieuuoc.com', 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1453869315), 
('google.com', 26, 12, 14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1456311258), 
('top1-seo-service.com', 82, 33, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1456236598), 
('m.facebook.com', 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1454114822), 
('facebook.com', 6, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1454081979), 
('google.com.vn', 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1453462045), 
('buttons-for-website.com', 12, 6, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455984776), 
('r.search.yahoo.com', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1453558433), 
('burger-imperia.com', 4, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455973715), 
('vn.search.yahoo.com', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1453641925), 
('whois.domaintools.com', 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455521119), 
('k6ct1.com', 8, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455871979), 
('bing.com', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455234013), 
('hvd-store.com', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455326490), 
('yandex.ru', 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455671462), 
('buyessaynow.biz', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455719097), 
('hundejo.com', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455944051), 
('domaincrawler.com', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1456098428);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_searchkeys`
--

DROP TABLE IF EXISTS `ctypa_vi_searchkeys`;
CREATE TABLE `ctypa_vi_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `skey` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `skey` (`skey`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_support`
--

DROP TABLE IF EXISTS `ctypa_vi_support`;
CREATE TABLE `ctypa_vi_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idgroup` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `skype_item` varchar(100) NOT NULL,
  `skype_type` varchar(100) NOT NULL,
  `yahoo_item` varchar(100) NOT NULL,
  `yahoo_type` varchar(2) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_support_group`
--

DROP TABLE IF EXISTS `ctypa_vi_support_group`;
CREATE TABLE `ctypa_vi_support_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_support_group`
--

INSERT INTO `ctypa_vi_support_group` VALUES
(1, 'Admin', 3);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_tkblop`
--

DROP TABLE IF EXISTS `ctypa_vi_tkblop`;
CREATE TABLE `ctypa_vi_tkblop` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `lop` varchar(6) NOT NULL,
  `tiet` int(2) NOT NULL,
  `thu2` varchar(15) DEFAULT NULL,
  `thu3` varchar(15) DEFAULT NULL,
  `thu4` varchar(15) DEFAULT NULL,
  `thu5` varchar(15) DEFAULT NULL,
  `thu6` varchar(15) DEFAULT NULL,
  `thu7` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=20  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_tkblop`
--

INSERT INTO `ctypa_vi_tkblop` VALUES
(1, 'K6CT1', 1, 'Chào cờ', 'KTXLA', 'CSDL', 'BTĐT', 'CSDL', 'Nghỉ'), 
(2, 'K6CT1', 2, 'BTĐT', 'KTXLA', 'CSDL', 'BTĐT', 'CSDL', 'Nghỉ'), 
(3, 'K6CT1', 3, 'BTĐT', 'KTXLA', 'CSDL', 'TACN', 'CSDL', 'Nghỉ'), 
(4, 'K6CT1', 4, 'BTĐT', 'KTXLA', 'STVB', 'TACN', 'TACN', 'Nghỉ'), 
(5, 'K6CT1', 5, 'BTĐT', 'KTXLA', 'STVB', 'TACN', 'TACN', 'Nghỉ'), 
(6, 'K6CT1', 6, 'STVB', 'Nghỉ', 'STVB', 'Nghỉ', 'KTXLA', 'Nghỉ'), 
(7, 'K6CT1', 7, 'STVB', 'Nghỉ', 'STVB', 'Nghỉ', 'KTXLA', 'Nghỉ'), 
(8, 'K6CT1', 8, 'TACN', 'Nghỉ', 'STVB', 'Nghỉ', 'KTXLA', 'Nghỉ'), 
(9, 'K6CT1', 9, 'TACN', 'Nghỉ', 'TACN', 'Nghỉ', 'KTXLA', 'Nghỉ'), 
(10, 'K6CT1', 10, 'TACN', 'Nghỉ', 'TACN', 'Nghỉ', 'Nghỉ', 'Nghỉ');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_video_clip_clip`
--

DROP TABLE IF EXISTS `ctypa_vi_video_clip_clip`;
CREATE TABLE `ctypa_vi_video_clip_clip` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `tid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` mediumtext NOT NULL,
  `bodytext` mediumtext NOT NULL,
  `keywords` mediumtext NOT NULL,
  `img` varchar(255) NOT NULL,
  `internalpath` varchar(255) NOT NULL,
  `externalpath` mediumtext NOT NULL,
  `groups_view` varchar(255) NOT NULL,
  `comm` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `addtime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_video_clip_clip`
--

INSERT INTO `ctypa_vi_video_clip_clip` VALUES
(1, 3, 'Múa đương đại', 'mua-duong-dai', 'Trung cấp Dak Lak, múa đương đại tại Hội thi văn hóa, thể thao các trường TCCN tỉnh Dak Lak lần thứ nhất - Năm 2013', '', 'trung cấp,thi văn,thể thao', '', '', 'https://www.youtube.com/watch?v=30xE2pO9RgA', '6', 1, 1, 1453419856);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_video_clip_comm`
--

DROP TABLE IF EXISTS `ctypa_vi_video_clip_comm`;
CREATE TABLE `ctypa_vi_video_clip_comm` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `posttime` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `broken` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ischecked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `posttime` (`userid`,`posttime`),
  KEY `cid` (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_video_clip_hit`
--

DROP TABLE IF EXISTS `ctypa_vi_video_clip_hit`;
CREATE TABLE `ctypa_vi_video_clip_hit` (
  `cid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `view` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `likehit` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `unlikehit` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comment` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `broken` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `view` (`view`),
  KEY `likehit` (`likehit`),
  KEY `unlikehit` (`unlikehit`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_video_clip_hit`
--

INSERT INTO `ctypa_vi_video_clip_hit` VALUES
(1, 39, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_video_clip_topic`
--

DROP TABLE IF EXISTS `ctypa_vi_video_clip_topic`;
CREATE TABLE `ctypa_vi_video_clip_topic` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `keywords` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_video_clip_topic`
--

INSERT INTO `ctypa_vi_video_clip_topic` VALUES
(1, 0, 'Tài liệu Học tập', 'tai-lieu-hoc-tap', 'tài liệu học tập', 1, '', 1, 'tài liệu học tập'), 
(2, 0, 'Video Hướng dẫn', 'video-huong-dan', 'video hướng dẫn', 2, '', 1, 'video hướng dẫn'), 
(3, 0, 'Tổng hợp', 'tong-hop', 'tổng hợp', 3, '', 1, 'tổng hợp'), 
(4, 0, 'Cờ nhíp Của ban', 'co-nhip-cua-ban', 'cờ nhíp của bạn', 4, '', 1, 'cờ nhíp của bạn');


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_voting`
--

DROP TABLE IF EXISTS `ctypa_vi_voting`;
CREATE TABLE `ctypa_vi_voting` (
  `vid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_voting`
--

INSERT INTO `ctypa_vi_voting` VALUES
(2, 'Bạn biết đến Website này từ đâu?', '', 1, 1, '6', 1275318540, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `ctypa_vi_voting_rows`
--

DROP TABLE IF EXISTS `ctypa_vi_voting_rows`;
CREATE TABLE `ctypa_vi_voting_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vid` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=15  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctypa_vi_voting_rows`
--

INSERT INTO `ctypa_vi_voting_rows` VALUES
(5, 2, 'Một người bạn chia sẻ trên Facebook', '', 4), 
(6, 2, 'Tìm kiếm trên Google', '', 0), 
(7, 2, 'Bạn bè giới thiệu', '', 0), 
(14, 2, 'Vô tình biết được', '', 0);